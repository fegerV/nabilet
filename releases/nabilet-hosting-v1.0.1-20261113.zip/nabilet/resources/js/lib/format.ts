/**
 * Форматирование — часть интерфейса, а не утилита «на потом».
 *
 * Деньги в проекте хранятся целыми minor units (ТЗ §3), поэтому форматтер
 * принимает копейки и никогда не работает с float. Русские склонения вынесены
 * сюда же: «3 билета», а не «3 билет(ов)» — это первое, что выдаёт машинный UI.
 *
 * Само деление на 100 живёт не здесь, а в `lib/money.ts`: конверсия единиц —
 * одно правило, и `money()` его вызывает, а не повторяет.
 */

import { minorToRub } from './money'

export function money(minor: number, opts: { currency?: string; compact?: boolean } = {}): string {
  const { currency = '₽', compact = false } = opts
  const value = minorToRub(minor)

  if (compact && Math.abs(value) >= 1000) {
    const short = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 }).format(value / 1000)
    return `${short} тыс. ${currency}`
  }

  return `${new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 }).format(value)} ${currency}`
}

/**
 * Склонение: plural(3, 'билет', 'билета', 'билетов') → 'билета'.
 *
 * ПРАВИЛО ОДНО НА ДВА ЯЗЫКА. Ровно то же правило живёт на сервере
 * (`Core\Support\RuText::plural()`), потому что часть подписей собирается в
 * письмах и PDF. Языки разные — сверка автоматической быть не может, поэтому
 * таблица проверок в `tests/Unit/format.test.ts` повторяет таблицу
 * `tests/Unit/RuTextTest.php` число-в-число: если правило поменяют в одном
 * месте, вторая таблица об этом не узнает, но обе хотя бы закрепляют ОДИН
 * набор границ (11–14, 21–24, 101–114).
 *
 * ПОЧЕМУ НЕЛЬЗЯ «НА ПАЛЬЦАХ». На дашборде администратора стояло
 * `n === 1 ? 'мероприятие' : 'мероприятий'` — бинарная копия этого правила, в
 * которой потерялась форма для 2–4. Два черновика давали «2 мероприятий ещё в
 * черновиках». Копия выглядит безобидно, потому что верна для 1 и для 5.
 */
export function plural(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10
  const mod100 = n % 100
  if (mod10 === 1 && mod100 !== 11) return one
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few
  return many
}

export function seatsLabel(n: number): string {
  return `${n} ${plural(n, 'место', 'места', 'мест')}`
}

export function ticketsLabel(n: number): string {
  return `${n} ${plural(n, 'билет', 'билета', 'билетов')}`
}

/** Ряды в сетке зала: «1 ряд», «3 ряда», «12 рядов». */
export function rowsLabel(n: number): string {
  return `${n} ${plural(n, 'ряд', 'ряда', 'рядов')}`
}

const MONTHS_GEN = [
  'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
  'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
]
/** Именительный падеж — для автономного «октябрь 2026» (без числа перед ним). */
const MONTHS_NOM = [
  'январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
  'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь',
]
const WEEKDAYS = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб']

export function dateLong(iso: string): string {
  const d = new Date(iso)
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`
}

export function dateFull(iso: string): string {
  const d = new Date(iso)
  return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`
}

/** «25 декабря, 19:00» — дата + время (для таблиц заказов/сеансов). */
export function dateTime(iso: string): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}, ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

export function time(iso: string): string {
  const d = new Date(iso)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

/**
 * Даты с годом и короткие формы — один владелец, а не копии `toLocaleString`.
 *
 * РАНЬШЕ ЭТИ ФОРМАТЫ ЖИЛИ РОЗНО. `mediaLibrary.ts` и `AdminRafflesPage.vue`
 * определяли КАЖДЫЙ СВОЙ `formatDate` (один — «9 октября 2026», второй —
 * «25.12.2026, 19:30», то есть разные форматы под одним именем), а
 * `AdminEventFormPage` и `AdminDashboard` встраивали `toLocaleString` /
 * `Intl.DateTimeFormat` прямо в `computed`. Копии не лгали (форматы стабильны
 * для ru-RU), но расходились бы при смене локали или правке одного места.
 *
 * Здесь — единственный владелец; месяцы берутся из того же `MONTHS_GEN`, что у
 * `dateLong`/`dateTime`, поэтому вывод детерминирован и не зависит от локали
 * браузера (в отличие от `toLocaleString`, который на managed-хостинге с
 * неустановленной ru-RU мог бы отдать `Oct 9, 2026`).
 */
function pad2(n: number): string {
  return String(n).padStart(2, '0')
}

/** «9 октября 2026» — дата с годом (библиотека файлов). Пустая → ''. */
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]} ${d.getFullYear()}`
}

/** «9 октября 2026, 19:30» — дата с годом и временем (карточка мероприятия). */
export function formatDateTimeLong(iso: string | null | undefined): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]} ${d.getFullYear()}, ${pad2(d.getHours())}:${pad2(d.getMinutes())}`
}

/** «октябрь 2026» — подпись периода обзора. */
export function formatMonthYear(iso: string | null | undefined): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  return `${MONTHS_NOM[d.getMonth()]} ${d.getFullYear()}`
}

/** «09.10.2026, 19:30» — короткая дата+время (окно розыгрыша). */
export function formatDateTimeShort(iso: string | null | undefined): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${d.getFullYear()}, ${pad2(d.getHours())}:${pad2(d.getMinutes())}`
}

/** «через 9:41» — для таймера удержания места. */
export function countdown(secondsLeft: number): string {
  const s = Math.max(0, secondsLeft)
  const m = Math.floor(s / 60)
  const sec = s % 60
  return `${m}:${String(sec).padStart(2, '0')}`
}

/** Относительное время для админки: «12 минут назад». */
export function relative(iso: string, now: Date = new Date()): string {
  const diff = Math.round((now.getTime() - new Date(iso).getTime()) / 1000)
  if (diff < 60) return 'только что'
  if (diff < 3600) {
    const m = Math.round(diff / 60)
    return `${m} ${plural(m, 'минуту', 'минуты', 'минут')} назад`
  }
  if (diff < 86400) {
    const h = Math.round(diff / 3600)
    return `${h} ${plural(h, 'час', 'часа', 'часов')} назад`
  }
  const d = Math.round(diff / 86400)
  return `${d} ${plural(d, 'день', 'дня', 'дней')} назад`
}

/**
 * Читаемый размер файла — один владелец, а не копия в каждой странице.
 *
 * РАНЬШЕ ПРАВИЛО БЫЛО РАЗМНОЖЕНО. `humanSize` жил в `lib/mediaLibrary.ts` (его
 * домен — файлы), а `AdminLogsPage.vue` определял рядом свой `formatSize` с тем
 * же исходом, только переписанный иначе (`Math.round(bytes / 1024)` против
 * `(bytes / 1024).toFixed(0)`), и `AdminEventFormPage.vue` встраивал
 * `file.size / 1024 / 1024` прямо в строку ошибки и подпись превью. Копии были
 * эквивалентны, пока их не тронут: правка одной (добавить ГБ, сменить округление
 * КБ) разошлась бы с остальными, и лог стал бы показывать «10 МБ» там, где «10.0 МБ».
 *
 * Здесь — единственный владелец (рядом с `money`/`plural`/`formatDate`: всё, что
 * превращает «число» в «человеческую строку», живёт в `format.ts`).
 * `mediaLibrary.ts` его ре-экспортирует, чтобы старые импортёры не поменялись.
 */
export function humanSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 Б'
  if (bytes < 1024) return `${bytes} Б`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`
  return `${(bytes / 1024 / 1024).toFixed(1)} МБ`
}
