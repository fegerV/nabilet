<?php

declare(strict_types=1);

namespace Nabilet\Modules\Analytics\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Nabilet\Modules\Orders\StateMachines\OrderStateMachine;

/**
 * Аналитика против реальной схемы.
 *
 * Панель когда-то читала `bookings`/`booking_seats` — таблицы архивной схемы,
 * которых в `nabilet_core_spec/migrations.sql` нет, — и колонки
 * `analytics_events.event_type` (реально `event_name`), `users.name` (реально
 * `first_name`/`last_name`) и `events.name` (реально `title`).
 *
 * Каждый запрос ниже явно перечисляет колонки реальной схемы; тесты
 * `tests/Feature/Analytics/AnalyticsReportTest.php` кладут данные в настоящую
 * базу и проверяют результаты — если имя таблицы или колонки выдумано,
 * запрос упадёт на SQLSTATE[42P01]/[42703].
 */
class AnalyticsReportService
{
    /** Интервал отчёта по умолчанию, дней. */
    public const DEFAULT_DAYS = 30;

    /**
     * Общие метрики за период (все заказы, оплаченные отдельно).
     *
     * @return array{
     *     totalSales: int,
     *     revenue: int,
     *     totalOrders: int,
     *     totalTicketsSold: int,
     *     uniqueVisitors: int,
     * }
     */
    public function metrics(string|\DateTimeInterface $since): array
    {
        $since = $this->moment($since);

        $totalOrders = (int) DB::table('orders')
            ->where('created_at', '>=', $since)
            ->count();

        $totalSales = (int) DB::table('orders')
            ->where('created_at', '>=', $since)
            ->where('status', OrderStateMachine::PAID)
            ->sum('total_amount');

        $totalTicketsSold = (int) DB::table('tickets')
            ->where('created_at', '>=', $since)
            ->count();

        $uniqueVisitors = (int) DB::table('analytics_events')
            ->where('event_name', 'page_view')
            ->where('occurred_at', '>=', $since)
            ->distinct()
            // `user_id` is BIGINT and `anonymous_id` is CHAR(36); the two must be
            // compared in one type or the distinct collapses to nothing. MySQL's
            // cast spelling is `CAST(x AS CHAR)` — this read `user_id::text`, which
            // is not MySQL syntax at all and made the query fail with error 1064.
            ->count(DB::raw('COALESCE(CAST(user_id AS CHAR), anonymous_id)'));

        return [
            'totalSales' => $totalSales,
            'revenue' => $totalSales,
            'totalOrders' => $totalOrders,
            'totalTicketsSold' => $totalTicketsSold,
            'uniqueVisitors' => $uniqueVisitors,
        ];
    }

    /**
     * Топ событий по выручке (только оплаченные заказы).
     *
     * @return Collection<int, object{name: string, orders: int, revenue: int}>
     */
    public function topEvents(string|\DateTimeInterface $since): Collection
    {
        $since = $this->moment($since);

        // Один билет = одна позиция заказа, поэтому join с order_items даёт
        // несколько строк на заказ. Сначала выбираем УНИКАЛЬНЫЕ пары
        // (событие, заказ), и только потом суммируем сумму заказа — иначе
        // выручка умножалась бы на число билетов в заказе.
        $orders = DB::table('orders as o')
            ->join('order_items as oi', 'oi.order_id', '=', 'o.id')
            ->join('inventory_items as ii', 'ii.id', '=', 'oi.inventory_item_id')
            ->join('sessions as s', 's.id', '=', 'ii.session_id')
            ->join('events as e', 'e.id', '=', 's.event_id')
            ->where('o.created_at', '>=', $since)
            ->where('o.status', OrderStateMachine::PAID)
            ->select(
                'e.id as event_id',
                'e.title as name',
                'o.id as order_id',
                'o.total_amount'
            )
            ->distinct();

        return DB::query()
            ->fromSub($orders, 'x')
            ->select(
                'name',
                DB::raw('COUNT(*) as orders'),
                DB::raw('SUM(total_amount) as revenue')
            )
            ->groupBy('event_id', 'name')
            ->orderByDesc('revenue')
            ->limit(10)
            ->get();
    }

    /**
     * Продажи по дням: дата, число заказов, выручка.
     *
     * @return array<int, array{date: string, orders: int, revenue: float}>
     */
    public function salesByDay(string|\DateTimeInterface $since): array
    {
        $since = $this->moment($since);

        $rows = DB::table('orders')
            ->where('created_at', '>=', $since)
            ->selectRaw('CAST(created_at AS date) as date')
            ->selectRaw('COUNT(*) as orders')
            ->selectRaw('SUM(CASE WHEN status = ? THEN total_amount ELSE 0 END) as revenue', [OrderStateMachine::PAID])
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return $rows->map(fn ($r) => [
            'date' => (string) $r->date,
            'orders' => (int) $r->orders,
            'revenue' => (float) $r->revenue,
        ])->all();
    }

    /**
     * Заказы для экспорта. LEFT JOIN с users: гостевые заказы (user_id NULL)
     * обязаны попадать в выгрузку.
     *
     * @return Collection<int, object>
     */
    public function ordersForExport(string|\DateTimeInterface $since): Collection
    {
        $since = $this->moment($since);

        return DB::table('orders as o')
            ->leftJoin('users as u', 'u.id', '=', 'o.user_id')
            ->where('o.created_at', '>=', $since)
            ->select(
                'o.id',
                'o.order_number',
                'o.created_at',
                'u.first_name',
                'u.last_name',
                'u.email as customer_email',
                'o.customer_email as guest_email',
                'o.status',
                'o.total_amount',
                'o.currency'
            )
            ->orderByDesc('o.created_at')
            ->get();
    }

    /**
     * Уникальные посетители за период.
     */
    public function uniqueVisitors(string|\DateTimeInterface $since): int
    {
        return (int) $this->metrics($since)['uniqueVisitors'];
    }

    /**
     * Статусы заказов с количеством.
     *
     * @return Collection<int, object{status: string, count: int}>
     */
    public function orderStatuses(string|\DateTimeInterface $since): Collection
    {
        $since = $this->moment($since);

        return DB::table('orders')
            ->where('created_at', '>=', $since)
            ->select('status', DB::raw('COUNT(*) as count'))
            ->groupBy('status')
            ->orderByDesc('count')
            ->get();
    }

    private function moment(string|\DateTimeInterface $since): string
    {
        if ($since instanceof \DateTimeInterface) {
            return $since->format('Y-m-d H:i:s');
        }

        return $since;
    }
}