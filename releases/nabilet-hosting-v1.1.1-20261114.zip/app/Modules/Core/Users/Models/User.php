<?php

declare(strict_types=1);

namespace Nabilet\Modules\Core\Users\Models;

use Nabilet\Modules\Core\Models\Concerns\HasPublicId;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Nabilet\Modules\Core\Users\Domain\UserStatus;
use Nabilet\Modules\Core\Organizations\Models\Organization;
use Nabilet\Modules\Core\Models\Role;
use Nabilet\Modules\Core\Models\UserRole;
use Nabilet\Modules\Core\Models\UserSession;
use Nabilet\Modules\Core\Models\LoginLog;
use Nabilet\Modules\Orders\Models\Order;
use Nabilet\Modules\Tickets\Models\Ticket;
use Nabilet\Modules\Cart\Models\Cart;
use Nabilet\Modules\Privacy\Models\Consent;
use Nabilet\Modules\Notifications\Models\Notification;
use Nabilet\Modules\Privacy\Models\PrivacyRequest;
use Nabilet\Modules\Media\Models\MediaAsset;
use Nabilet\Modules\Analytics\Models\HeatmapEvent;
use Nabilet\Modules\Analytics\Models\AnalyticsEvent;
use Nabilet\Modules\Analytics\Models\AbAssignment;

/**
 * User Model - Canonical Implementation
 *
 * Represents a user in the system with all relationships.
 *
 * WHY IT EXTENDS `Illuminate\Foundation\Auth\User`
 *   This was a plain `Model`, which meant it could not be the subject of a guard:
 *   `Illuminate\Contracts\Auth\Authenticatable` is what `Auth::user()`,
 *   `$request->user()` and every policy expect, and `EloquentUserProvider` refuses
 *   anything else. The auth provider in `config/auth.php` pointed at
 *   `App\Models\User` instead — the web guard's model — while every module in
 *   the tree uses *this* one. A guard that returned the other model would hand
 *   controllers a different class for the same row, so `instanceof` checks and
 *   `userSessions()` would be missing exactly where they are needed.
 *
 *   The base class brings `Authenticatable`, `Authorizable`, `CanResetPassword`
 *   and `MustVerifyEmail`. It declares no `$fillable`, no `$table` and no
 *   `$timestamps`, so nothing declared below is overridden, and it adds no
 *   attribute — `verify-models-schema.php` sees the same field set as before.
 */
class User extends Authenticatable
{
    use HasPublicId;

    use HasApiTokens;

    protected $table = 'users';

    /**
     * `password` and `remember_token` never leave the process.
     *
     * The base class does not declare `$hidden` (Laravel removed it), so without
     * this a `toArray()` — in a log line, an exception context, or a resource that
     * forgets a field — would carry the password hash. `AuthResource` lists its
     * fields explicitly, so this is defence in depth rather than the only guard.
     */
    protected $hidden = ['password', 'remember_token'];

    protected $fillable = [
        'public_id',
        'email',
        'email_verified_at',
        'password',
        'first_name',
        'last_name',
        'phone',
        'phone_verified_at',
        'status',
        'locale',
        'timezone',
        'last_login_at',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime:Y-m-d H:i:s.u',
            'phone_verified_at' => 'datetime:Y-m-d H:i:s.u',
            'last_login_at' => 'datetime:Y-m-d H:i:s.u',
            'created_at' => 'datetime:Y-m-d H:i:s.u',
            'updated_at' => 'datetime:Y-m-d H:i:s.u',
            'deleted_at' => 'datetime:Y-m-d H:i:s.u',
        ];
    }

    /**
     * Display name, as one string.
     *
     * MOVED HERE from `App\Models\User` — that class was a *second* model over
     * the same `users` table with its own `$fillable` and none of the relations
     * declared below. The duplication was not harmless: `Order::user()` resolves
     * to THIS model, so `$order->user?->name` was always null and
     * `OrderNotificationData::customerName()` silently fell back to
     * «Покупатель». An accessor that only one of two models for one table has is
     * a bug generator, so it lives with the model now.
     */
    public function getNameAttribute(): string
    {
        return trim(($this->first_name ?? '') . ' ' . ($this->last_name ?? '')) ?: 'User';
    }

    /**
     * Access to the admin panel: an account that is not `active` cannot enter.
     *
     * ROLE CHECKS ARE NOT HERE. `isAdminSession()` / the `admin` middleware
     * decide what a session may do; this answers only whether the account
     * behind it still exists for that purpose (`banned` = no). Kept from
     * `App\Models\User`, which was the only place it lived.
     */
    public function canAccessAdmin(): bool
    {
        return $this->status === UserStatus::ACTIVE;
    }

    public function organizations(): BelongsToMany
        {
            return $this->belongsToMany(Organization::class, 'user_organization')
                ->withPivot('role_id');
        }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'user_roles');
    }

    /**
     * Role membership by slug — one query, no hydration of the whole relation.
     *
     * MOVED HERE from `App\Models\User` (see `getNameAttribute()`): a role check
     * that only one of two models for one table offers is a check that silently
     * returns false on the other.
     */
    public function hasRole(string $role): bool
    {
        return $this->roles()->where('slug', $role)->exists();
    }

    public function userRoles(): HasMany
    {
        return $this->hasMany(UserRole::class);
    }

    public function userSessions(): HasMany
    {
        return $this->hasMany(UserSession::class);
    }

    public function loginLogs(): HasMany
    {
        return $this->hasMany(LoginLog::class);
    }

    /**
     * Заказы покупателя.
     *
     * ВНЕШНИЙ КЛЮЧ БЫЛ НЕВЕРНЫМ. Здесь стояло `hasMany(Order::class,
     * 'customer_id')`, а колонки `customer_id` в схеме НЕТ — ни в `orders`, ни
     * в одной другой таблице (проверено по `information_schema`). Связь была
     * нерабочей: `$user->orders` падал с SQLSTATE 42S22 «Unknown column
     * 'orders.customer_id'». Не замечали потому, что связь не вызывалась
     * ниоткуда — мёртвый код, который выглядел рабочим.
     *
     * Владелец заказа — `orders.user_id` (nullable FK на `users`,
     * `ON DELETE SET NULL`), и именно по нему скоупит `OrderController`.
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'user_id');
    }

    /**
     * Билеты покупателя — через его заказы.
     *
     * Прямой связи `tickets.customer_id` не существует: билет принадлежит
     * заказу (`tickets.order_id`, NOT NULL, FK), а покупателю — через него.
     * Здесь стояло `hasMany(Ticket::class, 'customer_id')`, то есть та же
     * несуществующая колонка, что и в `orders()` выше.
     */
    public function tickets(): HasManyThrough
    {
        return $this->hasManyThrough(Ticket::class, Order::class, 'user_id', 'order_id');
    }

    public function carts(): HasMany
    {
        return $this->hasMany(Cart::class);
    }

    public function consents(): HasMany
    {
        return $this->hasMany(Consent::class);
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class);
    }

    public function privacyRequests(): HasMany
    {
        return $this->hasMany(PrivacyRequest::class);
    }

    public function grantedUserRoles(): HasMany
    {
        return $this->hasMany(UserRole::class, 'granted_by');
    }

    public function uploadedMediaAssets(): HasMany
    {
        return $this->hasMany(MediaAsset::class, 'uploaded_by');
    }

    public function heatmapEvents(): HasMany
    {
        return $this->hasMany(HeatmapEvent::class);
    }

    public function analyticsEvents(): HasMany
    {
        return $this->hasMany(AnalyticsEvent::class);
    }

    public function abAssignments(): HasMany
    {
        return $this->hasMany(AbAssignment::class);
    }
}
