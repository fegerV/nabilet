<?php

declare(strict_types=1);

namespace Nabilet\Modules\Media\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Nabilet\Core\Support\AssetUrl;

/**
 * Файл для API.
 *
 * Поля совпадают со схемой `MediaAsset` контракта. Дополнительно отдаются три,
 * которых в схеме нет, и каждое — осознанно:
 *
 *  * `public_id` — публичный идентификатор (ULID). Числовой `id` остаётся в
 *    ответе для совместимости с уже написанным админским кодом, но в ссылках и
 *    между модулями используется `public_id`: он не говорит, сколько файлов в
 *    системе и в каком порядке они загружены.
 *  * `url` — готовый адрес. Клиент мог бы собрать его сам из `disk` и `path`,
 *    но тогда правило «`/storage/...` против корня» размножилось бы по фронтенду
 *    ровно так же, как когда-то размножилось по бэкенду (см. `AssetUrl`).
 *    Адрес ОТНОСИТЕЛЬНЫЙ (`/storage/...`), а не абсолютный от `APP_URL`:
 *    админка и API отдаются одним хостом, поэтому относительный путь всегда
 *    резолвится верно. Раньше абсолютный адрес ломал превью файлов, когда хост
 *    в `.env` не совпадал с хостом, на котором открыта админка (404 на каждом
 *    `<img>`). Внешние адреса (если в `path` лежит полный URL) возвращаются как есть.
 *    Значение собирает `AssetUrl::storageRelative()`: список «что считается
 *    внешним» существует в одном месте — у абсолютного варианта, — и четвёртый
 *    случай добавили бы только туда.
 *  * `links` — привязки к объектам, и только когда они подгружены. Галерея
 *    мероприятия без них не может показать, к какому объекту относится файл,
 *    а `position` задаёт порядок. Поле не добавляется, если связь не загружена:
 *    иначе каждый ответ тянул бы запрос, которого вызывающий не просил.
 */
class MediaAssetResource extends JsonResource
{
    public function toArray($request): array
    {
        $asset = $this->resource;

        $data = [
            'id' => (int) $asset->id,
            'public_id' => (string) $asset->public_id,
            // Виртуальная папка медиатеки; null — «Все файлы».
            'folder_id' => $asset->folder_id === null ? null : (int) $asset->folder_id,
            'disk' => (string) $asset->disk,
            'path' => (string) $asset->path,
            'url' => AssetUrl::storageRelative((string) $asset->path),
            'filename' => (string) $asset->filename,
            'mime_type' => (string) $asset->mime_type,
            'size_bytes' => (int) $asset->size_bytes,
            'width' => $asset->width === null ? null : (int) $asset->width,
            'height' => $asset->height === null ? null : (int) $asset->height,
            'checksum' => $asset->checksum === null ? null : (string) $asset->checksum,
            'title' => $asset->title === null ? null : (string) $asset->title,
            'alt_text' => $asset->alt_text === null ? null : (string) $asset->alt_text,
            'variants_json' => $asset->variants_json,
            'created_at' => $asset->created_at?->toIso8601String(),
            'updated_at' => $asset->updated_at?->toIso8601String(),
        ];

        if ($asset->relationLoaded('links')) {
            $data['links'] = $asset->links
                ->map(static fn ($link): array => [
                    'id' => (int) $link->id,
                    'entity_type' => (string) $link->entity_type,
                    'entity_id' => (int) $link->entity_id,
                    'role' => (string) $link->role,
                    'position' => (int) $link->position,
                ])
                ->values()
                ->all();
        }

        return $data;
    }
}
