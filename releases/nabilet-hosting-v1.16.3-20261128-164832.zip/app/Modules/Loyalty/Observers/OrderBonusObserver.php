<?php

declare(strict_types=1);

namespace Nabilet\Modules\Loyalty\Observers;

use Illuminate\Support\Facades\DB;
use Nabilet\Modules\Loyalty\Jobs\AccrueOrderBonusJob;
use Nabilet\Modules\Loyalty\Jobs\RefundOrderBonusJob;
use Nabilet\Modules\Orders\Models\Order;
use Nabilet\Modules\Orders\StateMachines\OrderStateMachine;
use Nabilet\Modules\Payments\StateMachines\RefundStateMachine;

/**
 * Реакция на смену статуса заказа: начислить кэшбэк за оплату, вернуть бонусы
 * за несостоявшуюся покупку.
 *
 * ПОЧЕМУ ОБСЕРВЕР, А НЕ ВЫЗОВ ИЗ `OrderService::markPaid()`
 *   Заказ становится `paid` из нескольких мест — `OrderService::markPaid()`
 *   (обычный путь оплаты), `PaymentService` при подтверждении платежа,
 *   `RefundService` и админские сценарии, — и начислять бонусы из каждого
 *   значит гарантированно забыть один. Ровно это рассуждение записано в
 *   `OrderObserver` для писем и вебхуков, и здесь оно то же: обсервер — это
 *   единственная точка, где ловятся ВСЕ переходы статуса. То же самое верно и
 *   для отмены: `cancelled` приходит и из админского сценария, и из
 *   `OrderService::cancelOrder()`, и из вебхука провайдера.
 *
 * ПОЧЕМУ `afterCommit()` НА ПОСТАНОВКЕ
 *   Ни начисление, ни возврат не должны уйти от транзакции, которая откатилась:
 *   иначе покупатель получил бы бонусы за заказ, которого нет, или наоборот
 *   вернул бы бонусы по заказу, который всё-таки прошёл. И ни одно из двух не
 *   должно выполняться внутри транзакции оплаты — сбой бонусного счёта не имеет
 *   права отменить купленный билет или возврат денег.
 *
 * ГРАНИЦА, КОТОРУЮ НАДО ЗНАТЬ
 *   Обсервер ловит только СМЕНУ статуса. Заказ, оказавшийся `paid` без правки
 *   строки (такого пути в коде нет — `markPaid()` всегда делает `update()`),
 *   остался бы без начисления; разбор таких случаев — задача сверки, а не
 *   наблюдателя.
 *
 * КОГДА БОНУСЫ ВОЗВРАЩАЮТСЯ — И ПОЧЕМУ ИМЕННО ЭТИ ТРИ СТАТУСА
 *   `cancelled` и `expired` — заказ не станет оплаченным никогда: покупка не
 *   состоялась, а бонусы были списаны в момент оформления (см.
 *   `BonusService::spendForOrder()`, где объяснено, почему списание, а не
 *   отложенный «резерв»). `refunded` — покупка состоялась и была отменена
 *   целиком: покупатель вернул деньги, и бонусная часть платежа обязана
 *   вернуться вместе с ними, иначе возврат «в бонусах» тихо пропадает.
 *
 *   `payment_failed` В СПИСКЕ НЕТ, и это не упущение: этот статус не терминальный
 *   (`OrderStateMachine` разрешает `payment_failed → awaiting_payment`), то есть
 *   покупатель может повторить оплату с другой карты. Вернуть бонусы на отказе
 *   карты значило бы вернуть их заказу, который ещё может быть оплачен, — а
 *   повторное списание потребовало бы новой строки журнала, потому что
 *   `spend:{order_id}` уже израсходован. Бонусы ждут вместе с местами.
 *
 *   `partially_refunded` В СПИСКЕ ТОЖЕ НЕТ: частичный возврат — это возврат части
 *   мест, и «какая доля списанных бонусов возвращается» — отдельное продуктовое
 *   решение, которого пока нет. Заказ в этом статусе может уйти в `refunded`, и
 *   тогда возврат произойдёт целиком. Известное ограничение, записано в
 *   `docs/LOYALTY-PLAN.md`.
 */
class OrderBonusObserver
{
    /** Терминальные статусы, в которых покупка не состоялась. */
    private const RELEASES_BONUSES = [
        OrderStateMachine::CANCELLED,
        OrderStateMachine::EXPIRED,
        OrderStateMachine::REFUNDED,
    ];

    public function updated(Order $order): void
    {
        // Тот же статус мог быть записан повторно (идемпотентный `markPaid`) —
        // ни начисление, ни возврат это не повод дублировать, и `dedupe_key`
        // поймал бы повтор, но лишняя джоба в очереди всё равно не нужна.
        if (! $order->wasChanged('status')) {
            return;
        }

        if ($order->status === OrderStateMachine::PAID) {
            AccrueOrderBonusJob::forOrder($order)
                ->onConnection('database')
                ->afterCommit();

            return;
        }

        if ($order->status === OrderStateMachine::PARTIALLY_REFUNDED) {
            // Сумма берётся из тех же строк refunds, по которым RefundLedger
            // выбрал этот статус: неудачные возвраты не считаются. Не держим её
            // в колонке заказа — это было бы вторым источником правды о деньгах.
            $refunded = (int) (DB::table('refunds')
                ->join('payments', 'payments.id', '=', 'refunds.payment_id')
                ->where('payments.order_id', $order->getKey())
                ->where('refunds.status', '!=', RefundStateMachine::FAILED)
                ->sum('refunds.amount'));

            RefundOrderBonusJob::forOrder($order, max(0, $refunded))
                ->onConnection('database')
                ->afterCommit();

            return;
        }

        if (in_array($order->status, self::RELEASES_BONUSES, true)) {
            RefundOrderBonusJob::forOrder($order)
                ->onConnection('database')
                ->afterCommit();
        }
    }
}
