<?php

declare(strict_types=1);

namespace Nabilet\Modules\Tickets\Services;

use Nabilet\Core\Support\QrSigner;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Tickets\Domain\CheckinEvaluator;
use Nabilet\Modules\Tickets\Domain\ScanMode;
use Nabilet\Modules\Tickets\Domain\ScanOutcome;
use Nabilet\Modules\Tickets\Domain\ScanRequest;
use Nabilet\Modules\Tickets\Domain\TicketSnapshot;
use Nabilet\Modules\Tickets\Models\Ticket;
use Nabilet\Modules\Tickets\Models\TicketScan;
use Nabilet\Modules\Tickets\Repositories\TicketRepository;
use Nabilet\Modules\Tickets\StateMachines\TicketStateMachine;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Service for handling ticket scanning and check-in operations.
 *
 * The decision itself belongs to the pure domain CheckinEvaluator, whose real
 * contract is evaluate(ScanRequest, ?TicketSnapshot): this service is the
 * adapter that builds those value objects from Eloquent models, persists the
 * scan row, and applies `resultingStatus` — the evaluator never writes.
 */
class TicketScanService
{
    public function __construct(
        private readonly TicketRepository $repository,
        private readonly CheckinEvaluator $checkinEvaluator
    ) {}

    /**
     * Scan a ticket and record the check-in.
     *
     * A11.2 (Critical): если передан `qr_payload`, его подпись обязана быть
     * проверена через QrSigner. Без этого любой, знающий перебираемый ticket_id
     * (и session_id), мог «погасить» чужой билет, не предъявляя валидного QR —
     * классическая подделка входа. Если `qr_payload` не передан (внутренний вызов,
     * например TicketService::checkInTicket), используется прежний путь по id.
     *
     * ИДЕМПОТНОСТЬ (`$clientScanId`)
     *   `POST /api/v1/checkin/use` обязан быть идемпотентным: оператор дважды
     *   нажимает «погасить», сеть переотправляет пакет. Ключ — UUID, который
     *   генерирует УСТРОЙСТВО (`client_scan_id`), а схема обеспечивает
     *   уникальность парой `uq_ticket_scans_client (device_id, client_scan_id)`.
     *   При повторе возвращается ЗАПИСАННЫЙ исход, а не новый: иначе «нажал
     *   дважды» выглядело бы как «вошло два человека», а «повтор after already_used»
     *   стирал бы первую отметку времени — ту самую, по которой §32 требует
     *   показать оператору, когда билет вошёл в первый раз.
     *
     *   Поверх этого `EnsureIdempotency` (заголовок `Idempotency-Key`) защищает
     *   от повтора на уровне HTTP-транспорта. Это разные уровни: client_scan_id
     *   живёт в приложении устройства и переживает перезапуск, ключ заголовка —
     *  нет. Оба нужны, и ни один не заменяет другой.
     *
     * @param int $organizationId организация запроса (устройства или сотрудника);
     *   обязательна (план §3.1): забыть арендатора — ошибка типов, а не
     *   молчаливый пропуск проверки
     * @param string|null $clientScanId UUID устройства; null — внутренний вызов
     * @param \DateTimeImmutable|null $scannedAt момент сканирования для офлайн-пакета
     * @return array{success: bool, message: string, result?: string, ticket?: Ticket, scan?: TicketScan, reason?: string, replay?: bool}
     */
    public function scan(
        int $ticketId,
        int $sessionId,
        int $organizationId,
        ?int $deviceId = null,
        ?string $qrPayload = null,
        ?string $clientScanId = null,
        ?\DateTimeImmutable $scannedAt = null,
    ): array {
        // Проверка-in идёт по токену устройства: организации HTTP-контекста
        // здесь нет (и не нужно) — арендатор проверяется ниже явно через
        // `belongsToOrganization($organizationId, ...)`, который передают все
        // HTTP-входы. Читающий скоуп `Ticket` глушился бы этим обходом и так.
        return app(OrganizationContext::class)->withoutScope(
            fn (): array => $this->scanScoped($ticketId, $sessionId, $deviceId, $qrPayload, $clientScanId, $scannedAt, $organizationId)
        );
    }

    private function scanScoped(
        int $ticketId,
        int $sessionId,
        ?int $deviceId,
        ?string $qrPayload,
        ?string $clientScanId,
        ?\DateTimeImmutable $scannedAt,
        int $organizationId,
    ): array {
        return DB::transaction(function () use ($ticketId, $sessionId, $deviceId, $qrPayload, $clientScanId, $scannedAt, $organizationId) {
            // Идемпотентный повтор приходит ДО любых изменений: билет уже
            // погашен этим же самым сканом, и второй раз его гасить нечем.
            if ($clientScanId !== null && $deviceId !== null) {
                $existing = TicketScan::query()
                    ->where('device_id', $deviceId)
                    ->where('client_scan_id', $clientScanId)
                    ->first();

                if ($existing !== null) {
                    $ticket = Ticket::query()->whereKey($existing->ticket_id)->first();

                    // Повтор не должен становиться обходом арендатора: устройство
                    // организации B не получает исход скана билета организации A
                    // даже при совпавшем client_scan_id.
                    if ($ticket === null
                        || ! $this->belongsToOrganization($organizationId, $this->ticketOrganizationId($ticket))
                    ) {
                        return [
                            'success' => false,
                            'message' => 'Ticket not found',
                            'reason' => 'TICKET_NOT_FOUND',
                        ];
                    }

                    return [
                        'success' => in_array($existing->result, [ScanOutcome::ADMITTED, ScanOutcome::CONFLICT_REVOKED], true),
                        'message' => 'Scan already recorded (idempotent replay)',
                        'result' => $existing->result,
                        'reason' => strtoupper($existing->result),
                        'ticket' => $ticket,
                        'scan' => $existing,
                        'replay' => true,
                    ];
                }
            }

            // A11.2: вход по QR — проверяем подпись, иначе отклоняем.
            if ($qrPayload !== null) {
                $verified = $this->makeQrSigner()->verify($qrPayload);

                if ($verified === null) {
                    return [
                        'success' => false,
                        'message' => 'QR signature is invalid',
                        'reason' => 'QR_SIGNATURE_INVALID',
                    ];
                }

                // Пэйлоад несёт public_id билета (QrSigner «NB1.<publicId>.<token>.<sig>»).
                $ticket = Ticket::query()
                    ->where('public_id', $verified['ticketId'])
                    ->lockForUpdate()
                    ->first();

                if (!$ticket) {
                    return [
                        'success' => false,
                        'message' => 'Ticket not found',
                        'reason' => 'TICKET_NOT_FOUND',
                    ];
                }

                // Кросс-проверка с переданным ticket_id (если указан).
                if ($ticketId !== 0 && $ticket->id !== $ticketId) {
                    return [
                        'success' => false,
                        'message' => 'Ticket id does not match QR',
                        'reason' => 'TICKET_ID_MISMATCH',
                    ];
                }
            } else {
                // Прежний путь по целочисленному id (внутренний вызов без QR).
                $ticket = Ticket::query()
                    ->where('id', $ticketId)
                    ->lockForUpdate()
                    ->first();

                if (!$ticket) {
                    return [
                        'success' => false,
                        'message' => 'Ticket not found',
                        'reason' => 'TICKET_NOT_FOUND',
                    ];
                }
            }

            // Межарендаторский доступ: билет другой организации неотличим от
            // несуществующего. `null` — внутренний вызов без HTTP-контекста
            // (например, `TicketService::checkInTicket`), для него проверка не
            // выполняется; все HTTP-входы передают организацию явно.
            if (! $this->belongsToOrganization($organizationId, $this->ticketOrganizationId($ticket))) {
                return [
                    'success' => false,
                    'message' => 'Ticket not found',
                    'reason' => 'TICKET_NOT_FOUND',
                ];
            }

            // tickets.session_id is a first-class column (spec schema); there is
            // no inventoryItem relation on Ticket and going through it produced
            // "Call to undefined relationship" errors at runtime.
            if ((int) $ticket->session_id !== $sessionId) {
                return [
                    'success' => false,
                    'message' => 'Ticket does not belong to this session',
                    'reason' => 'WRONG_SESSION',
                ];
            }

            // Сеанс тоже обязан принадлежать той же организации: иначе билет
            // организации A можно было бы «проверить» на сеансе организации B.
            if (! $this->belongsToOrganization($organizationId, $this->sessionOrganizationId($sessionId))) {
                return [
                    'success' => false,
                    'message' => 'Session not found',
                    'reason' => 'WRONG_SESSION',
                ];
            }

            $outcome = $this->checkinEvaluator->evaluate(
                new ScanRequest(
                    ticketPublicId: $ticket->public_id,
                    sessionId: $sessionId,
                    mode: ScanMode::ONLINE,
                    deviceId: $deviceId,
                    clientScanId: $clientScanId,
                    scannedAt: $scannedAt,
                ),
                $this->snapshot($ticket),
            );

            $scan = $this->repository->recordScan(
                $ticket,
                $deviceId,
                result: $outcome->result,
                mode: ScanMode::ONLINE,
                clientScanId: $clientScanId,
                scannedAt: $scannedAt,
            );

            if (!$outcome->admits) {
                return [
                    'success' => false,
                    'message' => $outcome->reason ?? 'Check-in not allowed',
                    'result' => $outcome->result,
                    'reason' => strtoupper($outcome->result),
                    'ticket' => $ticket,
                    'scan' => $scan,
                    'used_at' => $outcome->usedAt?->format(\DATE_ATOM),
                ];
            }

            // Admitted: issued -> used, exactly once (no used -> issued path in
            // the state machine; §32 re-scans return already_used above).
            if ($outcome->resultingStatus !== null && $ticket->status !== $outcome->resultingStatus) {
                $ticket->update([
                    'status' => $outcome->resultingStatus,
                    'used_at' => now(),
                ]);
            }

            return [
                'success' => true,
                'message' => 'Check-in successful',
                'result' => $outcome->result,
                'ticket' => $ticket->fresh(),
                'scan' => $scan,
            ];
        });
    }

    /**
     * Verify if a ticket can be checked in without recording the scan.
     *
     * `$organizationId` — организация запроса (устройства или сотрудника),
     * обязательна (план §3.1). Чужой билет и чужой сеанс отвечают так же, как
     * несуществующие: иначе проверка превращается в способ узнать, что билет
     * с таким QR существует у другого арендатора.
     *
     * @return array{valid: bool, reason?: string, result?: string}
     */
    public function canCheckin(
        Ticket $ticket,
        int $sessionId,
        int $organizationId,
        ?int $deviceId = null,
    ): array {
        if (! $this->belongsToOrganization($organizationId, $this->ticketOrganizationId($ticket))) {
            return ['valid' => false, 'result' => ScanOutcome::NOT_FOUND, 'reason' => 'TICKET_NOT_FOUND'];
        }

        if ((int) $ticket->session_id !== $sessionId) {
            // Ключ `result` обязан быть: контроллер читает именно его
            // (`$decision['result']`), и без него вердикт скатывается в
            // `unknown_ticket` вместо `wrong_session`/`wrong_event`. Различие
            // session/event дальше берётся из сравнения event_id в контроллере.
            return ['valid' => false, 'result' => ScanOutcome::WRONG_SESSION, 'reason' => 'WRONG_SESSION'];
        }

        if (! $this->belongsToOrganization($organizationId, $this->sessionOrganizationId($sessionId))) {
            return ['valid' => false, 'result' => ScanOutcome::NOT_FOUND, 'reason' => 'TICKET_NOT_FOUND'];
        }

        $outcome = $this->checkinEvaluator->evaluate(
            new ScanRequest(
                ticketPublicId: $ticket->public_id,
                sessionId: $sessionId,
                mode: ScanMode::ONLINE,
                deviceId: $deviceId,
            ),
            $this->snapshot($ticket),
        );

        if (!$outcome->admits) {
            return [
                'valid' => false,
                'result' => $outcome->result,
                'reason' => strtoupper($outcome->result),
            ];
        }

        return ['valid' => true, 'result' => $outcome->result];
    }

    /**
     * Проверить подпись QR-пэйлоада и вернуть извлечённый public_id билета.
     * Используется публичным эндпоинтом verify для децентрализованной валидации.
     *
     * @return array{ticketId: string, token: string}|null null при невалидной подписи
     */
    public function verifyQr(string $payload): ?array
    {
        return $this->makeQrSigner()->verify($payload);
    }

    /**
     * Подписывальщик QR — через единый `QrSignerFactory`.
     *
     * Здесь была КОПИЯ логики из `TicketService::makeQrSigner()` (с комментарием
     * «логика скопирована»), и обе копии подписывали билеты `APP_KEY`, когда
     * `TICKET_QR_SECRET` не задан. Теперь источник один.
     */
    private function makeQrSigner(): QrSigner
    {
        return QrSignerFactory::make();
    }

    /**
     * Process an offline bundle scan (§44 reconciliation).
     *
     * The device already made its decision at the door; the server records what
     * happened and resolves conflicts by revocation — it cannot un-admit anyone.
     *
     * `$bundleHash === null` — вызов из `POST /api/v1/checkin/sync`, где контракт
     * хеша бандла не предусматривает. Тогда проверка ослабляется ровно на одну
     * ступень и не молча: устройство обязано иметь НЕИСТЁКШИЙ бандл на этот
     * сеанс (`offline_bundles`), иначе офлайн-скан неотличим от выдуманного.
     * Точный хеш остаётся для путей, которые его передают.
     */
    public function scanFromBundle(
        string $ticketPublicId,
        int $organizationId,
        ?string $bundleHash,
        int $deviceId,
        ?string $clientScanId = null,
        bool $deviceAdmitted = true,
        ?\DateTimeImmutable $scannedAt = null,
    ): array {
        // Тот же аргумент, что у `scan()`: организация приходит параметром
        // (устройство из бандла), HTTP-контекст отсутствует.
        return app(OrganizationContext::class)->withoutScope(
            fn (): array => $this->scanFromBundleScoped($ticketPublicId, $bundleHash, $deviceId, $clientScanId, $deviceAdmitted, $scannedAt, $organizationId)
        );
    }

    private function scanFromBundleScoped(
        string $ticketPublicId,
        ?string $bundleHash,
        int $deviceId,
        ?string $clientScanId,
        bool $deviceAdmitted,
        ?\DateTimeImmutable $scannedAt,
        int $organizationId,
    ): array {
        return DB::transaction(function () use ($ticketPublicId, $bundleHash, $deviceId, $clientScanId, $deviceAdmitted, $scannedAt, $organizationId) {
            $ticket = Ticket::query()
                ->where('public_id', $ticketPublicId)
                ->lockForUpdate()
                ->first();

            if (!$ticket) {
                return [
                    'success' => false,
                    'message' => 'Ticket not found',
                    'reason' => 'TICKET_NOT_FOUND',
                ];
            }

            // Межарендаторский доступ: билет и сеанс обязаны принадлежать
            // организации устройства. Чужой билет неотличим от несуществующего.
            if (! $this->belongsToOrganization($organizationId, $this->ticketOrganizationId($ticket))) {
                return [
                    'success' => false,
                    'message' => 'Ticket not found',
                    'reason' => 'TICKET_NOT_FOUND',
                ];
            }

            if (! $this->belongsToOrganization($organizationId, $this->sessionOrganizationId((int) $ticket->session_id))) {
                return [
                    'success' => false,
                    'message' => 'Ticket not found',
                    'reason' => 'TICKET_NOT_FOUND',
                ];
            }

            if (!$this->verifyBundleForDevice($bundleHash, $deviceId, (int) $ticket->session_id)) {
                return [
                    'success' => false,
                    'message' => 'Invalid bundle for this device/session',
                    'reason' => 'INVALID_BUNDLE',
                ];
            }
            // De-duplicate retried uploads via uq_ticket_scans_client
            // (device_id, client_scan_id): the same upload applied twice must
            // not become two admissions.
            if ($clientScanId !== null) {
                $existing = TicketScan::query()
                    ->where('device_id', $deviceId)
                    ->where('client_scan_id', $clientScanId)
                    ->first();

                if ($existing) {
                    return [
                        'success' => true,
                        'message' => 'Scan already recorded (idempotent replay)',
                        'result' => $existing->result,
                        'ticket' => $ticket,
                        'scan' => $existing,
                        // Признак повтора: `sync` считает его отдельным счётчиком
                        // (`duplicates`). Без флага повторная загрузка выглядела
                        // бы новым допуском — то есть одним человеком, вошедшим
                        // дважды.
                        'replay' => true,
                    ];
                }
            }

            $outcome = $this->checkinEvaluator->evaluate(
                new ScanRequest(
                    ticketPublicId: $ticket->public_id,
                    sessionId: (int) $ticket->session_id,
                    mode: ScanMode::OFFLINE_SYNC,
                    deviceId: $deviceId,
                    clientScanId: $clientScanId ?? (string) Str::uuid(),
                    scannedAt: $scannedAt,
                    deviceAdmitted: $deviceAdmitted,
                ),
                $this->snapshot($ticket),
            );

            $scan = $this->repository->recordScan(
                $ticket,
                $deviceId,
                result: $outcome->result,
                mode: ScanMode::OFFLINE_SYNC,
                clientScanId: $clientScanId,
                // Хеш бандла попадает в метаданные только когда он был: null
                // превратился бы в JSON-null и сделал бы «сканов без бандла»
                // неотличимыми от «сканов с бандлом неизвестного хеша».
                metadata: $bundleHash === null ? null : ['bundle_hash' => $bundleHash],
            );

            if ($outcome->result === ScanOutcome::CONFLICT_REVOKED) {
                // §44: person is inside, ticket was refunded/revoked/expired —
                // record the conflict honestly by revoking, never mark `used`.
                $ticket = $this->repository->revoke($ticket, (string) $outcome->reason);
            } elseif ($outcome->resultingStatus !== null && $ticket->status !== $outcome->resultingStatus) {
                $ticket->update([
                    'status' => $outcome->resultingStatus,
                    'used_at' => $scannedAt ? \Carbon\Carbon::instance($scannedAt) : now(),
                ]);
            }

            return [
                'success' => $outcome->admits || $outcome->result === ScanOutcome::CONFLICT_REVOKED,
                'message' => $outcome->reason ?? ('offline sync recorded: ' . $outcome->result),
                'result' => $outcome->result,
                'ticket' => $ticket instanceof Ticket ? $ticket->fresh() : $ticket,
                'scan' => $scan,
            ];
        });
    }

    /**
     * Verify that a bundle hash is valid for a specific device and session.
     */
    private function verifyBundleForDevice(?string $bundleHash, int $deviceId, int $sessionId): bool
    {
        // offline_bundles keys the device column as `checkin_device_id`, and
        // `expires_at` is DATETIME(6) — comparing against a raw integer or
        // inventing a `device_id` column failed silently/with SQL errors.
        $query = DB::table('offline_bundles')
            ->where('checkin_device_id', $deviceId)
            ->where('session_id', $sessionId)
            ->where('expires_at', '>', now());

        // Без хеша (sync по контракту) проверка идёт «у устройства есть живой
        // бандл на этот сеанс» — это слабее точного совпадения, но ровно так же
        // проверяемо и не даёт выдумать скан для сеанса, которого устройство
        // никогда не загружало.
        if ($bundleHash !== null) {
            $query->where('bundle_hash', $bundleHash);
        }

        return $query->first() !== null;
    }

    /**
     * Get scan history for a ticket.
     */
    public function getScanHistory(int $ticketId): array
    {
        return TicketScan::query()
            ->where('ticket_id', $ticketId)
            ->orderBy('scanned_at', 'desc')
            ->get()
            ->toArray();
    }

    /**
     * Handle concurrent scan scenario where two devices scan same ticket.
     */
    public function handleConcurrentScan(int $ticketId, int $deviceId): array
    {
        $existingScan = TicketScan::query()
            ->where('ticket_id', $ticketId)
            ->where('device_id', $deviceId)
            ->orderBy('scanned_at')
            ->first();

        if ($existingScan) {
            return [
                'success' => false,
                'message' => 'Ticket was already scanned',
                'reason' => 'ALREADY_SCANNED',
                'first_scan_at' => $existingScan->scanned_at,
                'first_device_id' => $existingScan->device_id,
            ];
        }

        return [
            'success' => false,
            'message' => 'Concurrent scan detected, please retry',
            'reason' => 'CONCURRENT_SCAN',
        ];
    }

    /**
     * Проверка арендатора для путей сканирования.
     *
     * Ожидаемая организация обязательна (план §3.1): «внутренних вызовов без
     * организации» больше не существует — каждый публичный метод службы
     * принимает арендатора явно, и забыть его — ошибка типов, а не молчаливый
     * пропуск проверки. `null` в фактической организации (бит без заказа,
     * обрыв цепочки родителя) — отказ, а не «любой арендатор».
     */
    private function belongsToOrganization(int $expectedOrganizationId, ?int $actualOrganizationId): bool
    {
        return $actualOrganizationId !== null && $expectedOrganizationId === $actualOrganizationId;
    }

    /**
     * Организация билета — через его заказ: `tickets` собственной колонки
     * `organization_id` не имеет, а `orders.organization_id` — обязательная.
     */
    private function ticketOrganizationId(object $ticket): ?int
    {
        $orderId = $ticket->order_id ?? null;

        if ($orderId === null) {
            return null;
        }

        $organizationId = DB::table('orders')->where('id', $orderId)->value('organization_id');

        return $organizationId !== null ? (int) $organizationId : null;
    }

    /** Организация сеанса — через событие (`sessions.event_id → events.organization_id`). */
    private function sessionOrganizationId(int $sessionId): ?int
    {
        $organizationId = DB::table('sessions')
            ->join('events', 'events.id', '=', 'sessions.event_id')
            ->where('sessions.id', $sessionId)
            ->value('events.organization_id');

        return $organizationId !== null ? (int) $organizationId : null;
    }

    /**
     * Build the immutable domain snapshot the evaluator decides on. Only the
     * fields the decision needs — deliberately no holder data (ТЗ §43/§44).
     */
    private function snapshot(Ticket $ticket): TicketSnapshot
    {
        $toImmutable = static fn ($dt): ?\DateTimeImmutable => $dt === null
            ? null
            : \DateTimeImmutable::createFromInterface($dt);

        return new TicketSnapshot(
            publicId: $ticket->public_id,
            status: $ticket->status ?? TicketStateMachine::ISSUED,
            sessionId: (int) $ticket->session_id,
            eventId: (int) $ticket->event_id,
            ticketNumber: (string) $ticket->ticket_number,
            usedAt: $toImmutable($ticket->used_at),
            revokedAt: $toImmutable($ticket->revoked_at),
            cancelledAt: $toImmutable($ticket->cancelled_at),
            refundedAt: $toImmutable($ticket->refunded_at),
            expiredAt: $toImmutable($ticket->expired_at),
            revokedReason: $ticket->revoked_reason,
        );
    }
}
