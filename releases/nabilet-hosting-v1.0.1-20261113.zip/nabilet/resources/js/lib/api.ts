/**
 * Единый клиент к Laravel REST API.
 *
 * Контракт: все ресурсные ответы — { data, meta? } (см. контроллеры модулей).
 * Ошибки валидации приходят как { error: { code, message, errors? } }.
 * Токен доступа (админка) кладём в localStorage, шлём как Authorization: Bearer.
 *
 * Базу не хардкодим — берём из текущего origin (сборка живёт в Laravel),
 * но даём переопределить через VITE_API_BASE_URL для dev-режима.
 */

const BASE_URL: string = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '/api/v1'

/**
 * Ошибка API в §66-конверте.
 *
 * `details` — ВСЕГДА карта «поле → сообщения» (`Record<string, string[]>`),
 * извлечённая из `error.details.fields` сервера. Единая форма важна: на неё
 * опираются и `CheckoutPage` (привязка сообщений к инпутам), и обработчики
 * холда. Раньше `request()` читал несуществующий `error.errors`, поэтому
 * `details` был `null` и серверные ошибки валидации не доходили до UI вообще.
 */
export class ApiError extends Error {
  readonly status: number
  readonly code: string | null
  readonly details: Record<string, string[]> | null

  constructor(status: number, message: string, code: string | null = null, details: Record<string, string[]> | null = null) {
    super(message)
    this.status = status
    this.code = code
    this.details = details
  }
}

export const AUTH_TOKEN_KEY = 'nabilet_admin_token'

export function getToken(): string | null {
  return localStorage.getItem(AUTH_TOKEN_KEY)
}

export function setToken(token: string | null): void {
  if (token) localStorage.setItem(AUTH_TOKEN_KEY, token)
  else localStorage.removeItem(AUTH_TOKEN_KEY)
}

/* ── Токен покупателя (витрина) ───────────────────────────────────────────
 * ПОЧЕМУ ОТДЕЛЬНЫЙ КЛЮЧ, А НЕ ТОТ ЖЕ САМЫЙ
 *   Токен — один и тот же Bearer (`user_sessions`, guard `api`), но аудиторий
 *   две: сотрудник (админка) и покупатель (витрина). Пока ключ был один,
 *   вход покупателя на витрине клал бы свой токен туда, откуда его читает
 *   guard админки (`getToken()`), и происходили две вещи сразу:
 *
 *     1. покупатель, кликнувший «Организаторам» в меню витрины, попадал на
 *        `/admin`; guard видел токен без роли admin/manager и вызывал
 *        `clearSession()` — то есть покупателя разлогинивало простым переходом
 *        по ссылке;
 *     2. вход в админку затирал бы сессию витрины, и наоборот.
 *
 *   Разделение ключей снимает оба: guard админки смотрит только на свой ключ и
 *   чужого покупателя не видит вовсе. Это тот же раскол «сотрудник /
 *   покупатель», что и на сервере (`StaffRole::isStaff()`), только на клиенте.
 */
export const CUSTOMER_TOKEN_KEY = 'nabilet_customer_token'

export function getCustomerToken(): string | null {
  try {
    return localStorage.getItem(CUSTOMER_TOKEN_KEY)
  } catch {
    return null // приватный режим — сессия живёт до перезагрузки
  }
}

export function setCustomerToken(token: string | null): void {
  try {
    if (token) localStorage.setItem(CUSTOMER_TOKEN_KEY, token)
    else localStorage.removeItem(CUSTOMER_TOKEN_KEY)
  } catch {
    /* ignore */
  }
}

/** Чья сессия предъявляется запросу. */
export type TokenAudience = 'staff' | 'customer'

/**
 * Какой токен уйдёт в `Authorization`.
 *
 * По умолчанию — токен сотрудника, если он есть: сотрудник, зашедший в витрину,
 * остаётся собой (он и есть пользователь), а вот обратный выбор сломал бы
 * админку — её запросы уходили бы под покупательским токеном и получали 403.
 *
 * Явный `preferred` нужен там, где важна именно аудитория: выход из кабинета
 * (`logoutCustomer()`) обязан отозвать сессию ПОКУПАТЕЛЯ, а не сотрудника,
 * иначе в браузере, где открыты обе сессии, кнопка «Выйти» в кабинете
 * выкидывала бы из админки.
 */
export function activeToken(preferred?: TokenAudience): { token: string | null; audience: TokenAudience | null } {
  if (preferred === 'staff') {
    const token = getToken()
    return { token, audience: token === null ? null : 'staff' }
  }
  if (preferred === 'customer') {
    const token = getCustomerToken()
    return { token, audience: token === null ? null : 'customer' }
  }

  const staff = getToken()
  if (staff) return { token: staff, audience: 'staff' }

  const customer = getCustomerToken()
  return { token: customer, audience: customer === null ? null : 'customer' }
}

/**
 * Погасить протухшую сессию — ИМЕННО ТУ, которой отвечал сервер.
 *
 * Раньше здесь был безусловный `setToken(null)`: с двумя ключами он стирал бы
 * токен сотрудника в ответ на 401 по запросу с покупательским токеном, то есть
 * разлогинивал бы вообще другую сессию.
 */
function clearTokenFor(audience: TokenAudience | null): void {
  if (audience === 'staff') setToken(null)
  else if (audience === 'customer') setCustomerToken(null)
}

/* ── Гостевой токен корзины (контракт D5: X-Cart-Token) ───────────────────
 * Корзина на сервере ключуется парой (cart_token, session_id). Без заголовка
 * сервер считает каждый запрос нового покупателя «чужой» корзиной и либо
 * создаёт новую, либо отвечает 422. Поэтому токен генерируется один раз
 * на браузере, сохраняется в localStorage и шлётся с КАЖДЫМ запросом;
 * ответный заголовок X-Cart-Token обновляет его (например, после checkout,
 * когда сервер выдаёт свежий токен под следующую корзину).
 */
export const CART_TOKEN_KEY = 'nabilet_cart_token'

/** Сгенерировать UUID v4 (crypto.randomUUID с фолбэком на crypto.getRandomValues). */
function uuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  const bytes = new Uint8Array(16)
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes)
  } else {
    for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256)
  }
  bytes[6] = (bytes[6]! & 0x0f) | 0x40
  bytes[8] = (bytes[8]! & 0x3f) | 0x80
  const hex = [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}

export function getCartToken(): string | null {
  try {
    return localStorage.getItem(CART_TOKEN_KEY)
  } catch {
    return null // приватный режим — токен живёт до перезагрузки
  }
}

export function ensureCartToken(): string {
  const existing = getCartToken()
  if (existing) return existing
  const fresh = uuid()
  try {
    localStorage.setItem(CART_TOKEN_KEY, fresh)
  } catch {
    /* ignore */
  }
  return fresh
}

export function setCartToken(token: string | null): void {
  try {
    if (token) localStorage.setItem(CART_TOKEN_KEY, token)
    else localStorage.removeItem(CART_TOKEN_KEY)
  } catch {
    /* ignore */
  }
}

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  body?: unknown
  /** Бросить ApiError вместо возврата — для «expected» 404 (например страница события по slug). */
  silent?: boolean
  /**
   * Чей токен предъявить. По умолчанию — доступный (сотрудник важнее
   * покупателя). Явно задаётся только там, где аудитория и есть смысл запроса:
   * см. `logoutCustomer()`.
   */
  as?: TokenAudience
}

export interface PageMeta {
  current_page: number
  per_page: number
  total: number
  last_page: number
}

/* ── Разбор §66-конверта ошибки ───────────────────────────────────────────
 * Один источник правды для `request()` и `upload()`. Раньше каждый разбирал
 * конверт по-своему, и они разошлись: `upload()` знал про `details.fields`,
 * а `request()` читал `error.errors`, которого сервер не отдаёт. Дублирование
 * парсинга — и есть корневая причина; поэтому вынесено в две функции ниже.
 */

/** Похоже ли значение на карту «поле → массив сообщений». */
function isFieldMap(value: object): boolean {
  const entries = Object.entries(value)
  return entries.length > 0 && entries.every(([, v]) => Array.isArray(v))
}

/**
 * Извлечь карту ошибок по полям.
 *
 * Канонический путь — `error.details.fields` (`ValidationError::toResponse()`).
 * Дополнительно принимаем `error.details` как саму карту полей (форма, которую
 * ожидает `CheckoutPage`) и устаревший `error.errors` (форма Laravel).
 */
function extractFieldErrors(payload: unknown): Record<string, string[]> | null {
  if (!payload || typeof payload !== 'object' || !('error' in payload)) return null

  const error = (payload as { error?: unknown }).error
  if (!error || typeof error !== 'object') return null
  const envelope = error as Record<string, unknown>

  const details = envelope.details
  if (details && typeof details === 'object') {
    const fields = (details as Record<string, unknown>).fields
    if (fields && typeof fields === 'object') return fields as Record<string, string[]>
    if (isFieldMap(details)) return details as Record<string, string[]>
  }

  const errors = envelope.errors
  if (errors && typeof errors === 'object') return errors as Record<string, string[]>

  return null
}

/** Машинный код (`error.code`) и человекочитаемое сообщение из конверта. */
function extractErrorMeta(payload: unknown, status: number): { message: string; code: string | null } {
  const p = payload && typeof payload === 'object' ? (payload as Record<string, unknown>) : null
  const envelope = p && p.error && typeof p.error === 'object' ? (p.error as Record<string, unknown>) : null

  const message =
    envelope && typeof envelope.message === 'string' && envelope.message !== ''
      ? envelope.message
      : typeof p?.message === 'string' && p.message !== ''
        ? p.message
        : `HTTP ${status}`

  const code = envelope && envelope.code != null ? String(envelope.code) : null

  return { message, code }
}

/** Универсальная выборка: возвращает объект { data, meta? } уже развёрнутым. */
export async function request<T = unknown>(path: string, options: ApiOptions = {}): Promise<T> {
  const { token, audience } = activeToken(options.as)
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  }
  if (token) headers.Authorization = `Bearer ${token}`
  // Контракт D5: все обращения к корзине — с гостевым токеном покупателя.
  // Для `/cart` токен ещё и СОЗДАЁТСЯ при необходимости: первый запрос нового
  // покупателя должен получить свою корзину, а не 422.
  //
  // Остальным маршрутам токен отдаём, только если он уже есть. Это нужно
  // `POST /payments`: сервер доказывает право на гостевой заказ именно этим
  // заголовком (`PaymentController::mayPay()` — у гостевого заказа
  // `user_id = NULL`, проверить владельца больше нечем), и без него оплата
  // отвечала 404 «чужой заказ». Плодить токены на запросах админки при этом
  // не нужно — поэтому `getCartToken()`, а не `ensureCartToken()`.
  if (path.startsWith('/cart')) {
    headers['X-Cart-Token'] = ensureCartToken()
  } else {
    const guestToken = getCartToken()
    if (guestToken) headers['X-Cart-Token'] = guestToken
  }

  let res: Response
  try {
    res = await fetch(`${BASE_URL}${path}`, {
      method: options.method ?? 'GET',
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    })
  } catch {
    throw new ApiError(0, 'Нет соединения с сервером. Проверьте связь.')
  }

  // Сервер мог выдать новый токен (первый запрос без валидного) — сохраняем.
  const echoed = res.headers.get('X-Cart-Token')
  if (echoed && echoed !== getCartToken()) setCartToken(echoed)

  if (res.status === 204) return undefined as T

  let payload: unknown = null
  try {
    payload = await res.json()
  } catch {
    payload = null
  }

  if (!res.ok) {
    // 401 → протухла сессия; гасим ИМЕННО ТУ, которой отвечал сервер, и даём
    // странице решить (редирект на логин).
    const { message, code } = extractErrorMeta(payload, res.status)
    if (res.status === 401 && code !== 'bad_credentials') clearTokenFor(audience)
    throw new ApiError(res.status, message, code, extractFieldErrors(payload))
  }

  return payload as T
}

/** GET /path → { data, meta? } */
export async function get<D, M extends PageMeta = PageMeta>(path: string, silent = false): Promise<{ data: D; meta?: M }> {
  return request<{ data: D; meta?: M }>(path, { silent })
}

/** POST/PUT/PATCH/DELETE → { data } */
export async function send<D>(path: string, method: 'POST' | 'PUT' | 'PATCH' | 'DELETE', body?: unknown): Promise<{ data: D }> {
  return request<{ data: D }>(path, { method, body })
}

/**
 * Отправка FormData (multipart) — например, загрузка файла афиши на
 * POST /events с полем poster_file. Не сериализует тело как JSON и не ставит
 * Content-Type (браузер сам добавит boundary). Ошибки парсятся так же, как в
 * request(): ApiError с details.fields для привязки к конкретным инпутам.
 */
export async function upload<D>(path: string, formData: FormData, method: 'POST' | 'PATCH' = 'POST'): Promise<{ data: D }> {
  const { token, audience } = activeToken()
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (token) headers.Authorization = `Bearer ${token}`

  let res: Response
  try {
    res = await fetch(`${BASE_URL}${path}`, { method, headers, body: formData })
  } catch {
    throw new ApiError(0, 'Нет соединения с сервером. Проверьте связь.')
  }

  let payload: unknown = null
  try {
    payload = await res.json()
  } catch {
    payload = null
  }

  if (!res.ok) {
    const { message, code } = extractErrorMeta(payload, res.status)
    if (res.status === 401 && code !== 'bad_credentials') clearTokenFor(audience)
    throw new ApiError(res.status, message, code, extractFieldErrors(payload))
  }

  return payload as { data: D }
}

export const api = {
  get,
  send,
  upload,
}