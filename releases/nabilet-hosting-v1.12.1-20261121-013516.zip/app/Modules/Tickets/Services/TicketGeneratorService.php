<?php

declare(strict_types=1);

namespace Nabilet\Modules\Tickets\Services;

use Illuminate\Support\Facades\Log;
use Nabilet\Core\Support\AssetUrl;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Core\Support\Money;
use Nabilet\Core\Support\RuText;
use Nabilet\Modules\Tickets\Domain\Qr\QrCapacityException;
use Nabilet\Modules\Tickets\Domain\Qr\QrEncoder;
use Nabilet\Modules\Tickets\Domain\Qr\QrPngRenderer;
use Nabilet\Modules\Tickets\Domain\TicketPalette;
use Nabilet\Modules\Tickets\Models\Ticket;
use Nabilet\Modules\Tickets\Models\TicketTemplate;

/**
 * Builds the data contract for the customer-facing ticket email.
 *
 * Ticket issuance and QR signing are owned by TicketService. This class only
 * reads an issued ticket; it never invents a booking model, unsigned QR, or
 * legacy hall schema.
 *
 * QR-КАРТИНКА РИСУЕТСЯ ЛОКАЛЬНО
 *
 * Раньше здесь стояло «QR raster rendering is intentionally not attempted».
 * Это было верно ровно до тех пор, пока не появился `Domain/Qr/QrEncoder`:
 * подписанный payload нельзя отдавать сервису картинок (это утечка пропуска),
 * а пакета QR в `vendor/` нет, поэтому кодировщик написан свой и сверяется с
 * независимой реализацией побитово (см. `QrEncoderGoldenMasterTest`).
 *
 * Картинка отдаётся как `data:image/png;base64,…` — единственный способ
 * вложить код в письмо, не отдавая payload наружу. Ограничение честное и
 * известное: Gmail вырезает `data:`-URI в `src`, поэтому QR — удобство для
 * клиентов, которые их показывают, а гарантированный путь остаётся прежним:
 * текстовый payload рядом и кнопка на страницу с билетом.
 *
 * МАКЕТ БИЛЕТА
 *
 * Раньше `events.ticket_template_id` существовал, но не влиял ни на что:
 * назначение макета не читал ни один потребитель, поэтому «индивидуальный
 * билет под мероприятие» оставался настройкой без последствий. Теперь макет
 * резолвится здесь (`TicketTemplateResolver`) и уезжает в письмо в виде
 * палитры — см. `TicketPalette` о том, почему переносится только цвет, а не
 * холст целиком.
 *
 * Резолвер инжектится необязательным: у класса есть потребитель, который
 * собирает его напрямую (`new TicketGeneratorService()` в тесте контракта на
 * несохранённом билете). Для несохранённого билета резолв пропускается —
 * читать `events.ticket_template_id` не из чего.
 */
class TicketGeneratorService
{
    public function __construct(
        private readonly ?TicketTemplateResolver $templates = null,
    ) {}

    /**
     * @return array{
     *   order_id:int,
     *   ticket_number:string,
     *   event_name:string,
     *   event_date:string,
     *   venue_name:string,
     *   seats:string,
     *   price:\Nabilet\Core\Support\Money,
     *   currency:string,
     *   customer_name:string,
     *   customer_email:string,
     *   qr_payload:string,
     *   unique_hash:string,
     *   poster_url:string|null,
     *   ticket_url:string,
     *   qr_data_uri:string|null,
     *   template:array{id:int,name:string,format:string,width:int,height:int,background_color:string,accent_color:string}|null
     * }
     */
    public function generateTicketData(Ticket $ticket): array
    {
        return app(OrganizationContext::class)->withoutScope(
            fn (): array => $this->generateTicketDataScoped($ticket)
        );
    }

    private function generateTicketDataScoped(Ticket $ticket): array
    {
        $ticket->loadMissing([
            'order.user',
            'orderItem',
            'event',
            'session.venue',
            'seat.row',
            'standingZone',
        ]);

        $order = $ticket->order;
        if ($order === null) {
            throw new \LogicException('Cannot prepare a ticket email without its order.');
        }
        if (! is_string($ticket->qr_payload) || $ticket->qr_payload === '') {
            throw new \LogicException('Cannot email a ticket without its signed QR payload.');
        }

        $event = $ticket->event;
        $session = $ticket->session;
        $seat = $ticket->seat;
        $standingZone = $ticket->standingZone;
        // Подпись места без дублирования ряда.
        //
        // `seat.label` в схеме зала часто уже содержит ряд («Ряд 2 Место 1»),
        // и прежняя склейка «имя ряда / label» давала на билете «Ряд 2 / Ряд 2
        // Место 1». Сравниваем по вхождению: если ряд уже назван в подписи —
        // префикс не нужен.
        $seatLabel = 'Свободная рассадка';

        if ($seat !== null) {
            $rowName = (string) ($seat->row?->name ?? '');
            $label = (string) ($seat->label !== null && $seat->label !== '' ? $seat->label : 'Место ' . $seat->number);
            $needsRow = $rowName !== '' && ! str_contains($label, $rowName);

            $seatLabel = $needsRow ? $rowName . ' / ' . $label : $label;
        } elseif ($standingZone !== null) {
            $seatLabel = (string) $standingZone->name;
        }

        $minorAmount = (int) ($ticket->orderItem?->unit_price ?? 0);

        // Макет и палитра. `$event` может быть null (билет старой базы без
        // события) — тогда оформления нет, и это штатно: билет уходит в
        // стандартном виде, а не остаётся без письма.
        $template = $this->templateFor($ticket);
        $palette = TicketPalette::fromTemplateJson($template?->template_json);

        return [
            'order_id' => (int) $order->id,
            'ticket_number' => (string) $ticket->ticket_number,
            'event_name' => (string) ($event?->title ?? 'Мероприятие'),
            'event_date' => RuText::stamp($session?->starts_at) ?? '',
            // Время отдельной строкой: конструктор предлагает `{{event.time}}`, и
            // без этого поля переменная подставлялась пустой строкой — дизайнер
            // видел на макете время, а покупатель не видел ничего.
            'event_time' => RuText::clock($session?->starts_at) ?? '',
            'venue_name' => (string) ($session?->venue?->name ?? ''),
            'seats' => $seatLabel,
            // Ряд и место по отдельности — для макетов, где они стоят в разных
            // блоках. `seats` остаётся склеенной строкой для «одной строкой».
            'seat_row' => (string) ($seat?->row?->name ?? ''),
            'seat_number' => (string) ($seat?->number ?? ''),
            // Цена — СОБСТВЕННОСТЬ Money. Раньше здесь стояло вещественное
            // деление minor-единиц на сто, и каждый потребитель (письмо, PDF)
            // заново форматировал результат — копия правила конверсии
            // minor→десятичное, которая молча расходится с владельцем.
            'price' => Money::of($minorAmount, (string) ($order->currency ?? 'RUB')),
            'currency' => (string) ($order->currency ?? 'RUB'),
            'customer_name' => (string) ($order->customer_name ?? $order->user?->name ?? 'Покупатель'),
            'customer_email' => (string) $order->customer_email,
            'qr_payload' => (string) $ticket->qr_payload,
            'unique_hash' => (string) $ticket->public_id,
            // Афиша — из мероприятия, не из макета: макет описывает раскладку,
            // а картинка у каждого мероприятия своя (см. план §4.2). Постер
            // лежит в `storage/app/public`, поэтому URL идёт через `/storage/`.
            'poster_url' => AssetUrl::storageOrNull($event?->poster),
            'ticket_url' => $this->ticketUrl(),
            // Готовый QR как data-URI. Один источник для ОБОИХ писем — и для
            // живого пути (`OrderNotificationData`), и для шаблона
            // `tickets::email.ticket`: расхождение между этими каналами уже
            // один раз оставляло покупателя без оформления.
            'qr_data_uri' => $this->qrDataUri((string) $ticket->qr_payload),
            'template' => $template === null ? null : [
                'id' => (int) $template->id,
                'name' => (string) $template->name,
                'format' => (string) ($template->format ?? 'mobile'),
                'width' => (int) ($template->width ?? 0),
                'height' => (int) ($template->height ?? 0),
                'background_color' => $palette->background,
                'accent_color' => $palette->accent,
            ],
        ];
    }

    /**
     * Макет билета для этого билета, либо `null`.
     *
     * Несохранённый билет резолвить не от чего: `events.ticket_template_id`
     * читается из БД по `event_id`, а у модели «в памяти» такого id нет.
     * Проверка не косметическая — без неё прямое `new TicketGeneratorService()`
     * на несохранённой модели уходило бы в базу.
     */
    private function templateFor(Ticket $ticket): ?TicketTemplate
    {
        if (! $ticket->exists) {
            return null;
        }

        return $this->templates()->resolveForTicket($ticket);
    }

    /**
     * Резолвер из контейнера, если он не был инжектнут.
     *
     * `TicketTemplateResolver` без зависимостей, поэтому контейнер собирает его
     * без настройки; ленивое разрешение нужно только для прямого
     * `new TicketGeneratorService()`.
     */
    private function templates(): TicketTemplateResolver
    {
        return $this->templates ?? app(TicketTemplateResolver::class);
    }

    /**
     * Ссылка на страницу «Мои билеты» в витрине.
     *
     * Витрина живёт на history-роутинге: `/tickets` — настоящий адрес,
     * который сервер отдаёт на белом списке путей (`routes/web.php`).
     * Именно сюда ведёт кнопка в письме; QR рисует браузер покупателя, поэтому
     * подписанный payload не покидает его устройство. До 1.2.0 путь собирался
     * hash-формой `/#/tickets` — витрина отдавалась только на `/`; старые
     * письма продолжает принимать мост в `router/index.ts`.
     *
     * ЧЕРЕЗ `url()`, А НЕ `rtrim(config('app.url'),'/') . '/…'`. Склейка
     * корня вручную стояла в четырёх местах (`AccountMailService`,
     * `ReferralService`, `NotifyRaffleWinnersJob` и здесь), и каждое повторяло
     * одно и то же правило: «убрать завершающий слэш у `app.url`, приписать
     * путь». `url()` делает это сам, учитывает `forceRootUrl`/`forceScheme`
     * и в отсутствие запроса (очередь, консоль) берёт тот же `app.url`.
     * `ReferralTest` и `AccountRecoveryTest` сравнивают ссылки именно с
     * формой `url('/…')` — то есть тесты знали правильный ответ, а код его
     * не использовал.
     */
    private function ticketUrl(): string
    {
        return url('/tickets');
    }

    /**
     * QR билета как `data:image/png;base64,…`, либо `null`.
     *
     * `null` — не ошибка, а деградация: payload может не влезть в
     * поддерживаемые версии (в реальности — нет, запас двукратный). В этом
     * случае письмо обязано уйти как раньше, с текстовым payload, поэтому
     * исключение ловится здесь, а не всплывает до отправителя. Обратное —
     * «письмо без билета из-за картинки» — недопустимо.
     */
    private function qrDataUri(string $payload): ?string
    {
        try {
            return QrPngRenderer::dataUri(QrEncoder::encode($payload));
        } catch (QrCapacityException $e) {
            Log::warning('QR билета не построен — письмо уйдёт с текстовым payload.', [
                'exception' => $e::class,
                'message' => $e->getMessage(),
            ]);

            return null;
        }
    }
}
