<?php

declare(strict_types=1);

namespace Nabilet\Modules\Embed\Http\Controllers;

use Nabilet\Core\Support\Paging;
use Nabilet\Core\Tenancy\OrganizationContext;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Nabilet\Core\Errors\AuthError;
use Nabilet\Core\Errors\NotFoundError;
use Nabilet\Core\Errors\ValidationError;
use Nabilet\Core\Idempotency\IdempotencyHeader;
use Nabilet\Modules\Cart\Http\Resources\CartResource;
use Nabilet\Modules\Cart\Models\Cart;
use Nabilet\Modules\Cart\Services\CartCheckoutService;
use Nabilet\Modules\Cart\Services\CartItemService;
use Nabilet\Modules\Cart\Services\CartService;
use Nabilet\Modules\Cart\Support\CartToken;
use Nabilet\Modules\Embed\Services\EmbedAccessService;
use Nabilet\Modules\Events\Http\Resources\EventResource;
use Nabilet\Modules\Events\Models\Event;
use Nabilet\Modules\Events\Repositories\EventRepository;
use Nabilet\Modules\Inventory\Models\InventoryItem;
use Nabilet\Modules\Inventory\Support\StageSide;
use Nabilet\Modules\Orders\Http\Resources\OrderResource;
use Nabilet\Modules\Orders\Models\Order;
use Nabilet\Modules\Payments\Models\Payment;
use Nabilet\Modules\Payments\Services\PaymentService;
use Nabilet\Modules\Sessions\Models\Session;
use Nabilet\Modules\Venues\Models\HallSchemaVersion;

/**
 * The seven `/api/v1/embed/*` operations the contract declares.
 *
 * These are the only endpoints in the application that are authorized by
 * something other than a user session: an embed widget runs on a third party's
 * site, in a browser that has no NABILET account and no NABILET cookie. The
 * caller is identified by a capability pair — the `embed_token` query parameter
 * (a scoped `api_keys` row) and the `Origin` header — and every check lives in
 * `EmbedAccessService`, which this controller calls first in every method.
 *
 * NO BUSINESS LOGIC HERE, DELIBERATELY.
 *   Seats are reserved, carts are keyed and orders are created by the same
 *   services the storefront uses (`CartService`, `CartItemService`,
 *   `CartCheckoutService`, `PaymentService`). A second implementation of
 *   "reserve a seat" written for the embed surface would be a second place for
 *   the seat-hold invariant to be broken, and the first one is already hard
 *   enough. What this class adds is exactly two things: the §18 gate, and the
 *   contract's response shape.
 *
 * WHY THE RESPONSES ARE MAPPED BY HAND INSTEAD OF REUSING THE MODULE RESOURCES.
 *   `CartResource` and `EventResource` are reused where they already match the
 *   contract. The session and payment payloads are not, because the module
 *   resources describe a different surface: `SessionResource` omits
 *   `event_id`/`venue_id`/`hall_id`/`schema_version_id`, which `Session` requires,
 *   and `PaymentResource` omits `order_id`, which `Payment` names. Stretching a
 *   shared resource to satisfy both shapes is how one surface's response starts
 *   changing when the other is edited.
 *
 * THE CHECKOUT TOKEN HAS TWO NAMES, ON PURPOSE.
 *   The contract calls the guest capability `checkout_token` and passes it in
 *   `X-Checkout-Token`. The storefront has always called the same value
 *   `cart_token` and passed it in `X-Cart-Token` — it is one column,
 *   `carts.cart_token`. The embed surface accepts either header and returns the
 *   value under both names, so a widget embedded inside the storefront shares one
 *   cart with the page around it instead of creating a second one.
 */
final class EmbedController extends Controller
{
    /** The contract's name for the guest capability header. */
    private const CHECKOUT_HEADER = 'X-Checkout-Token';

    /** The contract's name for the replay-protection header. */
    private const IDEMPOTENCY_HEADER = IdempotencyHeader::NAME;

    public function __construct(
        private readonly EmbedAccessService $access,
        private readonly CartService $carts,
        private readonly CartItemService $cartItems,
        private readonly CartCheckoutService $checkout,
        private readonly PaymentService $payments,
        private readonly EventRepository $eventRepository,
    ) {}

    // ── Catalogue ────────────────────────────────────────────────────────────

    /**
     * `GET /api/v1/embed/events/{event}` — the event page inside the widget.
     */
    public function showEvent(Request $request, int $event): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $model = $this->access->event($event, $organizationId);

        // `sessions.hall` лениво читается ресурсом (`hall?->name`), а зал —
        // скоупнутая модель: грузим под bypass вместе с venue.
        app(OrganizationContext::class)->withoutScope(
            fn () => $model->load(['category', 'translations', 'sessions.hall', 'sessions.venue'])
        );

        // Availability is attached as an attribute BEFORE rendering: without it
        // the resource's fallback lazy-loads `InventoryItem` — a scoped model,
        // and the widget has no tenant context (capability key checked above).
        $this->eventRepository->hydrateAvailableSeats(new \Illuminate\Database\Eloquent\Collection([$model]));

        return response()->json(['data' => new EventResource($model)]);
    }

    /**
     * `GET /api/v1/embed/events/{event}/sessions` — the schedule inside the widget.
     */
    public function listEventSessions(Request $request, int $event): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $model = $this->access->event($event, $organizationId);

        $perPage = Paging::limit((int) $request->get('per_page', 20), 20, 100);

        // Сеансы — скоупнутые чтения (тридцать шестая модель): у виджета нет
        // тенант-контекста (embed-ключ, организация проверена выше) —
        // выборка расписания в bypass; событие выше уже решено lookup'ом.
        $sessions = app(OrganizationContext::class)->withoutScope(
            fn () => Session::query()
                ->where('event_id', $model->id)
                ->orderBy('starts_at')
                ->paginate($perPage)
        );

        return response()->json([
            'data' => $sessions->getCollection()
                ->map(fn (Session $session): array => $this->sessionPayload($session))
                ->all(),
            'meta' => [
                'current_page' => $sessions->currentPage(),
                'per_page' => $sessions->perPage(),
                'total' => $sessions->total(),
                'last_page' => $sessions->lastPage(),
            ],
        ]);
    }

    /**
     * `GET /api/v1/embed/sessions/{session}/seatmap` — geometry plus inventory.
     *
     * The whole hall is returned, not a page of it: a seat map that arrives in
     * pages is not a seat map. `InventoryItem` rows are the same rows
     * `GET /api/v1/inventory?session_id=` returns, so a widget and the storefront
     * see the same availability — including `available_quantity`, which is what
     * makes a half-sold standing zone render correctly.
     */
    public function seatmap(Request $request, int $session): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $model = $this->access->session($session, $organizationId);

        // Версия схемы зала — скоупнутая модель (тридцатая): у виджета нет
        // тенант-контекста (capability-ключ, организация проверена выше) —
        // загружаем в bypass. Геометрия дальше собирается из её JSON-колонки.
        app(OrganizationContext::class)->withoutScope(
            fn () => $model->load('schemaVersion')
        );

        // Инвентарь сеанса — публичная карта зала: embed-запрос идёт по
        // capability ключа (организация проверена authorize выше), тенант-
        // контекста у виджета нет — в bypass.
        $inventory = app(OrganizationContext::class)->withoutScope(
            fn () => InventoryItem::query()
                ->with(['seat.row.sector', 'standingZone'])
                ->where('session_id', $model->id)
                ->orderBy('id')
                ->get()
        );

        // Те же вычисляемые поля, что отдаёт витринный GET /inventory: без
        // row_number/sector_name рядная карта и подписи зон в виджете пустые.
        $inventory->each(function (InventoryItem $item): void {
            $seat = $item->seat;
            if ($seat !== null) {
                $seat->setAttribute('row_number', $seat->row?->number);
                $seat->setAttribute('sector_name', $seat->row?->sector?->name);
            }
        });

        // Фронт виджета переходит с витринного `/inventory` на embed-ручку без
        // переписывания парсера: отдаём тот же конверт {data, meta}, плюс
        // исторические поля `inventory`/`schema` для старых клиентов.
        $items = $inventory->map(fn (InventoryItem $item): array => $item->toArray())->all();
        $total = count($items);
        $maxPerOrder = max(1, (int) config('nabilet.checkout.max_items_per_order', 10));
        $schemaJson = $model->schemaVersion?->schema_json;
        $stageSide = StageSide::fromSchema(is_array($schemaJson) ? $schemaJson : null);

        return response()->json([
            'data' => [
                'data' => $items,
                'current_page' => 1,
                'per_page' => max(1, $total),
                'total' => $total,
                'last_page' => 1,
            ],
            'meta' => [
                'current_page' => 1,
                'per_page' => max(1, $total),
                'total' => $total,
                'last_page' => 1,
                'max_tickets_per_order' => $maxPerOrder,
                'stage_side' => $stageSide,
            ],
            'session' => $this->sessionPayload($model),
            'schema' => $this->schemaPayload($model->schemaVersion),
            'inventory' => $inventory
                ->map(fn (InventoryItem $item): array => [
                    'id' => $item->public_id,
                    'session_id' => $item->session_id,
                    'type' => $item->type,
                    'seat_id' => $item->seat_id,
                    'standing_zone_id' => $item->standing_zone_id,
                    'price_amount' => $item->price_amount,
                    'currency' => $item->currency,
                    'capacity' => $item->capacity,
                    'available_quantity' => $item->available_quantity,
                    'status' => $item->status,
                ])
                ->all(),
        ]);
    }

    // ── Cart ─────────────────────────────────────────────────────────────────

    /**
     * `POST /api/v1/embed/carts` — open (or reopen) the guest's cart for a session.
     *
     * 201 with `checkout_token` required by the contract's `CreateCartResponse`.
     * The token is echoed back under both names and also in the `X-Cart-Token`
     * response header, so the widget can store whichever it was built against.
     *
     * The session is resolved through `EmbedAccessService`, which is what refuses
     * a session of another organization and a session of a non-published event.
     */
    public function createCart(Request $request): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $validated = $request->validate([
            // No `integer` rule: `carts.session_id` is a string column and
            // `Session::findOrFailBySessionId()` accepts the ULID `public_id` as
            // well as the numeric key. The lookup itself is fail-closed — see
            // `EmbedAccessService::findByReference()`.
            'session_id' => ['bail', 'required', 'string'],
        ]);

        $session = $this->access->session($validated['session_id'], $organizationId);

        $token = $this->checkoutToken($request) ?? CartToken::generate();

        // `$request->user('api')` — вошедший покупатель, если виджет открыт под
        // Bearer-токеном: ранний доступ клуба (фаза 3b) работает и здесь.
        // Гвард явный — пути embed публичные, дефолтный гвард `web` (сессия).
        $cart = $this->carts->getOrCreateCart((string) $session->id, $token, $request->user('api'));

        // Позиции — дети корзины (capability-токен): витрина-эмбед отвечает
        // гостю без тенант-контекста, eager `items` на скоупе `CartItem`
        // отказал бы. Корзина только что создана этой же сессией виджета.
        app(OrganizationContext::class)->withoutScope(
            fn () => $cart->load('items.inventoryItem.seat.row.sector')
        );

        return response()
            ->json([
                'data' => new CartResource($cart),
                'checkout_token' => $token,
            ], 201)
            ->header(CartToken::HEADER, $token);
    }

    /**
     * `POST /api/v1/embed/carts/{cart}/items` — reserve a seat.
     *
     * The session is NOT in the body: it comes from the cart, which is the only
     * place that knows it. That is also why the cart is resolved before the body
     * is validated — a caller who does not hold the cart learns nothing about it.
     */
    public function addCartItem(Request $request, string $cart): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $token = $this->requireCheckoutToken($request);

        $model = $this->access->cart($cart, $token, $organizationId);

        // Same source as `CartController::addItem()`: config/nabilet.php →
        // CHECKOUT_MAX_ITEMS. A literal here would be the second copy of the
        // anti-scalping limit, and the one that goes stale.
        $maxPerOrder = max(1, (int) config('nabilet.checkout.max_items_per_order', 10));

        $validated = $request->validate([
            // Seatmap отдаёт ULID в поле `id`, а витринный чекаут — числовой
            // внутренний id. Принимаем оба: иначе виджет не мог бы зарезервировать
            // то, что только что показал.
            'inventory_item_id' => ['bail', 'required', 'string', 'max:64'],
            'quantity' => ['required', 'integer', 'min:1', 'max:' . $maxPerOrder],
        ]);

        $reference = trim((string) $validated['inventory_item_id']);
        $itemId = ctype_digit($reference)
            ? (int) $reference
            : (int) (app(OrganizationContext::class)->withoutScope(
                fn () => InventoryItem::query()->where('public_id', $reference)->value('id')
            ) ?? 0);
        if ($itemId < 1) {
            throw new NotFoundError('InventoryItem', $reference);
        }

        $this->cartItems->addItem(
            (string) $model->session_id,
            $itemId,
            (int) $validated['quantity'],
            $token,
            $request->user('api'),
        );

        // Корзина с позициями — дети capability-токена: витрина-эмбед отвечает
        // гостю без тенант-контекста, перечитывание после добавления — в bypass.
        $fresh = app(OrganizationContext::class)->withoutScope(
            fn () => Cart::query()->with('items.inventoryItem.seat.row.sector')->find($model->id)
        );

        return response()->json(['data' => new CartResource($fresh)], 201);
    }

    // ── Checkout ─────────────────────────────────────────────────────────────

    /**
     * `POST /api/v1/embed/orders` — turn the cart into an order.
     *
     * `cart_id` is the ULID `public_id` the create-cart response returned (the
     * numeric key is accepted too — see `EmbedAccessService::findByReference()`).
     */
    public function createOrder(Request $request): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $token = $this->requireCheckoutToken($request);

        $validated = $request->validate([
            'cart_id' => ['bail', 'required'],
            'customer_email' => ['required', 'email:rfc', 'max:255'],
            // Повтор ввода адреса — защита от опечатки (см. `CartController::checkout`).
            // `nullable`: embed-виджет поле не шлёт, для него контракт прежний.
            'customer_email_confirmation' => ['nullable', 'string', 'same:customer_email'],
            'customer_name' => ['nullable', 'string', 'max:255'],
            'customer_phone' => ['nullable', 'string', 'max:32'],
            'promo_code' => ['nullable', 'string', 'max:64'],
            // Те же поля, что принимает витринный /cart/checkout: без них
            // бонусы и рефералы в рамке молча перестали бы работать после
            // переключения денежного флоу на embed-ручки.
            'bonus_amount' => ['nullable', 'integer', 'min:0', 'max:100000000'],
            'referral_code' => ['nullable', 'string', 'max:32'],
        ]);

        // An array/object in `cart_id` is a client error, not a 500 on a cast —
        // the same guard `PaymentController::store()` carries for `order_id`.
        if (! is_scalar($validated['cart_id'])) {
            throw new ValidationError([
                'cart_id' => ['The cart id must be a string or an integer.'],
            ]);
        }

        $cart = $this->access->cart((string) $validated['cart_id'], $token, $organizationId);

        $result = $this->checkout->checkout((string) $cart->session_id, [
            'customer_name' => $validated['customer_name'] ?? null,
            'customer_email' => $validated['customer_email'],
            'customer_phone' => $validated['customer_phone'] ?? null,
            'promo_code' => $validated['promo_code'] ?? null,
            'bonus_amount' => (int) ($validated['bonus_amount'] ?? 0),
            'referral_code' => $validated['referral_code'] ?? null,
        ], $token);

        // Заказ только что создан чекаутом этой корзины: чтение для ответа —
        // в bypass, у гостя контекста нет (дети корзины, доступ решён
        // EmbedAccessService выше).
        $order = app(OrganizationContext::class)->withoutScope(
            fn () => Order::query()
                ->with(['items', 'payments'])
                ->where('public_id', $result['order_id'])
                ->firstOrFail()
        );

        return response()->json(['data' => new OrderResource($order)], 201);
    }

    /**
     * `POST /api/v1/embed/orders/{order}/payment` — start paying for the order.
     *
     * §18's fifth rule, "payment capability", is decided here rather than
     * assumed: the order must belong to the token's organization (checked by
     * `EmbedAccessService::order()`) AND must be payable by the caller, which for
     * a guest means holding the cart the order was created from. That is the same
     * rule `PaymentController::mayPay()` applies to the storefront, restated
     * against the checkout token; without it, any valid embed token could open a
     * payment for any order of the same organization.
     *
     * The refusal is 404, not 403: `order_id` alone must not confirm that an order
     * exists — see `NotFoundError`.
     */
    public function createPayment(Request $request, string $order): JsonResponse
    {
        $organizationId = $this->access->authorize($request);

        $token = $this->requireCheckoutToken($request);

        $model = $this->access->order($order, $organizationId);

        if ($model->cart_id === null || ! $this->callerHoldsCart((int) $model->cart_id, $token)) {
            throw new NotFoundError('Order', $order);
        }

        $result = $this->payments->initiatePayment((int) $model->id, [
            'idempotency_key' => $this->idempotencyKey($request),
        ]);

        return response()->json([
            'data' => $this->paymentPayload($result['payment'], $model),
        ], 201);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /**
     * The guest capability, under whichever name the caller used.
     *
     * `X-Checkout-Token` is the contract's name and is tried first;
     * `X-Cart-Token` is the storefront's and is accepted so a widget embedded in
     * the storefront shares the page's cart. Both are normalised identically
     * (`CartToken::normalize()`: length and alphabet), so neither can smuggle a
     * value the other would have refused.
     */
    private function checkoutToken(Request $request): ?string
    {
        return CartToken::normalize($request->header(self::CHECKOUT_HEADER))
            ?? CartToken::fromRequest($request);
    }

    /**
     * The checkout token, or a 403 explaining that it is required.
     *
     * 403 rather than 422: the token is a capability, exactly like the embed
     * token, and the embed surface answers every capability failure with 403 and a
     * distinct code so the widget can tell "you forgot the token" from "the token
     * is not mine". `EMBED_CHECKOUT_TOKEN_REQUIRED` is deliberately separate from
     * `EMBED_TOKEN_INVALID` — they are two different credentials.
     */
    private function requireCheckoutToken(Request $request): string
    {
        $token = $this->checkoutToken($request);

        if ($token === null) {
            throw new AuthError(
                'Embed cart and checkout requests must present their checkout token.',
                'EMBED_CHECKOUT_TOKEN_REQUIRED',
                403,
                ['header' => self::CHECKOUT_HEADER],
            );
        }

        return $token;
    }

    /** Does the caller hold the cart this order was created from? */
    private function callerHoldsCart(int $cartId, string $token): bool
    {
        // Токен корзины — capability гостя: чтение `Cart` в bypass, владение
        // решает сравнение токена в фильтре — чужая корзина тоже «не держится».
        return app(OrganizationContext::class)->withoutScope(
            fn () => Cart::query()
                ->where('id', $cartId)
                ->where('cart_token', $token)
                ->exists()
        );
    }

    /**
     * The replay-protection key, from the header the contract names or from the
     * body the storefront sends.
     *
     * The contract marks `Idempotency-Key` required on the three embed writes, and
     * since S-07 it is genuinely enforced: `PaymentService::initiatePayment()`
     * refuses to create a payment without a key (422), so this endpoint cannot
     * start a second payment for a double-submitted widget. The header is tried
     * first because it is the contract's name; the body field is accepted because
     * the storefront sends it that way.
     */
    private function idempotencyKey(Request $request): ?string
    {
        $key = trim((string) $request->header(self::IDEMPOTENCY_HEADER));

        if ($key === '') {
            $key = trim((string) $request->input('idempotency_key', ''));
        }

        return $key === '' ? null : $key;
    }

    /**
     * The contract's `Session` shape, with dates in ISO 8601.
     *
     * Hand-mapped rather than returned as the model: `Session`'s casts serialise
     * `starts_at` as `Y-m-d H:i:s.u`, while the contract declares `format:
     * date-time`. The storefront tolerates the former; a generated client built
     * from the contract does not.
     */
    private function sessionPayload(Session $session): array
    {
        return [
            'id' => $session->id,
            'public_id' => $session->public_id,
            'event_id' => $session->event_id,
            'venue_id' => $session->venue_id,
            'hall_id' => $session->hall_id,
            'schema_version_id' => $session->schema_version_id,
            'starts_at' => $session->starts_at?->toIso8601String(),
            'ends_at' => $session->ends_at?->toIso8601String(),
            'sales_start_at' => $session->sales_start_at?->toIso8601String(),
            'sales_end_at' => $session->sales_end_at?->toIso8601String(),
            'timezone' => $session->timezone,
            'status' => $session->status,
        ];
    }

    /**
     * The contract's `HallSchemaVersion` shape.
     *
     * `schema_json` is published as `schema` because that is the name the contract
     * gives the payload — the column and the field differ, and the mapping has to
     * live somewhere. `id` is the ULID `public_id`, matching `SessionResource`'s
     * view of the same row.
     */
    private function schemaPayload(?HallSchemaVersion $schema): ?array
    {
        if ($schema === null) {
            return null;
        }

        return [
            'id' => $schema->public_id,
            'hall_id' => $schema->hall_id,
            'version' => $schema->version,
            'status' => $schema->status,
            'width' => $schema->width,
            'height' => $schema->height,
            'background_url' => $schema->background_url,
            'schema' => $schema->schema_json,
            'published_at' => $schema->published_at?->toIso8601String(),
        ];
    }

    /**
     * The contract's `Payment` shape.
     *
     * `order_id` is the order's ULID, not `payments.order_id` (a BIGINT): the
     * contract types the field as a string and every other identifier it exposes
     * is the external one. `PaymentResource` cannot be reused for this — it
     * carries no `order_id` at all.
     */
    private function paymentPayload(Payment $payment, Order $order): array
    {
        return [
            'id' => $payment->public_id,
            'order_id' => $order->public_id,
            'provider' => $payment->provider,
            'provider_payment_id' => $payment->provider_payment_id,
            'amount' => $payment->amount,
            'currency' => $payment->currency,
            'status' => $payment->status,
            'payment_url' => $payment->payment_url,
            'created_at' => $payment->created_at?->toIso8601String(),
            'paid_at' => $payment->paid_at?->toIso8601String(),
        ];
    }
}
