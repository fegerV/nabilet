# Миграции production-схемы (76 таблиц)

Эти файлы — **не источник истины**. Истина — `nabilet_core_spec/migrations.sql`.
Это транскрипция: DDL пакета загружается в реальный MySQL 8.4, снимается через
`information_schema`, и по нему генерируются миграции.

```
nabilet_core_spec/migrations.sql   ← источник истины
        │
        │  загрузить в MySQL, снять information_schema
        ▼
tools/gen-migrations.py            ← генератор
        │
        ▼
database/migrations/*.php          ← этот каталог
        │
        │  php tools/verify-migrations.php
        ▼
сверка обратно с пакетом (16/16)
```

## Состав

| Файл | Что делает |
|---|---|
| `001_identity` … `008_integrations_system` | таблицы, колонки, первичные ключи, индексы. **Без внешних ключей** |
| `000900_add_foreign_keys` | все 101 внешний ключ, отложенно — когда таблицы уже существуют |
| `001000_add_check_constraints` | 35 CHECK-ограничений, сырым SQL (у Blueprint нет переносимого CHECK). Дальнейшие — `ck_users_status`/`ck_inventory_status`/`ck_events_status` (сплиты `013`–`015`), `ck_login_logs_event` (сплит `016`) и восемь словарей status-колонок (сплит `017`: `ck_carts_status`, `ck_checkin_devices_status`, `ck_consents_status`, `ck_privacy_requests_status`, `ck_notifications_status`, `ck_organizations_status`, `ck_ab_experiments_status`, `ck_orders_payment_status`) — зеркала `2026_10_12_000100`…`000500_*`. |
| `001100_add_schema_version_immutability_trigger` | триггер неизменяемости опубликованных версий схемы зала (ТЗ §20/§98) |

`000900` — не избыточная осторожность: объяви ключи внутри `create()`, и порядок
создания таблиц станет значимым, а `migrate:fresh` сломается на первой же
циклической ссылке.

`001100` **не генерируется**, а пишется руками: тело триггера
(`BEGIN … SIGNAL … END`) не выражается через метаданные колонок, и он ровно один.

## Почему `down()` ничего не делает

Миграции необратимы по замыслу. `down()`, который дропает `orders` или `tickets`,
уничтожает проданные билеты и историю платежей — это не откат, это инцидент.
Откатываться надо новой миграцией вперёд (`roll forward`), а не `migrate:rollback`.

## CHECK-ограничения и триггер — только MySQL

`001000` и `001100` проверяют драйвер и на не-MySQL **пропускают себя со
предупреждением в STDERR**, а не падают и не применяются наполовину. Гарантия,
которая молча не работает, опаснее гарантии, которой заметно нет.

## Как проверить

```bash
php tools/verify-migrations.php
```

Инструмент исполняет все миграции через стабы Laravel Schema, независимо
разбирает `nabilet_core_spec/migrations.sql` и сверяет:

- множества таблиц, колонок каждой таблицы, именованных индексов;
- все внешние ключи **вместе с `ON DELETE`**;
- все CHECK-ограничения;
- триггер иммутабельности;
- доменные инварианты: деньги — целые минорные единицы; `tickets.status`
  принимает `revoked`; `ck_tickets_terminal_exclusive` не трогает `revoked_at`.

Текущий результат: **16 проверок, 0 падений** — 76 таблиц, 110 FK, 48 CHECK,
1 триггер.

### Чего проверка не доказывает

- Что SQL исполнится на MySQL. В песочнице нет `pdo_sqlite`, а PHP к mysqld не
  подключается. Авторитетный прогон — применить `migrations.sql` на MySQL 8.4
  (`docs/DATABASE.md` §10) и, когда появится `vendor/`, `php artisan migrate:fresh`.
- Совпадение **типов** колонок (`VARCHAR(255)` против `string(255)`). Типы
  перенесены из `information_schema`, повторно здесь не сверяются.

## История

До появления пакета здесь лежал другой набор — **66 таблиц** с другими именами
(`event_sessions`, `rows`, `tables`, `ab_tests`) и другой моделью inventory
(enum состояния вместо `capacity` + `available_quantity`). Он перенесён в
`database/migrations-superseded/` и **не должен запускаться**.
