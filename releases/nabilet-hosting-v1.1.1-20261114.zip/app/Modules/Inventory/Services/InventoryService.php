<?php

declare(strict_types=1);

namespace Nabilet\Modules\Inventory\Services;

use Nabilet\Core\Errors\ConflictError;
use Nabilet\Core\Errors\NotFoundError;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Core\Support\PublicId;
use Nabilet\Modules\Cart\Models\Cart;
use Nabilet\Modules\Cart\Domain\CartStatus;
use Nabilet\Modules\Cart\Models\CartItem;
use Nabilet\Modules\Inventory\Models\InventoryItem;
use Nabilet\Modules\Inventory\StateMachines\InventoryItemStateMachine;
use Nabilet\Modules\Inventory\Repositories\InventoryItemRepository;
use Nabilet\Modules\Sessions\Models\Session;
use Nabilet\Modules\Venues\Models\HallRow;
use Nabilet\Modules\Venues\Models\HallSchemaVersion;
use Nabilet\Modules\Venues\Models\HallTable;
use Nabilet\Modules\Venues\Models\Seat;
use Nabilet\Modules\Venues\Models\Sector;
use Nabilet\Modules\Venues\Models\StandingZone;
use Nabilet\Modules\Venues\Domain\SchemaPrice;
use Illuminate\Support\Facades\DB;

class InventoryService
{
    public function __construct(
        protected InventoryItemRepository $repository
    ) {}

    /**
     * Генерирует из схемы зала:
     *   sectors → hall_rows → seats (геометрия) и inventory_items (места для продажи).
     *
     * Поддерживает оба формата schema_json:
     *   - канвас редактора (sectors[].seats[] с x/y/row/number) — конвертируется
     *     через HallSchemaVersion::toInventoryFormat();
     *   - rows-формат импортёра Афиши (sectors[].rows[].seats[] c price_amount)
     *     — используется напрямую.
     *
     * ГЕОМЕТРИЯ ПРИНАДЛЕЖИТ ВЕРСИИ СХЕМЫ, А НЕ СЕАНСУ. В цепочке
     * `sectors.schema_version_id` → `hall_rows.sector_id` → `seats.row_id` нет
     * `session_id`; сеансу принадлежит только инвентарь (`inventory_items`).
     * Поэтому геометрия материализуется ОДИН раз на версию схемы, а второй и
     * последующие сеансы в том же зале её переиспользуют — см. `existingGeometry()`.
     */
    public function generateFromSchema(HallSchemaVersion $schemaVersion, Session $session): int
    {
        return DB::transaction(function () use ($schemaVersion, $session) {
            $schema = $schemaVersion->schema_json ?? [];

            // rows-формат (конвертация канваса, если нужно)
            $sectors = $schemaVersion->toInventoryFormat();

            // 0. Снимаем инвентарь СЕССИИ — и только его.
            //
            // Порядок критичен: `inventory_items.seat_id` и `standing_zone_id`
            // ссылаются на `seats` / `standing_zones` с ON DELETE RESTRICT.
            // Проданные билеты по-прежнему защищены: у `tickets.seat_id` тоже
            // RESTRICT, поэтому пересборка зала с продажами падает — но уже
            // явно и не разрушая данные.
            InventoryItem::where('session_id', $session->id)->delete();

            // 1. Геометрия — ОДИН раз на версию схемы (см. docblock метода).
            //
            // Раньше метод всегда удалял её и создавал заново. На первом сеансе
            // это незаметно, на втором — падение: `inventory_items.seat_id`
            // держит `seats` через ON DELETE RESTRICT, поэтому `delete from
            // seats` упирался в FK (SQLSTATE 23000 / 1451) и `POST /sessions`
            // отвечал 500. Второй сеанс в том же зале нельзя было создать
            // вообще — ни на другую дату, ни на другое время.
            $sectorModels = $this->existingGeometry($schemaVersion, $sectors);

            // Пустой список = «геометрия уже на месте, материализовать нечего».
            // Цикл ниже — это материализация, и на существующей геометрии он не
            // должен выполниться ни разу.
            $sectorsToCreate = $sectorModels === null ? $sectors : [];
            $sectorModels ??= [];

            $seatCounter = 0;
            foreach ($sectorsToCreate as $sectorData) {
                $sector = Sector::create([
                    'schema_version_id' => $schemaVersion->id,
                    'name' => $sectorData['name'] ?? 'Сектор',
                    'code' => $sectorData['code'] ?? '',
                    'type' => $sectorData['type'] ?? 'seated',
                    'x' => $sectorData['x'] ?? 0,
                    'y' => $sectorData['y'] ?? 0,
                    'width' => $sectorData['width'] ?? 60,
                    'height' => $sectorData['height'] ?? 40,
                    'capacity' => 0,
                ]);
                $sectorModels[] = $sector;

                                $capacity = 0;
                                                $isStanding = ($sectorData['type'] ?? 'seated') === 'standing';
                                                $standingPrice = 0;
                                foreach ($sectorData['rows'] ?? [] as $rowData) {
                                    $row = HallRow::create([
                                                            'sector_id' => $sector->id,
                                                            'number' => $rowData['number'] ?? '',
                                                            'name' => $rowData['label'] ?? 'Ряд',
                                                            'price_amount' => $rowData['price_amount'] ?? 0,
                                                            'currency' => 'RUB',
                                                            'rotation' => 0,
                                                        ]);

                                    foreach ($rowData['seats'] ?? [] as $seatData) {
                                                                            $seatType = (string) ($seatData['type'] ?? 'standard');
                                                                                                    // Нормализация типов: импорт из Афиши даёт 'regular',
                                                                                                    // БД допускает standard/vip/wheelchair/companion/custom.
                                                                                                    if ($seatType === 'regular') {
                                                                                                        $seatType = 'standard';
                                                                                                    }

                                                                                                    $seatCounter += 1;
                                                                                                    // Стоячая зона: физических мест нет — вместимость = N билетов.
                                                                                                    if ($isStanding) {
                                                                                                        $capacity += 1;
                                                                                                        if ($standingPrice === 0) {
                                                                                                            $standingPrice = (int) ($rowData['price_amount'] ?? 0);
                                                                                                        }
                                                                                                        continue;
                                                                                                    }
                                                                Seat::create([
                                                                    'row_id' => $row->id,
                                                                    'number' => (string) ($seatData['number'] ?? (string) $seatCounter),
                                                                    'label' => $seatData['label'] ?? ('Ряд ' . ($rowData['number'] ?? '') . ' Место ' . ($seatData['number'] ?? '')),
                                                                    'type' => $seatType,
                                                                                                'x' => $seatData['x'] ?? 0,
                                                                                                'y' => $seatData['y'] ?? 0,
                                                                                                'rotation' => 0,
                                                                                                'status' => 'active',
                                                                    // Индивидуальная цена места (§54): побеждает цену ряда.
                                                                    'price_amount' => SchemaPrice::seatOverride($seatData['priceMinor'] ?? null)?->minorUnits(),
                                        ]);
                                        $capacity += 1;
                                    }
                                }
                $sector->update(['capacity' => $capacity]);

                // Банкетный стол (сектор `shape: 'table'`) — материализуем его
                // геометрию в `hall_tables`. Раньше таблица не заполнялась
                // НИКОГДА (0 строк во всех БД): стол существовал только как
                // кольцо мест внутри JSON-схемы, а из ТЗ-таблица оставалась
                // мёртвой. Старые строки не чистим вручную — `hall_tables`
                // ссылается на `sectors` с ON DELETE CASCADE, а сектора выше
                // пересоздаются.
                if (($sectorData['shape'] ?? null) === 'table' && is_array($sectorData['table'] ?? null)) {
                    $table = $sectorData['table'];
                    HallTable::create([
                        'sector_id' => $sector->id,
                        'name' => (string) ($sectorData['name'] ?? 'Стол'),
                        // width/height в БД NOT NULL, поэтому вырожденное кольцо
                        // (все места в одной точке) даёт минимальный размер,
                        // а не 0 — иначе строка не вставится.
                        'x' => (float) ($table['x'] ?? 0),
                        'y' => (float) ($table['y'] ?? 0),
                        'width' => max(1.0, (float) ($table['width'] ?? 0)),
                        'height' => max(1.0, (float) ($table['height'] ?? 0)),
                        'rotation' => 0,
                        'capacity' => (int) ($table['capacity'] ?? 0),
                        // Радиус кольца — не колонка, а метаданные: по нему
                        // витрина рисует круглый стол, а не прямоугольник.
                        'metadata_json' => [
                            'cx' => (float) ($table['cx'] ?? 0),
                            'cy' => (float) ($table['cy'] ?? 0),
                            'ring' => (float) ($table['ring'] ?? 0),
                        ],
                    ]);
                }
            }

            // 2. Собираем инвентарь сессии из мест.
            // Standing-зоны и сидячие места вставляются ОТДЕЛЬНО: у них разный набор колонок,
            // а bulk insert (Model::insert) требует одинаковых ключей у всех строк.
            // Прежний инвентарь уже снят шагом 0 (до удаления геометрии).
                                    $seatItems = [];
                                    $standingItems = [];
                                                foreach ($sectorModels as $sector) {
                                                    // Стоячая зона: одна standing-зона + один inventory-item standing
                                                    // с capacity = вместимость зоны (сколько билетов продать).
                                                    if (($sector->type ?? 'seated') === 'standing' && $sector->capacity > 0) {
                                                        $standingRow = HallRow::query()->where('sector_id', $sector->id)->first();
                                                        $standingPrice = (int) ($standingRow?->price_amount ?? 0);
                                                        // Зона принадлежит версии схемы (через сектор), поэтому при
                                                        // переиспользовании геометрии её нельзя создавать второй раз:
                                                        // иначе каждый новый сеанс добавлял бы ещё одну зону с тем же
                                                        // именем, а `standing_zone_id` первого сеанса указывал бы на
                                                        // старую. Берём существующую, цену не трогаем — её меняет
                                                        // `updateRowPrices()`.
                                                        $zone = StandingZone::query()->where('sector_id', $sector->id)->first()
                                                            ?? StandingZone::create([
                                                                'sector_id' => $sector->id,
                                                                'name' => $sector->name ?? 'Стоячая зона',
                                                                'capacity' => $sector->capacity,
                                                                'price_amount' => $standingPrice,
                                                                'currency' => 'RUB',
                                                            ]);
                                                        $standingItems[] = [
                                                            'public_id' => PublicId::generate(),
                                                            'organization_id' => $session->organization_id,
                                                            'session_id' => $session->id,
                                                            'type' => 'standing',
                                                            'seat_id' => null,
                                                            'standing_zone_id' => $zone->id,
                                                            'price_amount' => $standingPrice,
                                                            'currency' => 'RUB',
                                                            'capacity' => $sector->capacity,
                                                            'available_quantity' => $sector->capacity,
                                                            'status' => InventoryItemStateMachine::AVAILABLE,
                                                            'metadata_json' => json_encode([
                                                                'sector_name' => $sector->name,
                                                                'row_label' => 'Танцпол',
                                                                'seat_number' => null,
                                                            ]),
                                                            'created_at' => now(),
                                                            'updated_at' => now(),
                                                        ];
                                                        continue;
                                                    }
                                        $rows = HallRow::query()->where('sector_id', $sector->id)->get();
                                        foreach ($rows as $row) {
                                            $seats = Seat::query()->where('row_id', $row->id)->get();
                                            foreach ($seats as $seat) {
                                                $seatItems[] = [
                                                    'public_id' => PublicId::generate(),
                                                    'organization_id' => $session->organization_id,
                                                    'session_id' => $session->id,
                                                    'type' => 'seat',
                                                    'seat_id' => $seat->id,
                                                    // Индивидуальная цена места перекрывает цену ряда.
                                                    'price_amount' => $seat->price_amount ?? $row->price_amount,
                                                    'currency' => 'RUB',
                                                    'capacity' => 1,
                                                    'available_quantity' => 1,
                                                    'status' => InventoryItemStateMachine::AVAILABLE,
                                                    'metadata_json' => json_encode([
                                                        'sector_name' => $sector->name,
                                                        'row_label' => $row->name,
                                                        'seat_number' => $seat->number,
                                                    ]),
                                                    'created_at' => now(),
                                                    'updated_at' => now(),
                                                ];
                                            }
                                        }
                                    }

                                    $total = count($standingItems) + count($seatItems);
                        if ($total === 0) {
                            return 0;
                        }

                        if (count($standingItems) > 0) {
                            $this->repository->bulkCreate($standingItems);
                        }
                        if (count($seatItems) > 0) {
                            $this->repository->bulkCreate($seatItems);
                        }

                        return $total;
        });
    }

    /**
     * Вернуть уже материализованную геометрию версии схемы — или `null`, если её
     * нужно материализовать.
     *
     * `null` означает «геометрии нет»: либо её никогда не создавали, либо она
     * устарела и была безопасно снята. Массив секторов означает «переиспользуй».
     *
     * УСТАРЕВАНИЕ. `schema_json` опубликованной версии не меняется — правка схемы
     * создаёт НОВУЮ версию (`POST /halls/{publicId}/schema-versions/draft`),
     * поэтому расхождение с `schema_json` означает ручную правку в БД или старый
     * баг. Пересобрать геометрию в этом случае можно только если на неё никто не
     * ссылается: `seats` и `standing_zones` держат `inventory_items` ДРУГИХ
     * сеансов через ON DELETE RESTRICT (инвентарь текущего снят вызывающим).
     * Если ссылаются — падаем с 409: молча отдать покупателю схему, которой уже
     * нет, хуже, чем отказать администратору с объяснением.
     *
     * @param  array<int, array<string, mixed>>  $sectors  rows-формат схемы
     * @return array<int, Sector>|null
     */
    private function existingGeometry(HallSchemaVersion $schemaVersion, array $sectors): ?array
    {
        $sectorIds = Sector::query()
            ->where('schema_version_id', $schemaVersion->id)
            ->pluck('id')
            ->all();

        if ($sectorIds === []) {
            return null;
        }

        $rowIds = HallRow::query()->whereIn('sector_id', $sectorIds)->pluck('id')->all();

        if ($this->geometryMatchesSchema($sectors, $sectorIds, $rowIds)) {
            // `orderBy('id')` — порядок материализации: сектора создавались в
            // порядке схемы, поэтому сортировка по id его воспроизводит. Порядок
            // влияет только на порядок позиций инвентаря, но лучше он, чем
            // произвольный порядок из БД.
            return Sector::query()->whereIn('id', $sectorIds)->orderBy('id')->get()->all();
        }

        $seatIds = $rowIds === [] ? [] : Seat::query()->whereIn('row_id', $rowIds)->pluck('id')->all();
        $zoneIds = StandingZone::query()->whereIn('sector_id', $sectorIds)->pluck('id')->all();

        // Инвентарь текущей сессии уже снят, поэтому любая оставшаяся ссылка —
        // чужая.
        $seatsInUse = $seatIds !== [] && InventoryItem::query()->whereIn('seat_id', $seatIds)->exists();
        $zonesInUse = $zoneIds !== [] && InventoryItem::query()->whereIn('standing_zone_id', $zoneIds)->exists();

        if ($seatsInUse || $zonesInUse) {
            throw new ConflictError(
                sprintf(
                    'Hall schema version %d has geometry that no longer matches its schema, but other sessions already sell seats from it. Publish a new schema version instead of changing this one.',
                    $schemaVersion->id
                ),
                'SCHEMA_GEOMETRY_IN_USE',
                [
                    'schema_version_id' => $schemaVersion->id,
                    'seats_in_use' => $seatsInUse,
                    'standing_zones_in_use' => $zonesInUse,
                ]
            );
        }

        // Ссылок нет — снимаем и материализуем заново. Порядок обязателен: места
        // → ряды → зоны → сектора (`hall_rows`/`standing_zones` держат `sectors`
        // каскадом, но `inventory_items` — RESTRICT, поэтому удаляем явно).
        if ($seatIds !== []) {
            Seat::query()->whereIn('id', $seatIds)->delete();
        }
        HallRow::query()->whereIn('sector_id', $sectorIds)->delete();
        StandingZone::query()->whereIn('sector_id', $sectorIds)->delete();
        Sector::query()->whereIn('id', $sectorIds)->delete();

        return null;
    }

    /**
     * Совпадает ли материализованная геометрия с текущей схемой.
     *
     * Сравниваются количества, а не координаты: этого достаточно, чтобы отличить
     * «та же схема» от «схему поправили», а стоит это три `COUNT` вместо чтения
     * всех мест зала. Проверка вызывается один раз на созданный сеанс.
     *
     * @param  array<int, array<string, mixed>>  $sectors
     * @param  array<int, int|string>  $sectorIds
     * @param  array<int, int|string>  $rowIds
     */
    private function geometryMatchesSchema(array $sectors, array $sectorIds, array $rowIds): bool
    {
        if (count($sectorIds) !== count($sectors)) {
            return false;
        }

        $expectedRows = 0;
        $expectedSeats = 0;

        foreach ($sectors as $sectorData) {
            // У стоячей зоны физических мест нет: материализация создаёт ряд, но
            // до создания `seats` не доходит (вместимость зоны живёт в
            // `sectors.capacity`). Без этого исключения стоячий зал считался бы
            // устаревшим при каждом новом сеансе.
            $isStanding = ($sectorData['type'] ?? 'seated') === 'standing';

            foreach ($sectorData['rows'] ?? [] as $rowData) {
                $expectedRows++;

                if (! $isStanding) {
                    $expectedSeats += count($rowData['seats'] ?? []);
                }
            }
        }

        if (HallRow::query()->whereIn('sector_id', $sectorIds)->count() !== $expectedRows) {
            return false;
        }

        if ($expectedSeats === 0) {
            return true;
        }

        return Seat::query()->whereIn('row_id', $rowIds)->count() === $expectedSeats;
    }

    /**
     * Admin-обновление цен по рядам БЕЗ регенерации геометрии.
     *
     * Проблема, которую это решает: цены живут в inventory_items.price_amount и
     * проставляются только в generateFromSchema(), а роуты Inventory — только GET.
     * Единственный способ менять цену был — пересоздать инвентарь, что убивает
     * холды (seat_holds) и проданные билеты (status='sold').
     *
     * Правила:
     *   - обновляем price_amount только у СВОБОДНЫХ мест: available_quantity = capacity
     *     (для seat capacity=1, для standing capacity=N — «не трогать занятые места»);
     *   - холды и sold-позиции остаются со старой ценой — контракт покупки не меняется
     *     задним числом;
     *   - hall_rows / standing_zones обновляем всегда: следующий generateFromSchema()
     *     возьмёт новую цену как источник истины ряда;
     *   - cart_items открытых (active) корзин синхронизируются на новую цену и
     *     пересчитываются total_price / carts.total_amount, чтобы покупатель платил
     *     ровно то, что видит витрина.
     *
     * Всё в одном DB::transaction — либо весь прайс-лист применён, либо ничего.
     *
     * @param  int   $sessionId  числовой id или public_id сессии (как в CartService)
     * @param  array<int, array{row_id?: int|string, standing_zone_id?: int|string, price_amount: int|string}>  $rows
     * @param  bool  $sessionOnly  НЕ трогать hall_rows / standing_zones — менять цены
     *                             только в инвентаре ЭТОГО сеанса. Нужно, когда цены
     *                             «разовые под конкретный концерт»: со значением true
     *                             будущие сеансы того же зала наследуют базовую сетку
     *                             схемы, а не эту лесенку.
     * @return array{session_id:int, rows_updated:int, items_updated:int, cart_items_updated:int, carts_recalculated:int}
     */
    public function updateRowPrices(int|string $sessionId, array $rows, bool $sessionOnly = false): array
    {
        $session = Session::findOrFailBySessionId($sessionId);

        return DB::transaction(function () use ($session, $rows, $sessionOnly): array {
            $now = now();
            $rowsUpdated = 0;
            $itemsUpdated = 0;
            $cartItemsUpdated = 0;
            $affectedItemIds = [];

            foreach ($rows as $rowData) {
                $price = (int) $rowData['price_amount'];

                if (! empty($rowData['standing_zone_id'])) {
                    $zoneId = (int) $rowData['standing_zone_id'];

                    // Зона должна принадлежать этой сессии (через её инвентарь) —
                    // иначе админ одного города правил бы цены чужого зала.
                    $owns = InventoryItem::query()
                        ->where('session_id', $session->id)
                        ->where('standing_zone_id', $zoneId)
                        ->exists();
                    if (! $owns) {
                        throw new NotFoundError('Standing zone', $zoneId, [
                            'reason' => 'зона не относится к сессии ' . $session->id,
                        ]);
                    }

                    if (! $sessionOnly) {
                        StandingZone::query()
                            ->whereKey($zoneId)
                            ->update(['price_amount' => $price, 'updated_at' => $now]);
                    }
                    $rowsUpdated++;

                    $touched = InventoryItem::query()
                        ->where('session_id', $session->id)
                        ->where('standing_zone_id', $zoneId)
                        ->whereColumn('available_quantity', 'capacity')
                        ->pluck('id');
                    $affectedItemIds = array_merge($affectedItemIds, $touched->all());

                    $itemsUpdated += InventoryItem::query()
                        ->where('session_id', $session->id)
                        ->where('standing_zone_id', $zoneId)
                        ->whereColumn('available_quantity', 'capacity')
                        ->update(['price_amount' => $price, 'updated_at' => $now]);

                    continue;
                }

                $rowId = (int) $rowData['row_id'];

                $row = HallRow::find($rowId);
                if ($row === null) {
                    throw new NotFoundError('Hall row', $rowId);
                }
                // Ряд должен быть из схемы, по которой генерирован инвентарь сессии.
                $inSession = Seat::query()
                    ->where('row_id', $rowId)
                    ->whereIn('id', function ($q) use ($session): void {
                        $q->select('seat_id')
                            ->from('inventory_items')
                            ->where('session_id', $session->id)
                            ->whereNotNull('seat_id');
                    })
                    ->exists();
                if (! $inSession) {
                    throw new NotFoundError('Hall row', $rowId, [
                        'reason' => 'ряд не относится к сессии ' . $session->id,
                    ]);
                }

                if (! $sessionOnly) {
                    HallRow::query()
                        ->whereKey($rowId)
                        ->update(['price_amount' => $price, 'currency' => 'RUB', 'updated_at' => $now]);
                }
                $rowsUpdated++;

                $touched = InventoryItem::query()
                    ->where('session_id', $session->id)
                    ->whereIn('seat_id', function ($q) use ($rowId): void {
                        $q->select('id')->from('seats')->where('row_id', $rowId);
                    })
                    ->whereColumn('available_quantity', 'capacity')
                    ->pluck('id');
                $affectedItemIds = array_merge($affectedItemIds, $touched->all());

                $itemsUpdated += InventoryItem::query()
                    ->where('session_id', $session->id)
                    ->whereIn('seat_id', function ($q) use ($rowId): void {
                        $q->select('id')->from('seats')->where('row_id', $rowId);
                    })
                    ->whereColumn('available_quantity', 'capacity')
                    ->update(['price_amount' => $price, 'updated_at' => $now]);
            }

            // Синхронизация ОТКРЫТЫХ корзин (status='active'): unit_price и
            // total_price = новая цена × количество. Конвертированные/закрытые
            // корзины не трогаем — заказ уже зафиксировал цену.
            $cartItemsUpdated = $this->syncOpenCartItems($affectedItemIds, $now);
            $cartsRecalculated = $this->recalculateAffectedCarts();

            return [
                'session_id' => (int) $session->id,
                'rows_updated' => $rowsUpdated,
                'items_updated' => $itemsUpdated,
                'cart_items_updated' => $cartItemsUpdated,
                'carts_recalculated' => $cartsRecalculated,
                // Выводим режим явно: разница «только сеанс» vs «и сетка зала»
                // не видна по счётчикам, а от неё зависит, унаследуют ли цену
                // будущие сеансы этого зала.
                'session_only' => $sessionOnly,
            ];
        });
    }

    /**
     * Обновляет unit_price/total_price cart_items, ссылающихся на переоцененные
     * позиции, но только внутри активных корзин.
     *
     * @param  list<int>  $inventoryItemIds
     */
    protected function syncOpenCartItems(array $inventoryItemIds, $now): int
    {
        if ($inventoryItemIds === []) {
            return 0;
        }

        $updated = 0;
        // Пересчёт цен по открытым корзинам — системный путь (переоценка
        // сеанса): позиции читаются по ЯВНОМУ списку inventory_item_id,
        // в bypass — контекст вызывающего (консоль/сотрудник) не должен
        // сужать выборку корзин, у которых цена уже разошлась.
        $items = app(OrganizationContext::class)->withoutScope(
            fn () => CartItem::query()
                ->whereIn('inventory_item_id', $inventoryItemIds)
                ->whereHas('cart', fn ($q) => $q->where('status', CartStatus::ACTIVE))
                ->with('inventoryItem:id,price_amount')
                ->get()
        );

        foreach ($items as $item) {
            $newUnit = (int) ($item->inventoryItem?->price_amount ?? $item->unit_price);
            $newTotal = $newUnit * (int) $item->quantity;

            if ((int) $item->unit_price === $newUnit && (int) $item->total_price === $newTotal) {
                continue;
            }

            $item->forceFill([
                'unit_price' => $newUnit,
                'total_price' => $newTotal,
                'updated_at' => $now,
            ])->save();
            $updated++;
        }

        return $updated;
    }

    /**
     * Пересчёт carts.total_amount по всем активным корзинам (та же формула, что
     * в CartItemService::recalculateCartTotal — сумма total_price позиций).
     */
    protected function recalculateAffectedCarts(): int
    {
        // Активные корзины для пересчёта после переоценки — системный путь:
        // контекст вызывающего (консоль/сотрудник) не должен сужать выборку
        // корзин, цены в которых уже разошлись с позициями склада.
        $carts = app(OrganizationContext::class)->withoutScope(
            fn () => Cart::query()->where('status', CartStatus::ACTIVE)->get()
        );
        $recalculated = 0;

        foreach ($carts as $cart) {
            // Пересчёт корзин после переоценки — системный путь (см.
            // syncOpenCartItems): сумма позиций — в bypass.
            $total = (int) app(OrganizationContext::class)->withoutScope(
                fn () => CartItem::query()
                    ->where('cart_id', $cart->id)
                    ->sum('total_price')
            );

            if ((int) ($cart->total_amount ?? 0) !== $total) {
                $cart->forceFill(['total_amount' => (string) $total])->save();
                $recalculated++;
            }
        }

        return $recalculated;
    }

    public function getAvailableCount(Session $session): int
    {
        return $this->repository->getAvailableBySession($session->id)->sum('available_quantity');
    }

    public function getTotalCapacity(Session $session): int
    {
        return InventoryItem::where('session_id', $session->id)->sum('quantity');
    }

    public function getSoldCount(Session $session): int
    {
        return $this->repository->getSoldCount($session->id);
    }

    public function getHeldCount(Session $session): int
    {
        return $this->repository->getHeldCount($session->id);
    }

    public function reserveItem(InventoryItem $item, int $quantity = 1): InventoryItem
    {
        if ($item->available_quantity < $quantity) {
            throw new \RuntimeException('Insufficient available quantity');
        }

        return $this->repository->decrementQuantity($item, $quantity);
    }

    public function releaseItem(InventoryItem $item, int $quantity = 1): InventoryItem
    {
        return $this->repository->incrementQuantity($item, $quantity);
    }
}