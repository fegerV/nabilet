<script setup lang="ts">
/**
 * Оформление заказа.
 *
 * Правила, важные для конверсии:
 *  - Один экран, а не пять шагов. Шаги показаны как прогресс, но не рвут поток:
 *    пользователь видит, сколько осталось, и не теряет введённое.
 *  - Ошибка валидации объясняет, что исправить («телефон — 11 цифр», а не
 *    «неверный формат»), и появляется у поля, а не в общей плашке.
 *  - Кнопка оплаты не блокируется до полного заполнения: она показывает, чего
 *    не хватает. Серая кнопка без объяснения — главная причина брошенных корзин.
 *
 * Здесь же происходит НАСТОЯЩАЯ покупка. Раньше на этом экране стояла имитация
 * (`setTimeout` + `router.push('/payment/success')`), поэтому до сервера не
 * доходил ни один заказ витрины: корзина оставалась `active`, места — `held`,
 * билеты не выпускались, а покупатель видел «оплата прошла». Теперь:
 *
 *   1. `POST /cart/checkout` — заказ из удержанных мест (нужны контакты: на
 *      e-mail уходит билет, поэтому валидация контактов идёт ДО создания заказа);
 *   2. `POST /payments` — платёж и `confirmation_url`;
 *   3. переход на страницу оплаты (в demo-режиме — на локальный симулятор,
 *      который подтверждает платёж и возвращает покупателя на результат).
 *
 * Цена и итог берутся из ответа сервера (инвариант 6). Здесь стояли
 * `SERVICE_FEE = 9900` и промокод `NABILET10`, считавший скидку на клиенте: ни
 * сбора, ни промокодов сервер не знает (`CartService::checkout()`: subtotal =
 * discount = fee = total = сумма позиций, а `promo_code` отвечает 422
 * `PROMO_CODE_NOT_SUPPORTED`). Покупатель видел сумму, которую с него не
 * списывали, — расхождение между экраном и чеком.
 *
 * Бонусы (фаза 2b) — единственная величина, которую экран считает сам, и это
 * не возврат к прежней ошибке: клиентское число здесь только предпросмотр
 * лимита, а списание считает сервер в той же транзакции, что и заказ
 * (`CartCheckoutService::convert()`). Экран показывает ровно ту сумму, которую
 * подтвердит сервер, а на превышение получает 422 `BONUS_LIMIT_EXCEEDED` и
 * снимает галочку — молчаливой подмены итога не происходит ни на одной стороне.
 */
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import NButton from '@/components/ui/NButton.vue'
import NInput from '@/components/ui/NInput.vue'
import NCheckbox from '@/components/ui/NCheckbox.vue'
import NCountdown from '@/components/ui/NCountdown.vue'
import NEmptyState from '@/components/ui/NEmptyState.vue'
import { useCartStore, seatLineLabel, seatLineTotal, type CartSeat } from '@/stores/cart'
import { useLoyaltyStore } from '@/stores/loyalty'
import { useUiStore } from '@/stores/ui'
import { checkoutSession, fetchCart } from '@/lib/inventory'
import { ApiError } from '@/lib/api'
import { anchorDemoUrl, initiatePayment, newIdempotencyKey, rememberPaymentId } from '@/lib/payments'
import { trackEvent } from '@/lib/metrika'
import { money, plural, ticketsLabel } from '@/lib/format'
import { phoneError } from '@/lib/phone'
import { applyBonuses } from '@/lib/loyalty'
import { clearRememberedReferralCode, rememberedReferralCode } from '@/lib/referral'
import { cn } from '@/lib/cn'

const route = useRoute()
const router = useRouter()
const cart = useCartStore()
const loyalty = useLoyaltyStore()
const ui = useUiStore()

/** Сеанс, к которому относится корзина. Передаётся из выбора мест. */
const sessionId = computed(() => String(route.query.session ?? ''))

/**
 * Код приглашения (фаза 4): друг открыл `#/r/{code}` или `?ref={code}` — код
 * ждёт в localStorage ровно до этого момента.
 *
 * Читается один раз при заходе на экран, а не в каждом обращении: покупка
 * оформляется один раз, и реактивность здесь была бы ложной — код мог
 * смениться в другой вкладке, но оформляется заказ всё равно с тем кодом,
 * с которым покупатель пришёл.
 */
const referralCode = ref(rememberedReferralCode())

const STEPS = ['Места', 'Контакты', 'Оплата']
const currentStep = 1

const name = ref('')
const email = ref('')
/**
 * Повтор ввода e-mail.
 *
 * Билет уходит ровно на `email`, и ошибка в одну букву означает, что билет не
 * придёт: письмо вернётся к нам как недоставленное, а покупатель будет ждать.
 * Повторный ввод ловит опечатку сразу, пока человек ещё помнит, что набирал.
 * Сервер проверяет то же самое правилом `same:customer_email`.
 */
const emailConfirm = ref('')
const phone = ref('')
const agree = ref(false)
const paying = ref(false)
const submitted = ref(false)
/** Ошибки полей из §66-конверта сервера: `error.errors` → по полю. */
const serverErrors = ref<Record<string, string>>({})
/** Идёт восстановление корзины из `GET /cart` (F5 или возврат с оплаты). */
const restoring = ref(false)

/**
 * Ключ идемпотентности платежа (S-07).
 *
 * Живёт в пределах одного «намерения оплатить»: пока пользователь на этой
 * странице и не получил ошибку, повторные вызовы `pay()` (двойной клик,
 * ретрай транспорта) шлют ОДИН и тот же ключ — сервер вернёт тот же платёж
 * вместо второго. Сбрасывается после ошибки: новая попытка после сбоя — это
 * уже другой запрос, и она должна получить новый платёж, а не прежний.
 */
const paymentKey = ref('')

function idempotencyKey(): string {
  if (!paymentKey.value) paymentKey.value = newIdempotencyKey()
  return paymentKey.value
}

/** Проверка формы адреса. Одна на два места: ошибку поля и подтверждение у кнопки. */
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[a-zа-я]{2,}$/i

const localErrors = computed(() => {
  const out: Record<string, string> = {}
  if (name.value.trim().length < 2) out.name = 'Укажите имя, как в документе'
  if (!EMAIL_RE.test(email.value)) out.email = 'Нужен e-mail — на него придёт билет'
  // Расхождение ловим только когда адрес в принципе введён: иначе пустая пара
  // «пусто = пусто» давала бы вторую ошибку на пустом поле.
  if (email.value.trim() !== '' && emailConfirm.value.trim() !== email.value.trim()) {
    out.emailConfirm = 'Адреса не совпадают — проверьте e-mail'
  }
  const phoneErr = phoneError(phone.value)
  if (phoneErr) out.phone = phoneErr
  if (!agree.value) out.agree = 'Без согласия на оферту билет не выпустим'
  return out
})

/** Серверные ошибки важнее локальных: их вернул источник истины. */
const errors = computed<Record<string, string>>(() => ({ ...localErrors.value, ...serverErrors.value }))

const canPay = computed(() => Object.keys(errors.value).length === 0 && cart.count > 0)
const missingHint = computed(() => {
  if (cart.count === 0) return 'Сначала выберите места'
  const first = Object.values(errors.value)[0]
  return first ?? ''
})

/**
 * Адрес корректен и подтверждён повтором.
 *
 * Тогда у кнопки оплаты показываем, куда именно уйдёт билет: это последняя
 * точка, где покупатель ещё может заметить опечатку — после оплаты письмо
 * уходит автоматически, и вручную исправлять адрес придётся уже на «Моих билетах».
 */
const emailOk = computed(() => EMAIL_RE.test(email.value) && emailConfirm.value.trim() === email.value.trim())

/* ── Бонусы в чекауте (фаза 2b) ───────────────────────────────────────────
 * ЛИМИТ СЧИТАЕТ ВИТРИНА, НО РЕШАЕТ СЕРВЕР
 *   `spendCapMinor()` — зеркало `BonusPolicy::maxSpendable` (см. `lib/loyalty.ts`),
 *   и оно здесь только для того, чтобы показать покупателю доступную сумму и не
 *   дать отметить больше. Чекаут пересчитывает тот же лимит заново и отвечает
 *   422 `BONUS_LIMIT_EXCEEDED` на превышение. Молчаливого урезания нет ни на
 *   одной из сторон: покупатель подтверждает конкретную цену, и она не должна
 *   измениться без его ведома.
 *
 * ГОСТЬ БЛОКА НЕ ВИДИТ
 *   `loyalty.bonus === null` — гость, ошибка запроса или счёт ещё не приходил.
 *   Отличать ноль от «не знаю» здесь обязательно: ноль означает «счёт есть и он
 *   пуст», и показывать «спишите 0 бонусов» значило бы обещать то, чего нет.
 * ─────────────────────────────────────────────────────────────────────────── */

/** Покупатель решил платить бонусами. По умолчанию — нет: списание должно быть осознанным. */
const useBonuses = ref(false)

/**
 * Правило применения бонусов — один владелец: `applyBonuses()` из `@/lib/loyalty`.
 * Здесь только передаём корзину и флаг; все пять величин считаются там. Ниже —
 * тонкие обёртки, чтобы остальной код страницы не менялся.
 */
const bonus = computed(() =>
  applyBonuses({
    subtotalMinor: cart.subtotalMinor,
    discountMinor: cart.discountMinor,
    balanceMinor: loyalty.bonus?.balance ?? 0,
    cartTotalMinor: cart.totalMinor,
    useBonuses: useBonuses.value,
  }),
)

/** Сколько можно списать в этом заказе (минорные единицы). */
const bonusCapMinor = computed(() => bonus.value.capMinor)

/**
 * Сколько реально спишем, в минорных единицах.
 *
 * Лимит уже ограничен остатком после скидки (`spendCapMinor`), поэтому
 * отдельного «не больше заказа» здесь не нужно — это свойство владельца, а не
 * дополнительная проверка на странице.
 */
const bonusMinor = computed(() => bonus.value.appliedMinor)

/** Итог — сумма позиций минус бонусы. Именно её выставляет сервер (`orders.total_amount`). */
const totalMinor = computed(() => bonus.value.totalMinor)

/** Тот же лимит в бонусах — то число, которое видит и называет покупатель. */
const bonusCapUnits = computed(() => bonus.value.capUnits)

/** Блок вообще показывается: счёт загружен и на нём что-то есть. */
const canUseBonuses = computed(
  () => loyalty.bonus !== null && loyalty.bonusesCount > 0 && bonusCapMinor.value > 0,
)

/**
 * Сколько бонусов останется, если галочку поставить.
 *
 * Считается от ЛИМИТА, а не от применённой суммы, и это не мелочь: подпись
 * рядом с галочкой описывает предложение, а не текущее состояние. «−300 ₽ ·
 * останется 500 бонусов» на снятой галочке было бы правдой буквально (ничего не
 * списали) и бесполезно по смыслу — покупатель читает эту строку, чтобы решить,
 * ставить галочку или нет, и ему нужно знать, что будет ПОСЛЕ.
 */
const bonusLeftUnits = computed(() => bonus.value.leftUnits)

/** Имена полей §66 → имена полей формы. */
const SERVER_FIELD_MAP: Record<string, string> = {
  customer_name: 'name',
  customer_email: 'email',
  customer_email_confirmation: 'emailConfirm',
  customer_phone: 'phone',
}

/**
 * Перечитать серверную корзину.
 *
 * Стор корзины живёт в памяти, поэтому F5 на этом шаге (и возврат с платёжной
 * страницы) рисовал «корзина пуста» поверх реально удержанных мест. Читаем
 * `GET /cart` — ровно так же, как это делает экран выбора мест.
 */
async function restoreCart(): Promise<void> {
  const sid = sessionId.value
  if (!sid || cart.count > 0) return
  restoring.value = true
  try {
    const serverCart = await fetchCart(sid)
    if (!serverCart) return

    const items: CartSeat[] = []
    // B2: вместе с выбором восстанавливаем карту «id места → cart_item_id».
    // `CartItemResource` отдаёт настоящий `cart_items.id`, и
    // `DELETE /cart/items/{id}` требует именно его; без этой карты снятие
    // восстановленного холда не отпускало серверные места.
    const cartItemIds: Record<string, string> = {}
    for (const item of serverCart.items ?? []) {
      const id = String(item.inventory_item?.id ?? '')
      if (!id) continue
      const cartItemId = String(item.id ?? '')
      if (cartItemId) cartItemIds[id] = cartItemId
      items.push({
        id,
        sector: String(item.inventory_item?.seat?.sector ?? 'Зал'),
        row: Number(item.inventory_item?.seat?.row ?? 0),
        number: Number(item.inventory_item?.seat?.number ?? 0),
        priceMinor: Number(item.unit_price ?? 0),
        kind: 'standard' as const,
        // Без количества танцпол qty=3 восстанавливался как один билет:
        // сводка на оформлении и `totalMinor` занижались втрое.
        quantity: Math.max(1, Number(item.quantity ?? 1) || 1),
      })
    }

    cart.hydrate(items, cartItemIds)
    if (serverCart.expires_at) cart.setHoldExpiry(serverCart.expires_at)
  } catch {
    /* корзина недоступна — экран честно покажет «корзина пуста» */
  } finally {
    restoring.value = false
  }
}

function applyServerErrors(error: ApiError): void {
  const mapped: Record<string, string> = {}
  for (const [field, messages] of Object.entries(error.details ?? {})) {
    const key = SERVER_FIELD_MAP[field]
    if (key && Array.isArray(messages) && messages.length > 0) mapped[key] = String(messages[0])
  }
  serverErrors.value = mapped
}

function handlePayError(error: unknown): void {
  // Любая ошибка завершает попытку: следующий клик — это новый запрос и он
  // обязан получить новый ключ идемпотентности, иначе сервер вернул бы платёж
  // прежней (неудавшейся) попытки вместе с её мёртвой ссылкой на оплату.
  paymentKey.value = ''

  if (!(error instanceof ApiError)) {
    ui.notify('rose', 'Оплата не началась', error instanceof Error ? error.message : 'Попробуйте ещё раз')
    return
  }

  // Ошибки полей — у полей, а не общей плашкой.
  if (error.status === 422 && error.details) {
    applyServerErrors(error)
    ui.notify('sun', 'Проверьте данные', 'Некоторые поля заполнены неверно.')
    return
  }

  // Холд истёк: места уже освобождены, выбор нужно повторить.
  if (error.code === 'CART_EXPIRED' || error.status === 410) {
    ui.notify('rose', 'Время удержания истекло', 'Места освобождены — выберите их заново.')
    cart.release()
    void restoreCart()
    return
  }

  // 404 от checkout — это не «сбой», а конец lifetime корзины (аудит D-8):
  // конвертированная, отпущенная или стёртая sweeper'ом корзина не находится
  // `firstOrFail()` и рендерится как универсальный NOT_FOUND. Честно сообщаем
  // покупателю и возвращаем его к выбору мест вместо молчаливой общей ошибки.
  if (error.status === 404) {
    ui.notify('rose', 'Корзина не найдена', 'Заказ уже оформлен или корзина устарела — выберите места заново.')
    cart.release()
    return
  }

  if (error.code === 'CART_EMPTY') {
    ui.notify('rose', 'Корзина пуста', 'Сервер не нашёл удержанных мест для этого сеанса.')
    void restoreCart()
    return
  }

  if (error.code === 'SALES_CLOSED') {
    ui.notify('rose', 'Продажи закрыты', error.message)
    return
  }

  if (error.code === 'PROMO_CODE_REJECTED' || error.code === 'PROMO_CODE_NOT_FOUND' || error.code === 'PROMO_CODE_EXHAUSTED') {
    // Checkout теперь реально оценивает промокод (PromoEvaluator): отказ —
    // это 422 с машинным кодом, а не заглушка NOT_SUPPORTED. Сообщение
    // сервера уже объясняет причину (expired / min_order_amount / лимиты).
    ui.notify('sun', 'Промокод не применён', error.message)
    return
  }

  if (error.code === 'BONUS_LIMIT_EXCEEDED') {
    // Лимит изменился между отрисовкой экрана и оформлением (баланс потратили
    // в другой вкладке, подытог изменился). Галочку снимаем, а не «поправляем
    // молча»: покупатель подтверждал конкретную цену, и подмена суммы под ним
    // была бы хуже отказа. Баланс перечитываем — лимит на экране станет верным.
    useBonuses.value = false
    void loyalty.load(true)
    ui.notify('sun', 'Бонусы не списаны', `${error.message} Оформите заказ без бонусов или повторите попытку.`)
    return
  }

  if (error.code === 'DEMO_DISABLED' || error.status === 403) {
    ui.notify('rose', 'Оплата недоступна', 'Платёжный провайдер не настроен — обратитесь к организатору.')
    return
  }

  ui.notify('rose', 'Оплата не началась', error.message)
}

async function pay(): Promise<void> {
  submitted.value = true
  serverErrors.value = {}

  if (!canPay.value) {
    ui.notify('sun', 'Не хватает данных', missingHint.value)
    return
  }
  if (!sessionId.value) {
    ui.notify('rose', 'Сеанс не определён', 'Вернитесь к событию и выберите места заново.')
    return
  }

  paying.value = true
  try {
    // 1. Заказ из удержанных мест. Контакты обязательны — на e-mail уходит билет.
    //    Бонусы уходят тем же запросом: списание — часть оформления заказа, и
    //    считать его отдельным вызовом после создания заказа значило бы получить
    //    заказ с одной суммой, а списание — с другой.
    const { data: order } = await checkoutSession(sessionId.value, {
      customer_name: name.value.trim(),
      customer_email: email.value.trim(),
      customer_email_confirmation: emailConfirm.value.trim(),
      customer_phone: phone.value.trim(),
      bonus_amount: bonusMinor.value,
      // Фаза 4: приглашение друга. Необязательное поле — `undefined` не попадает
      // в JSON, и покупка без приглашения идёт ровно тем же запросом.
      referral_code: referralCode.value ?? undefined,
    })

    // 2. Итог — из ответа сервера, он источник правды о цене.
    cart.setOrder(order.order_id, Number(order.total_amount))

    // Фаза 4: код приглашения своё отработал (или сервер его молча отклонил).
    // Забываем, чтобы второй заказ того же браузера не тащил его за собой:
    // сервер отказал бы всё равно (`uq_referrals_inviter_email` + проверка
    // «адрес уже награждён»), но мусорный ключ в localStorage живёт годами.
    if (referralCode.value) clearRememberedReferralCode()

    // 3. Платёж. Гостевой заказ авторизуется заголовком X-Cart-Token,
    //    который подставляет api.ts (`PaymentController::mayPay()`). Ключ
    //    идемпотентности обязателен и стабилен в пределах попытки (S-07).
    // E2: цель `payment_attempt` фиксирует сам факт перехода к оплате —
    // расхождение между «начал оформление» и «нажал оплатить» и есть тот
    // шаг воронки, на котором теряются корзины.
    void trackEvent('payment_attempt', {
      params: { order_id: String(order.order_id), tickets: cart.count },
    }).catch(() => {})
    const { confirmation_url, payment } = await initiatePayment(order.order_id, idempotencyKey())
    // C2: запоминаем платёж — после ухода на оплату (полная навигация) страница
    // результата спросит у сервера его настоящий статус, а не поверит роуту.
    rememberPaymentId(payment?.public_id ?? payment?.id)

    if (!confirmation_url) {
      ui.notify('sun', 'Нет ссылки на оплату', 'Заказ создан. Попробуйте оплатить ещё раз.')
      await router.push('/payment/pending')
      return
    }

    // Уход на оплату — полная навигация, как в реальном сценарии с провайдером.
    window.location.href = anchorDemoUrl(confirmation_url) ?? confirmation_url
  } catch (error) {
    handlePayError(error)
  } finally {
    paying.value = false
  }
}

onMounted(() => {
  cart.setSession(sessionId.value)
  // E2: `checkout_started` — начало оформления заказа. Считаем один раз за
  // заход на экран (F5 на том же заказе — новый заход, это нормально).
  if (cart.count > 0) {
    void trackEvent('checkout_started', {
      params: { session: sessionId.value, tickets: cart.count },
    }).catch(() => {})
  }
  void restoreCart()
})
</script>

<template>
  <div class="mx-auto max-w-content px-4 py-6 sm:px-6">
    <h1 class="text-2xl font-bold tracking-tight text-content">Оформление заказа</h1>

    <!-- Прогресс: пользователь видит, что осталось, но поток не прерывается -->
    <ol class="mt-4 flex items-center gap-2 text-xs">
      <li v-for="(step, i) in STEPS" :key="step" class="flex items-center gap-2">
        <span
          :class="
            cn(
              'grid h-6 w-6 place-items-center rounded-full text-2xs font-semibold',
              i < currentStep ? 'bg-brand-500 text-white' : i === currentStep ? 'bg-accent-500 text-white' : 'bg-surface-3 text-subtle',
            )
          "
        >{{ i < currentStep ? '✓' : i + 1 }}</span>
        <span :class="i === currentStep ? 'font-medium text-content' : 'text-subtle'">{{ step }}</span>
        <span v-if="i < STEPS.length - 1" class="h-px w-6 bg-line" aria-hidden="true" />
      </li>
    </ol>

    <!-- Возврат с платёжной страницы / F5: подтягиваем удержанные места -->
    <p v-if="restoring" class="mt-6 text-sm text-subtle">Восстанавливаем ваш выбор…</p>

    <NEmptyState
      v-else-if="cart.count === 0"
      class="surface-card mt-6"
      icon="◫"
      title="Корзина пуста"
      description="Вернитесь к событию и выберите места на схеме зала — они будут держаться за вами 10 минут."
      action-label="К афише"
      @action="router.push('/')"
    />

    <div v-else class="mt-6 grid gap-5 lg:grid-cols-[1fr_380px]">
      <div class="space-y-4">
        <!-- Контакты -->
        <section class="surface-card p-4">
          <h2 class="text-sm font-semibold text-content">Покупатель</h2>
          <p class="mt-0.5 text-xs text-subtle">
            Билет придёт на этот e-mail — проверьте адрес, опечатка задержит его получение
          </p>

          <div class="mt-4 grid gap-3 sm:grid-cols-2">
            <NInput
              v-model="name"
              label="Имя и фамилия"
              placeholder="Иван Петров"
              autocomplete="name"
              required
              :error="submitted ? errors.name : ''"
            />
            <NInput
              v-model="phone"
              label="Телефон"
              placeholder="+7 900 123-45-67"
              type="tel"
              inputmode="tel"
              autocomplete="tel"
              required
              :error="submitted ? errors.phone : ''"
            />
            <NInput
              v-model="email"
              label="E-mail"
              placeholder="ivan@example.com"
              type="email"
              inputmode="email"
              autocomplete="email"
              required
              class="sm:col-span-2"
              :error="submitted ? errors.email : ''"
            />
            <NInput
              v-model="emailConfirm"
              label="E-mail ещё раз"
              placeholder="ivan@example.com"
              type="email"
              inputmode="email"
              autocomplete="email"
              required
              class="sm:col-span-2"
              hint="Повторите адрес: на него уходит билет, и исправить опечатку потом сложнее"
              :error="submitted ? errors.emailConfirm : ''"
            />
          </div>
        </section>

        <!-- Способ получения -->
        <section class="surface-card p-4">
          <h2 class="text-sm font-semibold text-content">Как получить билет</h2>
          <div class="mt-3 grid gap-2 sm:grid-cols-2">
            <label
              class="flex cursor-pointer items-start gap-2.5 rounded-lg border border-brand-500 bg-brand-500/8 p-3"
            >
              <input type="radio" name="delivery" value="qr" checked class="mt-0.5 accent-brand-500" />
              <span>
                <span class="block text-sm font-medium text-content">QR в приложении</span>
                <span class="mt-0.5 block text-xs text-subtle">Покажете на входе, работает без сети</span>
              </span>
            </label>
            <label class="flex cursor-pointer items-start gap-2.5 rounded-lg border border-line p-3 hover:border-line-strong">
              <input type="radio" name="delivery" value="pdf" class="mt-0.5 accent-brand-500" />
              <span>
                <span class="block text-sm font-medium text-content">PDF на почту</span>
                <span class="mt-0.5 block text-xs text-subtle">Плюс дубль в Telegram, если подключён</span>
              </span>
            </label>
          </div>
        </section>

        <!-- Согласие -->
        <section class="surface-card p-4">
          <NCheckbox
            v-model="agree"
            label="Согласен с офертой и правилами посещения"
            description="Возврат возможен не позднее чем за 24 часа до начала сеанса"
          />
          <p v-if="submitted && errors.agree" class="mt-2 text-xs text-rose-400">{{ errors.agree }}</p>
        </section>
      </div>

      <!-- Итог -->
      <aside class="lg:sticky lg:top-24 lg:self-start">
        <div class="surface-card overflow-hidden">
          <div class="border-b border-line px-4 py-3">
            <h2 class="text-sm font-semibold text-content">Заказ</h2>
          </div>

          <div class="p-4">
            <NCountdown
              v-if="cart.holdSecondsLeft > 0"
              :seconds-left="cart.holdSecondsLeft"
              :total="900"
              class="mb-4"
              @extend="cart.extendHold()"
            />

            <p v-if="cart.holdExtendError" class="mb-4 text-xs text-rose-400">
              {{ cart.holdExtendError }}
            </p>

            <ul class="space-y-2">
              <li
                v-for="seat in cart.seats.filter((s) => cart.selectedIds.has(s.id))"
                :key="seat.id"
                class="flex items-center justify-between gap-2 text-sm"
              >
                <span class="truncate text-muted">
                  {{ seatLineLabel(seat) }}
                </span>
                <span class="flex-none tabular-nums text-content">{{ money(seatLineTotal(seat)) }}</span>
              </li>
            </ul>

            <dl class="mt-4 space-y-1.5 border-t border-line pt-3 text-sm">
              <div class="flex justify-between">
                <dt class="text-muted">{{ ticketsLabel(cart.ticketsCount) }}</dt>
                <dd class="tabular-nums text-content">{{ money(cart.subtotalMinor) }}</dd>
              </div>
              <!-- Бонусы — отдельной строкой, как и скидка по промокоду: покупатель
                   должен видеть, чем именно закрыта часть заказа, а не «итог
                   меньше, чем сумма позиций» без объяснения. -->
              <div v-if="bonusMinor > 0" class="flex justify-between">
                <dt class="text-mint-400">Бонусами</dt>
                <dd class="tabular-nums text-mint-400">−{{ money(bonusMinor) }}</dd>
              </div>
              <div class="flex items-baseline justify-between border-t border-line pt-2">
                <dt class="font-medium text-content">Итого</dt>
                <dd class="text-xl font-semibold tabular-nums text-content">{{ money(totalMinor) }}</dd>
              </div>
            </dl>

            <!-- Списание бонусов. Блок появляется только когда счёт загружен и на
                 нём есть что списать: гость (`loyalty.bonus === null`) не видит его
                 вовсе, а покупателю с нулевым балансом нечего предлагать. -->
            <NCheckbox
              v-if="canUseBonuses"
              v-model="useBonuses"
              class="mt-4"
              :label="`Списать ${bonusCapUnits} ${plural(bonusCapUnits, 'бонус', 'бонуса', 'бонусов')}`"
              :description="`−${money(bonusCapMinor)} · после покупки останется ${bonusLeftUnits} ${plural(bonusLeftUnits, 'бонус', 'бонуса', 'бонусов')}`"
            />

            <!--
              Фаза 4: приглашение друга применено. Показываем ДО оплаты и честно
              про срок: награда приходит после ПЕРВОЙ оплаты друга, и это решает
              сервер (`ReferralService::rewardForOrder()`), а не этот экран.
              Молчаливое начисление «бонусов за приглашение» в итоге выглядело бы
              обещанием, которого никто не давал.
            -->
            <p
              v-if="referralCode"
              class="mt-3 rounded-lg border border-mint-500/30 bg-mint-500/8 px-3 py-2 text-xs text-muted"
            >
              Вас пригласил друг — бонусы начислим обеим сторонам после оплаты этого заказа.
            </p>

            <p
              v-if="emailOk"
              class="mt-4 rounded-lg border border-line bg-surface-2 px-3 py-2 text-xs text-muted"
            >
              Билет придёт на <span class="font-medium text-content">{{ email.trim() }}</span>
            </p>

            <NButton
              variant="accent"
              size="lg"
              block
              class="mt-4"
              :loading="paying"
              @click="pay"
            >
              Оплатить {{ money(totalMinor) }}
            </NButton>

            <p v-if="submitted && !canPay" class="mt-2 text-center text-xs text-sun-400">
              {{ missingHint }}
            </p>
            <p class="mt-3 text-center text-2xs text-subtle">
              Оплата проходит через ЮKassa. Статус заказа подтверждает сервер, а не редирект.
            </p>
          </div>
        </div>
      </aside>
    </div>
  </div>
</template>
