<?php

declare(strict_types=1);

namespace Nabilet\Modules\Orders\Models;

use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Core\Models\Concerns\HasPublicId;
use Nabilet\Modules\Core\Tenancy\TenantScoped;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use Nabilet\Modules\Core\Users\Models\User;
use Nabilet\Modules\Core\Organizations\Models\Organization;
use Nabilet\Modules\Payments\Models\Payment;
use Nabilet\Modules\Sessions\Models\Session;
use Nabilet\Modules\Events\Models\Event;
use Nabilet\Modules\Tickets\Models\Ticket;

/**
 * @property int $id
 * @property string $public_id      CHAR(26), ULID base32
 * @property string $order_number   NB-YYYYMMDD-XXXXXXXX
 * @property int $organization_id
 * @property int|null $user_id
 * @property int|null $session_id   сеанс заказа (резолвится из корзины при checkout)
 * @property int|null $event_id     событие заказа (резолвится из сеанса)
 * @property int $subtotal_amount   integer minor units
 * @property int $discount_amount
 * @property int $bonus_amount      списано бонусами, integer minor units (фаза 2b)
 * @property int $fee_amount
 * @property int $total_amount
 * @property string $currency
 * @property string $status         'pending' | 'awaiting_payment' | 'paid' | 'cancelled' | ...
 * @property string $payment_status 'pending' | 'succeeded' ...
 * @property string $customer_email
 * @property string|null $customer_name
 * @property string|null $customer_phone
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable|null $paid_at
 * @property \Carbon\CarbonImmutable|null $cancelled_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property int|null $promo_code_id
 * @property int|null $cart_id
 */
class Order extends Model
{
    use HasPublicId;
    use TenantScoped;

    protected static function tenantScopeEnabled(): bool
    {
        return true;
    }

    /**
     * Резолв route-model-binding вне глобального тенант-скоупа.
     *
     * Заказ адресуется по id в маршрутах, где доступ проверяется ПОСЛЕ резолва:
     * `OrderController::show()` — `assertCanSee()` (владелец/гость/сотрудник),
     * `cancel`/`refund` — middleware `admin`, embed — токен+origin. Если резолвить
     * под глобальным скоупом (фаза 2), маршрут без активной организации упал бы
     * `TenantContextMissingError` ещё до проверки доступа. Поэтому резолв работает
     * вне скоупа, а авторизация остаётся там, где она и была.
     */
    public function resolveRouteBinding($value, $field = null): ?Model
    {
        return app(OrganizationContext::class)->withoutScope(
            fn (): ?Model => parent::resolveRouteBinding($value, $field)
        );
    }

    protected $table = 'orders';

    protected $fillable = [
        'public_id',
        'order_number',
        'organization_id',
        'user_id',
        'session_id',
        'event_id',
        'subtotal_amount',
        'discount_amount',
        'bonus_amount',
        'fee_amount',
        'total_amount',
        'currency',
        'status',
        'payment_status',
        'customer_email',
        'customer_name',
        'customer_phone',
        'paid_at',
        'cancelled_at',
        'reminder_sent_at',
        'promo_code_id',
        'cart_id',
    ];

    protected $casts = [
        'subtotal_amount' => 'integer',
        'discount_amount' => 'integer',
        'bonus_amount' => 'integer',
        'fee_amount' => 'integer',
        'total_amount' => 'integer',
        'session_id' => 'integer',
        'event_id' => 'integer',
        'cart_id' => 'integer',
        'paid_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'reminder_sent_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        // `public_id` заполняет трейт HasPublicId; здесь — только номер заказа,
        // который нужен человеку в переписке и не является внешним ключом.
        static::creating(function (Order $model): void {
            if ($model->order_number === null) {
                $model->order_number = 'NB-' . now()->format('Ymd') . '-' . strtoupper(Str::random(8));
            }
        });
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    /**
     * Билеты заказа.
     *
     * Связь отсутствовала, хотя колонка `tickets.order_id` есть и
     * `OrderController::show()` её запрашивал: `$order->load([... 'tickets' ...])`
     * падал с «Call to undefined relationship [tickets] on model [Order]» → 500
     * на карточке заказа в админке. `OrderItem::tickets()` тоже не подходит как
     * замена: у `OrderItem` такой связи нет, а FK ведёт прямо на заказ.
     */
    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(Session::class);
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class);
    }
}