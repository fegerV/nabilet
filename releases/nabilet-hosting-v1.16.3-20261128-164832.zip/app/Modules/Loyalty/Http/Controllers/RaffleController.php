<?php

declare(strict_types=1);

namespace Nabilet\Modules\Loyalty\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Nabilet\Core\Errors\NotFoundError;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Core\Users\Models\User;
use Nabilet\Modules\Loyalty\Http\Resources\RaffleResultsResource;
use Nabilet\Modules\Loyalty\Models\Raffle;
use Nabilet\Modules\Loyalty\Services\RaffleService;
use Nabilet\Modules\Loyalty\StateMachines\RaffleStateMachine;

/**
 * Розыгрыши «счастливый билет» на витрине (фаза 5).
 *
 * ДВА ПУТИ С РАЗНЫМ ДОСТУПОМ
 *   `index()` — кабинет покупателя под `auth:api`: «в каких розыгрышах есть
 *   мои билеты». `results()` — публичная страница результатов: её открывают
 *   без аккаунта, и наружу уходит только маска победителя
 *   (`RaffleResultsResource`).
 *
 * ПОЧЕМУ ЧЕРНОВИКИ И ОТМЕНЁННЫЕ НЕ ВИДНЫ НИГДЕ
 *   Черновик ещё не существует для покупателя (он в процессе настройки),
 *   отменённый закончился ничьей. Показывать «вы участвовали» в отменённом
 *   розыгрыше — обещать приз, который не будет; смотреть «результаты»
 *   черновика — нечего. Отбор по `RaffleStateMachine::visible()`.
 */
class RaffleController extends Controller
{
    public function __construct(
        private readonly RaffleService $raffles,
    ) {
    }

    /**
     * GET /api/v1/me/raffles — мои участия.
     *
     * Пустой список — не 404: покупатель без билетов не ошибся, у него просто
     * ещё нет розыгрышей. Ответ всегда 200 с `data: []`.
     */
    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        return response()->json([
            'data' => $this->raffles->myRaffles($user),
        ]);
    }

    /**
     * GET /api/v1/raffles — публичный список акций витрины.
     *
     * Только видимые статусы и только организация текущего контекста: гость без
     * OrganizationContext видит пустой список, а не розыгрыши всех арендаторов.
     */
    public function publicIndex(): JsonResponse
    {
        $organizationId = app(OrganizationContext::class)->idOrNull();
        if ($organizationId === null) {
            return response()->json(['data' => []]);
        }

        $raffles = app(OrganizationContext::class)->withoutScope(
            fn () => Raffle::query()
                ->where('organization_id', $organizationId)
                ->whereIn('status', RaffleStateMachine::visible())
                ->orderByDesc('id')
                ->limit(50)
                ->get(['public_id', 'title', 'status', 'starts_at', 'ends_at'])
                ->map(static fn ($r): array => [
                    'public_id' => (string) $r->public_id,
                    'title' => (string) $r->title,
                    'status' => (string) $r->status,
                    'starts_at' => $r->starts_at?->toIso8601String(),
                    'ends_at' => $r->ends_at?->toIso8601String(),
                ])
                ->all()
        );

        return response()->json(['data' => $raffles]);
    }

    /**
     * GET /api/v1/raffles/{public_id} — результаты розыгрыша (публично).
     *
     * 404 для черновика, отменённого и несуществующего: у всех трёх случаев
     * один смысл для посетителя — «этой страницы нет».
     */
    public function results(string $publicId): JsonResponse
    {
        // Публичная страница без auth: у гостя контекста нет. Владение здесь
        // решает сам unguessable `public_id` (26 символов) — capability-путь,
        // как embed-ключ корзины, поэтому lookup и счётчик участников — в
        // bypass: без него админский фильтр отрезал бы гостя, а не чужих.
        $raffle = app(OrganizationContext::class)->withoutScope(
            fn (): ?Raffle => $this->raffles->findByPublicId($publicId)
        );

        if ($raffle === null || !in_array((string) $raffle->status, RaffleStateMachine::visible(), true)) {
            throw new NotFoundError('Raffle', $publicId);
        }

        // Счётчик участников грузится тем же ответом: страница показывает
        // «билетов было N», и отдельный запрос под него — лишний круг.
        //
        // Публичная страница результатов не имеет tenant-контекста, а
        // победитель резолвится через `entry.order` (маскировка адреса).
        // Загрузка призов, победителей и билетов идёт под тем же bypass —
        // все три кластерные модели (Raffle, RafflePrize, RaffleWinner,
        // RaffleEntry) скоупнуты, и ленивая связь у гостя была бы отказом.
        return app(OrganizationContext::class)->withoutScope(
            fn () => RaffleResultsResource::make(
                $raffle->load(['orderedPrizes', 'winners'])->loadCount('entries')
            )->response()
        );
    }
}
