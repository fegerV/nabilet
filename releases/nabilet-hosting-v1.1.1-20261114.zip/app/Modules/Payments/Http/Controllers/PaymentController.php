<?php

declare(strict_types=1);

namespace Nabilet\Modules\Payments\Http\Controllers;

use Nabilet\Core\Errors\NotFoundError;
use Nabilet\Core\Errors\ValidationError;
use Nabilet\Core\Idempotency\IdempotencyHeader;
use Nabilet\Core\Support\StaffRole;
use Nabilet\Core\Support\Paging;
use Nabilet\Core\Support\UserOrganization;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Cart\Models\Cart;
use Nabilet\Modules\Cart\Support\CartToken;
use Nabilet\Modules\Orders\Models\Order;
use Nabilet\Modules\Payments\Models\Payment;
use Nabilet\Modules\Payments\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

/**
 * Платежи.
 *
 * Префикс закрыт `auth:api` (routes/api.php), но одной авторизации мало: без
 * проверки владельца любой залогиненный пользователь видел список всех платежей
 * и любой платёж по id, а `POST /payments` позволял инициировать оплату по
 * чужому `order_id`. Владелец платежа — владелец заказа (`payment.order.user_id`).
 *
 * Сотрудник (admin/manager) видит все платежи; обычный пользователь — только
 * свои, принудительно. Чужой платёж — 404 (см. `NotFoundError`).
 */
class PaymentController extends Controller
{
    public function __construct(
        private readonly PaymentService $paymentService,
        private readonly OrganizationContext $context,
    ) {}

    public function index(Request $request): JsonResponse
    {
        // `organization_id` добавлен в список: без него он не доходил до сервиса,
        // а сервис на его отсутствие отвечает пустым результатом — список
        // платежей был пуст всегда.
        $filters = $request->only(['order_id', 'status', 'provider', 'organization_id', 'user_id']);
        $perPage = Paging::limit((int) $request->get('per_page', 20), 20, 100);

        if (! StaffRole::isStaff($request->user())) {
            // Обычный пользователь: скоуп — свои платежи. Принудительно, а не
            // «если не задан», иначе чужой user_id в query вернул бы чужие.
            $filters['user_id'] = $request->user()->id;
        } else {
            // Сотрудник: скоуп — его организация. Сервис fail-closed (без скоупа
            // отдаёт пустой результат), поэтому организация обязана быть
            // заполнена. Именно её отсутствие и делало список пустым раньше.
            // Показывать платежи ВСЕХ организаций нельзя: это и есть
            // межарендаторская утечка, от которой защищает сервис.
            //
            // Само членство — `UserOrganization`, как и везде: здесь стоял
            // `->value()` без сортировки, то есть у сотрудника с двумя
            // членствами ответ зависел от порядка строк в MySQL.
            $organizationId = $this->context->idOrNull() ?? UserOrganization::id($request->user());

            if ($organizationId === null) {
                throw new ValidationError([
                    'organization_id' => ['organization_id is required for this account.'],
                ]);
            }

            // `organization_id` из query не расширяет выборку: чужое значение
            // отвергается. Раньше оно уходило в репозиторий как есть, и admin
            // организации A мог запросить платежи организации B.
            $requested = $filters['organization_id'] ?? null;

            if ($requested !== null
                && (! is_scalar($requested) || (int) $requested !== $organizationId)
            ) {
                throw new ValidationError([
                    'organization_id' => ['organization_id does not belong to this account.'],
                ]);
            }

            $filters['organization_id'] = $organizationId;
        }

        // Покупатель читает транзакции детей СВОИХ платежей (фильтр по
        // user_id выше) без тенант-контекста: со включённым скоупом
        // `PaymentTransaction` eager-load в списке отказал бы. Сотрудник
        // идёт под своей организацией — скоуп лишь повторяет её же фильтр.
        $payments = StaffRole::isStaff($request->user())
            ? $this->paymentService->paginate($filters, $perPage)
            : $this->context->withoutScope(fn () => $this->paymentService->paginate($filters, $perPage));

        return response()->json([
            'data' => $payments,
            'meta' => [
                'current_page' => $payments->currentPage(),
                'per_page' => $payments->perPage(),
                'total' => $payments->total(),
                'last_page' => $payments->lastPage(),
            ],
        ]);
    }

    public function show(Request $request, Payment $payment): JsonResponse
    {
        $this->assertCanSee($request, $payment);

        // Дети — через уже авторизованного родителя: у покупателя организации
        // в контексте нет (см. assertCanSee ниже), скоупы `Order`/`Refund`
        // отказали бы на ленивой загрузке.
        $this->context->withoutScope(function () use ($payment): void {
            $payment->load(['order', 'transactions', 'refunds']);
        });

        return response()->json(['data' => $payment]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            // Здесь стояло `['bail','required','integer','exists:orders,id']`, и это
            // ломало последний шаг покупки. Внешний идентификатор заказа в этой
            // схеме — ULID `public_id` (так его отдаёт `OrderResource.id`, так
            // объявлен `docs/openapi.yaml#OrderIdPath: {type: string}` и именно его
            // возвращает `POST /cart/checkout` в поле `order_id`). Правило
            // `integer` отбраковало этот ULID раньше, чем дело доходило до поиска:
            // витрина получала 422 VALIDATION_ERROR на СВОЁМ ЖЕ ответе checkout, и
            // цепочка «выбрать место → корзина → оплатить» не проходила никогда.
            // Проверено на живом стенде.
            //
            // Тип не ограничиваем правилом `string`: админка и скрипты шлют
            // `orders.id` числом, и правило отбросило бы их 422-й. Существование
            // заказа проверяет `resolveOrder()`, а не правило `exists`: без
            // `bail`+`integer` MySQL приводит строку к числу (`id = '1abc'`
            // совпадает с 1), и `exists` пропускал бы мусор.
            'order_id' => ['bail', 'required'],
            // S-07: ключ обязателен по существу, но источником может быть и
            // заголовок `Idempotency-Key` (имя из контракта) — поэтому здесь он
            // `nullable`, а требование «непустой» выставляет сервис, который
            // умеет читать только итоговое значение. Правило `max:255` остаётся:
            // оно ловит тело до сервиса и даёт штатный 422 в конверте Laravel.
            'idempotency_key' => ['nullable', 'string', 'max:255'],
        ]);

        $reference = $validated['order_id'];

        // Массив/объект в `order_id` — ошибка клиента, а не 500 на приведении типа.
        if (! is_scalar($reference)) {
            throw new ValidationError([
                'order_id' => ['The order id must be a string or an integer.'],
            ]);
        }

        $order = $this->resolveOrder((string) $reference);

        // Оплатить можно только свой заказ: без этой проверки `order_id` из тела
        // позволял инициировать платёж по чужому заказу и получить ссылку на
        // оплату с его суммой. Чужой/несуществующий заказ — 404, не 403.
        if ($order === null || ! $this->mayPay($request, $order)) {
            throw new NotFoundError('Order', (string) $validated['order_id']);
        }

        // S-07: ключ идемпотентности обязателен. Контракт объявляет его
        // заголовком `Idempotency-Key` (`docs/openapi.yaml`), витрина шлёт телом
        // `idempotency_key` — принимаем оба, чтобы требование не зависело от
        // транспорта. Заголовок может прийти массивом (дубли), поэтому в сервис
        // уходит только строка; пустое значение отсекает `initiatePayment()`.
        $idempotencyKey = $validated['idempotency_key'] ?? $request->header(IdempotencyHeader::NAME);

        $result = $this->paymentService->initiatePayment(
            (int) $order->id,
            ['idempotency_key' => is_string($idempotencyKey) ? $idempotencyKey : null],
        );

        // 200 на повторе, 201 только на реальном создании: клиент по коду
        // отличает «я только что начал платёж» от «я повторяю тот же запрос»,
        // а не догадывается по телу ответа.
        return response()->json(['data' => [
            'payment' => $result['payment'],
            'confirmation_url' => $result['confirmation_url'],
        ]], $result['created'] ? 201 : 200);
    }

    /**
     * Найти заказ по внешнему идентификатору.
     *
     * Принимает обе формы, которыми заказ адресуют в системе:
     *   1. ULID `public_id` — то, что отдаёт `POST /cart/checkout` (`order_id`) и
     *      `OrderResource.id`; основной внешний идентификатор;
     *   2. числовой `orders.id` — админка и внутренние скрипты.
     *
     * Числовой вариант распознаётся только если строка ЦЕЛИКОМ из цифр: MySQL
     * сравнивает `id` со строкой, приводя её к числу, поэтому `'1abc'` совпал бы
     * с заказом 1 и открыл бы чужой заказ. Здесь — точное совпадение либо ULID.
     *
     * ПОЧЕМУ ПОИСК В BYPASS. Маршрут открыт гостю (оплата — последний шаг
     * гостевой витрины), а у гостя тенант-контекста нет: скоупнутый запрос
     * упал бы `TenantContextMissingError` (500) там, где контракт ждёт
     * платёжную ссылку или 404. Доступ решает исключительно `mayPay()` ниже —
     * сотрудник по организации заказа, владелец по `user_id`, гость по
     * capability-токену корзины; скоуп ничего бы сюда не добавил, только
     * сломал гостевую ветку.
     */
    private function resolveOrder(string $reference): ?Order
    {
        $reference = trim($reference);

        if ($reference === '') {
            return null;
        }

        return $this->context->withoutScope(
            fn (): ?Order => ctype_digit($reference)
                ? Order::query()->find((int) $reference)
                : Order::query()->where('public_id', $reference)->first()
        );
    }

    /**
     * Кто вправе оплатить заказ.
     *
     * Витрина — гостевой сценарий: корзина ключуется `X-Cart-Token`, покупатель
     * не логинится, поэтому у заказа `user_id = NULL` (проверено на живом
     * заказе: `CartCheckoutService::checkout()` его не проставляет). Проверка «заказ мой
     * по user_id» для такого заказа не проходит НИКОГДА, а маршрут стоял под
     * `auth:api` — то есть оплатить гостевой заказ было нельзя ни анонимно
     * (401), ни залогиненным (404). Сквозной сценарий «выбрать место → корзина →
     * оплатить» обрывался на последнем шаге.
     *
     * Право даёт одно из трёх:
     *   1. сотрудник (admin/manager) — видит и оплачивает заказы СВОЕЙ организации;
     *   2. владелец — заказ привязан к аккаунту и совпадает с `$request->user()`;
     *   3. гость, предъявивший `X-Cart-Token` той корзины, из которой создан заказ.
     *
     * Токен — это capability: UUID выдаётся браузеру покупателя при первом
     * добавлении места и больше нигде не публикуется. Без него чужой заказ
     * по-прежнему 404, поэтому IDOR остаётся закрытым — `order_id` сам по себе
     * не даёт ничего. Токен нормализуется (`CartToken::normalize()`: длина и
     * алфавит), сравнение идёт с `cart_token` в БД, а не с пользовательским вводом.
     *
     * Явная проверка `$user !== null` нужна и технически: прежний код обращался
     * к `$request->user()->id` без неё, и анонимный запрос к заказу с
     * заполненным `user_id` упал бы фаталом «Call to a member function on null».
     */
    private function mayPay(Request $request, Order $order): bool
    {
        if (StaffRole::isStaff($request->user())
            && $this->context->allows($order->organization_id)
        ) {
            return true;
        }

        return $this->holdsRequestAccess($request, $order);
    }

    /**
     * Есть ли у запроса право доступа к заказу помимо сотрудника.
     *
     *   1. владелец — заказ привязан к аккаунту и совпадает с `$request->user()`;
     *   2. гость, предъявивший `X-Cart-Token` той корзины, из которой создан заказ.
     *
     * Токен — это capability: UUID выдаётся браузеру покупателя при первом
     * добавлении места и больше нигде не публикуется. Без него чужой заказ
     * по-прежнему 404, поэтому IDOR остаётся закрытым — `order_id`/`payment_id`
     * сами по себе не дают ничего. Токен нормализуется (`CartToken::normalize()`:
     * длина и алфавит), сравнение идёт с `cart_token` в БД, а не с пользовательским вводом.
     *
     * Явная проверка `$user !== null` нужна и технически: прежний код обращался
     * к `$request->user()->id` без неё, и анонимный запрос к заказу с
     * заполненным `user_id` упал бы фаталом «Call to a member function on null».
     */
    private function holdsRequestAccess(Request $request, Order $order): bool
    {
        $user = $request->user();

        if ($user !== null && $order->user_id !== null && (int) $order->user_id === (int) $user->id) {
            return true;
        }

        $token = CartToken::fromRequest($request);

        if ($token === null || $order->cart_id === null) {
            return false;
        }

        // Токен корзины — capability гостя: заказ уже авторизован выше,
        // владение решает сравнение токена в фильтре — чтение в bypass.
        return app(OrganizationContext::class)->withoutScope(
            fn () => Cart::query()
                ->where('id', $order->cart_id)
                ->where('cart_token', $token)
                ->exists()
        );
    }

    /**
     * Возврат денег по платежу (ТЗ §85).
     *
     * `RefundService` был реализован полностью — валидация остатка, машина
     * состояний возврата, запрос к провайдеру, RefundLedger — но НЕ вызывался ни
     * одним маршрутом: возвраты существовали только в коде и тестах. Оператор не
     * мог вернуть деньги покупателю ни из админки, ни через API.
     *
     * Роут закрыт `admin`: возврат — финансовая операция, её не должен уметь
     * инициировать сам покупатель.
     */
    public function refund(Request $request, Payment $payment): JsonResponse
    {
        $this->assertCanSee($request, $payment);

        $validated = $request->validate([
            // Без `amount` возвращается весь остаток платежа.
            'amount' => ['nullable', 'integer', 'min:1'],
            'reason' => ['nullable', 'string', 'max:500'],
        ]);

        $payment = $this->paymentService->refundPayment(
            $payment,
            $validated['amount'] ?? null,
            $validated['reason'] ?? null,
        );

        return response()->json([
            // Дети URL-авторизованного платежа — в bypass, как в show().
            'data' => $this->context->withoutScope(
                fn () => $payment->load(['refunds', 'transactions'])
            ),
        ]);
    }

    /**
     * Fail-closed: чужой платёж неотличим от несуществующего.
     *
     * Гость витрины допускается по тому же capability, что и к `POST /payments`
     * (`X-Cart-Token` корзины, из которой создан заказ). Без этого страница
     * результата не могла получить авторитетный статус платежа: у гостевого
     * заказа `user_id = NULL`, и прежняя проверка только по владельцу отвечала
     * 404 — экран показывал «Билеты готовы», не спросив сервер (C2).
     */
    private function assertCanSee(Request $request, Payment $payment): void
    {
        // Заказ — ребёнок уже найденного платежа (route-binding), решение о
        // доступе принимается ниже по владельцу/токену корзины/членству.
        // Покупатель без staff-организации не имеет контекста, поэтому чтение
        // ребёнка — в bypass (см. OrderController::show).
        $order = $this->context->withoutScope(fn () => $payment->order);

        // Владелец заказа или гость с capability-токеном — доступ есть
        // независимо от роли: сотрудник тоже может быть покупателем.
        if ($order !== null && $this->holdsRequestAccess($request, $order)) {
            return;
        }

        // Сотрудник — только в пределах активной организации. Раньше здесь
        // стоял безусловный `return`, и admin организации A читал платёж
        // организации B, зная его id.
        if (StaffRole::isStaff($request->user())) {
            $this->context->assertCanAccess(
                $order?->organization_id,
                'Payment',
                (string) $payment->public_id,
            );

            return;
        }

        throw new NotFoundError('Payment', (string) $payment->public_id);
    }

    /**
     * Симулятор успешной оплаты для локальной разработки.
     *
     * Маршрут открыт (вне `auth:api`) намеренно: он воспроизводит возврат
     * покупателя с внешней платёжной страницы, а тот может быть не залогинен.
     * Защита — сам флаг `nabilet.payment.demo_mode`: по умолчанию он `false`, и
     * тогда метод отвечает 403, ничего не подтверждая. На проде этот флаг
     * включать нельзя — иначе платёж можно подтвердить анонимным запросом.
     */
    public function demoPay(Request $request): JsonResponse
    {
        // Только в demo-режиме: симулятор успешной оплаты.
        if (! (bool) config('nabilet.payment.demo_mode', false)) {
            return response()->json([
                'error' => ['code' => 'DEMO_DISABLED', 'message' => 'Demo mode is off'],
            ], 403);
        }

        // Второй барьер (аудит R-13). Маршрут анонимен и подтверждает оплату, а
        // защищён был ТОЛЬКО флагом из `.env`. Флаг переживает копирование
        // конфига между окружениями, поэтому окружение проверяется независимо от
        // него: в продакшене эндпоинт отказывает даже при включённом флаге.
        // `ProductionSafetyProvider` не даёт приложению подняться с этим флагом,
        // но барьер в самом эндпоинте не зависит от того, зарегистрирован ли
        // провайдер.
        if (app()->environment('production')) {
            return response()->json([
                'error' => [
                    'code' => 'DEMO_FORBIDDEN',
                    'message' => 'Demo payments are disabled in production',
                ],
            ], 403);
        }

        $paymentId = (string) $request->get('payment_id', '');

        if ($paymentId === '') {
            return response()->json([
                'error' => ['code' => 'MISSING_PAYMENT_ID', 'message' => 'payment_id is required'],
            ], 422);
        }

        $payment = $this->paymentService->confirmDemoPayment($paymentId);

        return response()->json(['data' => $payment]);
    }
}
