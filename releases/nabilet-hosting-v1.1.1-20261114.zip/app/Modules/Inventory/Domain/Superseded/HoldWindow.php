<?php

declare(strict_types=1);

namespace Nabilet\Modules\Inventory\Domain\Superseded;

use Nabilet\Core\Errors\DomainRuleViolation;

/**
 * The lifetime of a seat hold (ТЗ §24, §84).
 *
 * DEFAULT 10 MINUTES, CONFIGURABLE RANGE 5–30 — the spec states the range, so it
 * is enforced here rather than trusted from config. A TTL of 0 would let the
 * sweeper free a seat from under someone mid-checkout; a TTL of an hour would
 * pin inventory for a buyer who wandered off, which is a denial-of-sale against
 * everyone else.
 *
 * THE GRACE PERIOD IS PART OF THE WINDOW, NOT AN AFTERTHOUGHT.
 * `expires_at` is when the hold stops being *honoured*; the sweeper releases it
 * only at `expires_at + grace`. A buyer who hits "pay" at 09:59:59 must not have
 * the seat stolen by a job that runs at 10:00:00.
 *
 * ВНИМАНИЕ: ЭТОТ КЛАСС НЕ ИСПОЛЬЗУЕТСЯ В ПРОДАКШЕНЕ.
 * -----------------------------------------------------------------------
 * Он остаётся доменной моделью «как должно быть» и покрыт юнит-тестами
 * (`InventoryStockTest`, `CartTest`), но боевой путь удержания идёт мимо него,
 * и числа там ДРУГИЕ:
 *
 *                       | HoldWindow (этот файл) | реальный прод-путь
 *   --------------------+------------------------+--------------------------------
 *   срок удержания      | 600 с (10 мин)         | `CHECKOUT_HOLD_DURATION`,
 *                       |                        | по умолчанию 15 мин
 *                       |                        | (config/nabilet.php →
 *                       |                        |  CartService::holdDurationMinutes()
 *                       |                        |  → carts.expires_at)
 *   grace перед снятием | 30 с                   | 5 минут по умолчанию,
 *                       |                        | из `nabilet.checkout.
 *                       |                        |  hold_grace_minutes`
 *                       |                        |  (CHECKOUT_HOLD_GRACE_MINUTES)
 *
 * Число grace в прод-пути больше НЕ захардкожено: `HoldSweeper`,
 * `Orders\Models\SeatHold::isConvertible()` и
 * `Payments\Services\PaymentService::isHoldConvertible()` читают один ключ
 * конфига. Рассинхрон между ними = оплата в grace-окне приходит на место,
 * которое sweeper уже вернул в продажу. Значение `DEFAULT_GRACE_SECONDS`
 * (30 с) относится только к этой доменной модели и в проде не используется.
 */
final class HoldWindow
{
    public const MIN_TTL_SECONDS = 300;
    public const MAX_TTL_SECONDS = 1800;
    public const DEFAULT_TTL_SECONDS = 600;
    public const DEFAULT_GRACE_SECONDS = 30;

    private function __construct(
        private readonly \DateTimeImmutable $expiresAt,
        private readonly int $graceSeconds,
    ) {
    }

    public static function openingAt(\DateTimeImmutable $now, ?int $ttlSeconds = null, int $graceSeconds = self::DEFAULT_GRACE_SECONDS): self
    {
        $ttl = $ttlSeconds ?? self::DEFAULT_TTL_SECONDS;

        if ($ttl < self::MIN_TTL_SECONDS || $ttl > self::MAX_TTL_SECONDS) {
            throw new DomainRuleViolation(
                sprintf(
                    'Hold TTL must be between %d and %d seconds (5–30 minutes), got %d.',
                    self::MIN_TTL_SECONDS,
                    self::MAX_TTL_SECONDS,
                    $ttl
                ),
                'INVALID_HOLD_TTL'
            );
        }

        if ($graceSeconds < 0) {
            throw new DomainRuleViolation('Hold grace cannot be negative.', 'INVALID_HOLD_TTL');
        }

        return new self($now->modify(sprintf('+%d seconds', $ttl)), $graceSeconds);
    }

    public function expiresAt(): \DateTimeImmutable
    {
        return $this->expiresAt;
    }

    public function graceSeconds(): int
    {
        return $this->graceSeconds;
    }

    /** The hold is no longer honoured — but the seat is not necessarily free yet. */
    public function isExpiredAt(\DateTimeImmutable $now): bool
    {
        return $now >= $this->expiresAt;
    }

    /** The moment the sweeper may return the units to the pool. */
    public function releasableAt(): \DateTimeImmutable
    {
        return $this->expiresAt->modify(sprintf('+%d seconds', $this->graceSeconds));
    }

    public function isReleasableAt(\DateTimeImmutable $now): bool
    {
        return $now >= $this->releasableAt();
    }
}
