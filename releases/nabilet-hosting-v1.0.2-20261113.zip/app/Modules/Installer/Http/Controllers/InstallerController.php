<?php

declare(strict_types=1);

namespace Nabilet\Modules\Installer\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Routing\Controller;
use Illuminate\Validation\ValidationException;
use Nabilet\Core\Support\PublicationStatus;
use Nabilet\Modules\Core\Support\PublicId;
use Nabilet\Modules\Core\Users\Domain\UserStatus;
use Nabilet\Modules\Installer\Support\PreinstallAppKey;

/**
 * InstallerController — пошаговый установщик системы для шаред-хостинга.
 *
 * Предназначен для одноразового использования при первом запуске:
 * 1. Проверка требований сервера (PHP, расширения, права доступа)
 * 2. Настройка подключения к БД и запись .env
 * 3. Запуск миграций и сидеров
 * 4. Создание администратора (Vue-админка)
 * 5. Создание symbolic link для storage
 * 6. Блокировка повторного запуска через storage/install.lock
 *
 * После успешной установки файл storage/install.lock блокирует доступ к /install
 */
class InstallerController extends Controller
{
    /**
     * Шаблон генерируемого `.env`.
     *
     * ВАЖНО (аудит установщика B-3/B-4): этот блок — единственный источник
     * настроек после установки, и он же определяет, заработает ли система
     * «из коробки» без ручной правки файла.
     *
     *  - `QUEUE_CONNECTION=database`, а НЕ `sync`: письма и вебхуки уходят в
     *    очередь (`SendOrderNotificationJob`, `SendWebhookDeliveryJob`). При
     *    `sync` отправка выполняется прямо внутри HTTP-запроса покупателя —
     *    таймауты и деградация оформления заказа.
     *  - `CACHE_STORE`, а НЕ устаревший `CACHE_DRIVER`: `config/cache.php`
     *    читает именно `CACHE_STORE`, поэтому `CACHE_DRIVER` молча игнорировался
     *    и драйвер брался по умолчанию — конфигурация вводила в заблуждение.
     *  - `SESSION_DRIVER=database`: сессии переживают перезапуск и не зависят от
     *    каталога `storage/` на шаред-хостинге.
     *  - блок `MAIL_*` обязателен: без него билеты и сброс пароля не доставляются.
     *  - `BROADCAST_CONNECTION` (Laravel 11+), а не `BROADCAST_DRIVER`.
     */
    private const ENV_TEMPLATE = <<<'ENV'
APP_NAME={APP_NAME}
APP_ENV={APP_ENV}
APP_KEY={APP_KEY}
APP_DEBUG={APP_DEBUG}
APP_URL={APP_URL}
APP_LOCALE={APP_LOCALE}
APP_FALLBACK_LOCALE={APP_FALLBACK_LOCALE}
APP_TIMEZONE={APP_TIMEZONE}

LOG_CHANNEL={LOG_CHANNEL}
LOG_LEVEL={LOG_LEVEL}

DB_CONNECTION={DB_CONNECTION}
DB_HOST={DB_HOST}
DB_PORT={DB_PORT}
DB_DATABASE={DB_DATABASE}
DB_USERNAME={DB_USERNAME}
DB_PASSWORD={DB_PASSWORD}
# Коллация обязательна: дефолт `config/database.php` (`''`) MySQL 8 отвергает
# ошибкой `Unknown collation: ''` на первом же запросе миграций (найдено
# прогоном визарда 2026-11-04: установка падала прямо на шаге migrate).
DB_CHARSET={DB_CHARSET}
DB_COLLATION={DB_COLLATION}

BROADCAST_CONNECTION=log
CACHE_STORE={CACHE_STORE}
# Хостинг без Redis (задокументированный сценарий Timeweb): стенд в БД —
# осознанный выбор. Без этого подтверждения ProductionSafetyAudit в
# production не даст приложению подняться (см. ProductionSafetyAudit).
NABILET_ALLOW_DATABASE_CACHE=true
FILESYSTEM_DISK={FILESYSTEM_DISK}
QUEUE_CONNECTION={QUEUE_CONNECTION}
SESSION_DRIVER={SESSION_DRIVER}
SESSION_LIFETIME=120

MAIL_MAILER={MAIL_MAILER}
MAIL_HOST={MAIL_HOST}
MAIL_PORT={MAIL_PORT}
MAIL_USERNAME={MAIL_USERNAME}
MAIL_PASSWORD={MAIL_PASSWORD}
MAIL_ENCRYPTION={MAIL_ENCRYPTION}
MAIL_FROM_ADDRESS={MAIL_FROM_ADDRESS}
MAIL_FROM_NAME={MAIL_FROM_NAME}

YOOKASSA_SHOP_ID={YOOKASSA_SHOP_ID}
YOOKASSA_SECRET_KEY={YOOKASSA_SECRET_KEY}
ENV;

    /**
     * Показать форму установщика или вернуть JSON с требованиями
     */
    public function show(Request $request)
    {
        // Если уже установлено — блокируем доступ
        if ($this->isInstalled()) {
            return $request->expectsJson()
                ? response()->json(['error' => [
                    'code' => 'ALREADY_INSTALLED',
                    'message' => 'Система уже установлена',
                    'details' => [],
                ]], 403)
                : redirect('/')->with('error', 'Система уже установлена');
        }

        $requirements = $this->checkRequirements();
        $passed = $requirements['passed'];

        if ($request->expectsJson()) {
            return response()->json([
                'step' => 'requirements',
                'passed' => $passed,
                'requirements' => $requirements['details'],
            ]);
        }

        return view('installer::install', [
            'passed' => $passed,
            'requirements' => $requirements['details'],
        ]);
    }

    /**
     * Обработать форму установки
     */
    public function install(Request $request): JsonResponse
    {
        // Если уже установлено — блокируем
        if ($this->isInstalled()) {
            return response()->json(['error' => [
                'code' => 'ALREADY_INSTALLED',
                'message' => 'Система уже установлена',
                'details' => [],
            ]], 403);
        }

        try {
            // Лимит PHP (по умолчанию 30 с у php-fpm на шаред-хостинге) считает
            // время работы ВНУТРИ одного запроса: миграции ~90 таблиц и bcrypt
            // в сидерах реально выходят за 30 с (найдено прогоном визарда
            // 2026-11-04: FatalError «Maximum execution time …» прямо в
            // Hashing\BcryptHasher). Установка — разовое действие, а не
            // пользовательский запрос: обнуляем лимит; если хостер запретил
            // set_time_limit, фолбэка нет — но и прежний лимит не спасал.
            @set_time_limit(0);

            $validated = $request->validate([
                'app_name' => ['required', 'string', 'max:255'],
                // production-шаблон (APP_ENV=production) против правила
                // `ProductionSafetyAudit::insecureAppUrl()`: если мастер примет
                // http://, приложение отвергнет собственный .env сразу после
                // установки и ляжет (tickets + платежи обязаны жить на HTTPS).
                // Отсекаем это НА форме, а не 500-й после неё.
                'app_url' => ['required', 'url', 'max:255', 'starts_with:https://'],
                'db_host' => ['required', 'string', 'max:255'],
                'db_port' => ['required', 'integer', 'between:1,65535'],
                'db_database' => ['required', 'string', 'max:255'],
                'db_username' => ['required', 'string', 'max:255'],
                'db_password' => ['required', 'string', 'max:255'],
                'admin_email' => ['required', 'email', 'max:255'],
                'admin_password' => ['required', 'string', 'min:8', 'max:255'],
                // Почта (SMTP). Необязательна на шаге установки: если хост не
                // задан, мастер пишет `MAIL_MAILER=log`, чтобы система работала
                // без падения на первой же отправке, а SMTP можно включить позже.
                'mail_host' => ['nullable', 'string', 'max:255'],
                'mail_port' => ['nullable', 'integer', 'between:1,65535'],
                'mail_username' => ['nullable', 'string', 'max:255'],
                'mail_password' => ['nullable', 'string', 'max:255'],
                'mail_encryption' => ['nullable', 'string', 'max:10'],
                'mail_from_address' => ['nullable', 'email', 'max:255'],
                'mail_from_name' => ['nullable', 'string', 'max:255'],
                'yookassa_shop_id' => ['nullable', 'string', 'max:255'],
                'yookassa_api_key' => ['nullable', 'string', 'max:255'],
            ], [
                'app_url.starts_with' => 'APP_URL должен начинаться с https:// — приложение '
                    . 'отдаёт билеты и принимает оплату; по http оно откажется подниматься.',
            ]);

            // Шаг 1: Проверка подключения к БД
            //
            // Порт приводится к int явно: `validate('integer')` не приводит типы,
            // а HTML-форма (без JS-визарда) присылает порт строкой — под
            // strict_types=1 это TypeError вместо установки (найдено
            // e2e-прогоном архива v1.0.1, 2026-11-13).
            $this->testDatabaseConnection(
                $validated['db_host'],
                (int) $validated['db_port'],
                $validated['db_database'],
                $validated['db_username'],
                $validated['db_password']
            );

            // Шаг 2: Запись .env файла (возвращает сгенерированный APP_KEY)
            $appKey = $this->writeEnvFile($validated);

            // Перед запуском Artisan-команд подменяем in-memory-конфиг реальными
            // учётными данными из формы. `config:clear` удаляет только кэш-файл, но
            // НЕ перечитывает Dotenv в уже загруженный репозиторий конфигурации,
            // поэтому без этой подмены `migrate`/seed уходили бы на boot-значения
            // (127.0.0.1 / forge), а не на введённую БД, и установка падала бы.
            config([
                'database.connections.mysql.host' => $validated['db_host'],
                'database.connections.mysql.port' => $validated['db_port'],
                'database.connections.mysql.database' => $validated['db_database'],
                'database.connections.mysql.username' => $validated['db_username'],
                'database.connections.mysql.password' => $validated['db_password'],
                // Коллация — та же ловушка, что креды: boot-конфиг (без .env)
                // содержит `''`, и MySQL 8 валит первый же запрос миграций
                // `Unknown collation: ''`. Значения обязаны совпадать с тем,
                // что шаблон кладёт в .env — их источником и был этот список.
                'database.connections.mysql.charset' => 'utf8mb4',
                'database.connections.mysql.collation' => 'utf8mb4_unicode_ci',
                'app.key' => $appKey,
                'app.url' => $validated['app_url'],
                'app.env' => 'production',
            ]);
            DB::purge('mysql');

            // Шаг 3: Очистка кэша конфигурации
            Artisan::call('config:clear');
            Artisan::call('cache:clear');

            // Шаг 4: Запуск миграций
            $migrateExitCode = Artisan::call('migrate', ['--force' => true]);
            if ($migrateExitCode !== 0) {
                throw new \RuntimeException('Не удалось выполнить миграции базы данных');
            }

            // Шаг 5: Создание администратора и его организации
            $this->createAdminUser($validated['admin_email'], $validated['admin_password'], $validated['app_name']);

            // Шаг 6: Создание symbolic link для storage
            try {
                Artisan::call('storage:link');
            } catch (\Throwable $e) {
                Log::warning('Installer: Не удалось создать storage:link', ['exception' => $e->getMessage()]);
                // Не блокируем установку, если symlink не работает
            }

            // Шаг 7: Запуск сидеров (если есть)
            try {
                Artisan::call('db:seed', ['--force' => true]);
            } catch (\Throwable $e) {
                Log::warning('Installer: Сидеры не выполнены', ['exception' => $e->getMessage()]);
            }

            // Шаг 8: Генерация APP_KEY если не был указан
            if (empty(config('app.key'))) {
                Artisan::call('key:generate', ['--force' => true]);
            }

            // Шаг 9: Блокировка повторной установки
            $this->markAsInstalled();

            Log::info('Installer: Система успешно установлена', [
                'app_name' => $validated['app_name'],
                'app_url' => $validated['app_url'],
                'db_host' => $validated['db_host'],
                'admin_email' => $validated['admin_email'],
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Система успешно установлена',
                // Hash-адрес, а не /admin: витрина и админка — один SPA на
            // hash-роутинге (createWebHashHistory), прямой /admin отдаёт
            // фирменную 404 (найдено e2e-прогоном архива v1.0.1, 2026-11-13).
            'redirect' => '/#/admin',
            ]);

        } catch (ValidationException $e) {
            return response()->json(['error' => [
                'code' => 'VALIDATION_ERROR',
                'message' => 'Ошибка валидации',
                'details' => ['fields' => $e->errors()],
            ]], 422);

        } catch (\Throwable $e) {
            Log::error('Installer: Критическая ошибка установки', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            // Внутреннее сообщение уходит только в лог: раньше оно
            // публиковалось клиенту и раскрывало текст драйвера БД и пути.
            return response()->json(['error' => [
                'code' => 'INSTALL_FAILED',
                'message' => 'Не удалось завершить установку. Подробности — в журнале.',
                'details' => [],
            ]], 500);
        }
    }

    /**
     * Проверить параметры подключения к БД, ничего не записывая на диск.
     *
     * Раньше кнопка «Проверить подключение» на шаге 2 была клиентской
     * имитацией (`setTimeout(…, 700)` + галочка), поэтому пользователь видел
     * «успех» при заведомо неверных кредах, а реальная проверка выполнялась
     * только внутри POST /install (аудит установщика §4 / W-3).
     */
    public function testDatabase(Request $request): JsonResponse
    {
        if ($this->isInstalled()) {
            return response()->json(['error' => [
                'code' => 'ALREADY_INSTALLED',
                'message' => 'Система уже установлена',
                'details' => [],
            ]], 403);
        }

        try {
            $validated = $request->validate([
                'db_host' => ['required', 'string', 'max:255'],
                'db_port' => ['required', 'integer', 'between:1,65535'],
                'db_database' => ['required', 'string', 'max:255'],
                'db_username' => ['required', 'string', 'max:255'],
                'db_password' => ['required', 'string', 'max:255'],
            ]);

            $this->testDatabaseConnection(
                $validated['db_host'],
                (int) $validated['db_port'],
                $validated['db_database'],
                $validated['db_username'],
                $validated['db_password']
            );

            return response()->json([
                'success' => true,
                'message' => 'Подключение установлено',
            ]);
        } catch (ValidationException $e) {
            return response()->json(['error' => [
                'code' => 'VALIDATION_ERROR',
                'message' => 'Заполните параметры подключения',
                'details' => ['fields' => $e->errors()],
            ]], 422);
        } catch (\Throwable $e) {
            // Сообщение PDO раскрывает драйвер и хост, но не учётные данные; на
            // шаге настройки это полезно. Точный текст остаётся в логе.
            return response()->json(['error' => [
                'code' => 'DB_CONNECTION_FAILED',
                'message' => 'Не удалось подключиться к базе данных. Проверьте хост, порт, имя БД и учётные данные.',
                'details' => [],
            ]], 422);
        }
    }

    /**
     * Проверить требования сервера
     */
    private function checkRequirements(): array
    {
        $details = [];
        $allPassed = true;

        // Проверка версии PHP.
        //
        // Требуем 8.3, а не 8.1: `composer.json` объявляет `"php": "^8.3"`, и
        // Composer platform-check в `vendor/` роняет процесс на более старой
        // версии. Раньше мастер пропускал шаг 1 на PHP 8.1/8.2, а затем падал
        // уже на `migrate` — получалась полу-установка с записанным `.env`
        // и базой на середине миграций (аудит установщика B-1).
        $phpVersion = PHP_VERSION;
        $phpRequired = '8.3';
        $phpPassed = version_compare($phpVersion, $phpRequired, '>=');
        $details['php_version'] = [
            'name' => 'Версия PHP (≥' . $phpRequired . ')',
            'passed' => $phpPassed,
            'current' => $phpVersion,
            'required' => $phpRequired,
        ];
        if (!$phpPassed) {
            $allPassed = false;
        }

        // Проверка расширений
        $extensions = ['pdo', 'mbstring', 'openssl', 'json', 'xml', 'curl', 'zip'];
        foreach ($extensions as $ext) {
            $extLoaded = extension_loaded($ext);
            $details['ext_' . $ext] = [
                'name' => 'Расширение ' . $ext,
                'passed' => $extLoaded,
                'current' => $extLoaded ? 'установлено' : 'не установлено',
                'required' => 'установлено',
            ];
            if (!$extLoaded) {
                $allPassed = false;
            }
        }

        // Проверка прав на запись.
        //
        // Корень проекта тоже в списке: именно туда пишется `.env`
        // (`writeEnvFile()`), и без права записи установка обрывалась бы уже
        // после успешного PDO-теста — «необъяснимым» 500 (аудит установщика §3).
        $writablePaths = [
            storage_path(),
            storage_path('logs'),
            storage_path('framework/cache'),
            storage_path('framework/views'),
            base_path('bootstrap/cache'),
            base_path(),
        ];

        foreach ($writablePaths as $path) {
            $isWritable = is_writable($path);
            $relativePath = str_replace(base_path(), '', $path) ?: '/';
            $details['writable_' . md5($path)] = [
                'name' => 'Права на запись: ' . $relativePath,
                'passed' => $isWritable,
                'current' => $isWritable ? 'запись разрешена' : 'запись запрещена',
                'required' => 'запись разрешена',
            ];
            if (!$isWritable) {
                $allPassed = false;
            }
        }

        // Проверка наличия .env
        $envExists = File::exists(base_path('.env'));
        $details['env_file'] = [
            'name' => 'Файл .env отсутствует',
            'passed' => !$envExists,
            'current' => $envExists ? 'существует' : 'отсутствует',
            'required' => 'отсутствует',
        ];
        // Это не блокирующее требование

        return [
            'passed' => $allPassed,
            'details' => $details,
        ];
    }

    /**
     * Тестирование подключения к БД
     */
    private function testDatabaseConnection(string $host, int $port, string $database, string $username, string $password): void
    {
        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4";
            $options = [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            ];

            new \PDO($dsn, $username, $password, $options);

            Log::info('Installer: Подключение к БД успешно', ['host' => $host, 'database' => $database]);

        } catch (\PDOException $e) {
            Log::error('Installer: Не удалось подключиться к БД', [
                'host' => $host,
                'database' => $database,
                'exception' => $e->getMessage(),
            ]);

            throw new \RuntimeException(
                'Не удалось подключиться к базе данных. Проверьте параметры подключения. ' .
                'На Timeweb хост БД может отличаться от localhost — используйте значение из панели управления.'
            );
        }
    }

    /**
     * Записать .env файл
     */
    private function writeEnvFile(array $data): string
    {
        $appKey = 'base64:' . base64_encode(random_bytes(32));
        $envContent = $this->buildEnvContent($data, $appKey);

        $envPath = base_path('.env');

        if (!File::put($envPath, $envContent)) {
            throw new \RuntimeException('Не удалось записать файл .env. Проверьте права на запись в корень проекта.');
        }

        Log::info('Installer: Файл .env успешно создан', [
            'mail_mailer' => str_contains($envContent, 'MAIL_MAILER=log') ? 'log' : 'smtp',
        ]);

        return $appKey;
    }

    /**
     * Собрать содержимое `.env` из шаблона и данных мастера.
     *
     * Вынесено отдельно от записи на диск, чтобы результат можно было
     * проверить тестом, не трогая реальный `.env` установки.
     */
    private function buildEnvContent(array $data, string $appKey): string
    {
        $mailHost = trim((string) ($data['mail_host'] ?? ''));
        $mailUsername = trim((string) ($data['mail_username'] ?? ''));
        $mailPassword = (string) ($data['mail_password'] ?? '');
        $mailEncryption = strtolower(trim((string) ($data['mail_encryption'] ?? '')));

        // Пока SMTP не задан, письма пишутся в лог. Это осознанный рабочий
        // режим, а не «тихий успех»: отправка не бросает исключение и не рвёт
        // оформление заказа, а SMTP можно включить позже в админке/`.env`.
        $mailer = $mailHost !== '' ? 'smtp' : 'log';

        $fromAddress = trim((string) ($data['mail_from_address'] ?? '')) ?: (string) $data['admin_email'];
        $fromName = trim((string) ($data['mail_from_name'] ?? '')) ?: (string) $data['app_name'];

        $replacements = [
            '{APP_NAME}' => $this->envValue((string) $data['app_name']),
            '{APP_ENV}' => 'production',
            '{APP_KEY}' => $appKey,
            '{APP_DEBUG}' => 'false',
            '{APP_URL}' => $this->envValue((string) $data['app_url']),
            '{APP_LOCALE}' => 'ru',
            '{APP_FALLBACK_LOCALE}' => 'en',
            '{APP_TIMEZONE}' => 'Europe/Moscow',
            '{LOG_CHANNEL}' => 'stack',
            '{LOG_LEVEL}' => 'debug',
            '{DB_CONNECTION}' => 'mysql',
            '{DB_HOST}' => $this->envValue((string) $data['db_host']),
            '{DB_PORT}' => (string) $data['db_port'],
            '{DB_DATABASE}' => $this->envValue((string) $data['db_database']),
            '{DB_USERNAME}' => $this->envValue((string) $data['db_username']),
            '{DB_PASSWORD}' => $this->envValue((string) $data['db_password']),
            '{DB_CHARSET}' => 'utf8mb4',
            '{DB_COLLATION}' => 'utf8mb4_unicode_ci',
            '{CACHE_STORE}' => 'database',
            '{FILESYSTEM_DISK}' => 'public',
            '{QUEUE_CONNECTION}' => 'database',
            '{SESSION_DRIVER}' => 'database',
            '{MAIL_MAILER}' => $mailer,
            '{MAIL_HOST}' => $this->envValue($mailHost),
            '{MAIL_PORT}' => ((string) ($data['mail_port'] ?? '')) !== '' ? (string) $data['mail_port'] : '587',
            '{MAIL_USERNAME}' => $this->envValue($mailUsername),
            '{MAIL_PASSWORD}' => $this->envValue($mailPassword),
            '{MAIL_ENCRYPTION}' => $this->envValue($mailEncryption),
            '{MAIL_FROM_ADDRESS}' => $this->envValue($fromAddress),
            '{MAIL_FROM_NAME}' => $this->envValue($fromName),
            '{YOOKASSA_SHOP_ID}' => $this->envValue((string) ($data['yookassa_shop_id'] ?? '')),
            '{YOOKASSA_SECRET_KEY}' => $this->envValue((string) ($data['yookassa_api_key'] ?? '')),
        ];

        // strtr() вместо str_replace(): подстановка по ключам за один проход,
        // без риска, что значение одного плейсхолдера случайно совпадёт с именем
        // другого. Раньше APP_NAME подставлялся отдельным str_replace поверх
        // шаблона — лишняя точка отказа.
        return strtr(self::ENV_TEMPLATE, $replacements);
    }

    /**
     * Привести значение к безопасной для `.env` форме.
     *
     * Креды БД, YooKassa и почты раньше писались «как есть»: пароль с пробелом,
     * `#`, кавычкой или переводом строки разрывал файл и ломал установку
     * (аудит установщика §7). Простые значения оставляем без кавычек — так
     * `.env` читается привычно, — остальные оборачиваем в двойные кавычки.
     */
    private function envValue(string $value): string
    {
        if ($value === '') {
            return '';
        }

        if (preg_match('/^[A-Za-z0-9_.:\/@\-]+$/', $value) === 1) {
            return $value;
        }

        return '"' . str_replace(
            ['\\', '"', "\r", "\n"],
            ['\\\\', '\\"', '', '\\n'],
            $value
        ) . '"';
    }

    /**
     * Создать пользователя-администратора
     */
    private function createAdminUser(string $email, string $password, string $orgName): void
    {
        $userId = null;

        // Каноничная модель — единственная, через которую теперь создаётся
        // пользователь (`App\Models\User` осталось легаси-именем-подклассом).
        // Ветка `DB::table()` ниже — не дубль, а запас на случай, когда модель
        // недоступна (сломанный автолоад): установщик обязан доработать до
        // админа, иначе инсталляция заканчивается мёртвым сайтом без входа.
        if (class_exists(\Nabilet\Modules\Core\Users\Models\User::class)) {
            $user = \Nabilet\Modules\Core\Users\Models\User::create([
                'first_name' => 'Administrator',
                'email' => $email,
                'password' => bcrypt($password),
                'email_verified_at' => now(),
                'status' => UserStatus::ACTIVE,
            ]);
            $userId = $user->id;
            Log::info('Installer: Администратор создан', ['id' => $userId, 'email' => $email]);
        } else {
            Log::warning('Installer: Модель User не найдена, создаем админа через DB');
            $userId = DB::table('users')->insertGetId([
                'public_id' => PublicId::generate(),
                'email' => $email,
                'password' => password_hash($password, PASSWORD_BCRYPT),
                'first_name' => 'Administrator',
                'status' => UserStatus::ACTIVE,
                'email_verified_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            Log::info('Installer: Администратор создан через DB', ['id' => $userId, 'email' => $email]);
        }

        if ($userId) {
            $this->bootstrapOrganization((int) $userId, $orgName);
        }
    }

    /**
     * Create the self-hosted install's default organization and attach the admin.
     *
     * The app is multi-tenant (every tenant-scoped row carries organization_id) and
     * ResolveOrganizationContext resolves the active org from the user's membership.
     * Without this the freshly installed admin would have no org context and
     * tenant-scoped queries would throw TenantContextMissingError. We create one
     * org + link the admin; fail-soft so the install never blocks.
     */
    private function bootstrapOrganization(int $userId, string $orgName): void
    {
        try {
            $slug = Str::slug($orgName) ?: 'organization';
            if (DB::table('organizations')->where('slug', $slug)->exists()) {
                $slug .= '-' . substr(md5((string) $userId . $orgName), 0, 6);
            }

            $organizationId = DB::table('organizations')->insertGetId([
                'public_id' => PublicId::generate(),
                'name' => $orgName,
                'slug' => $slug,
                'status' => PublicationStatus::ACTIVE,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $roleId = DB::table('roles')->where('slug', 'admin')->value('id');
            if ($roleId === null) {
                $roleId = DB::table('roles')->insertGetId([
                    'name' => 'Administrator',
                    'slug' => 'admin',
                    'description' => 'Full access (created by installer)',
                ]);
            }

            DB::table('user_organization')->updateOrInsert(
                ['user_id' => $userId, 'organization_id' => $organizationId],
                ['role_id' => $roleId, 'created_at' => now()]
            );

            DB::table('user_roles')->updateOrInsert(
                ['user_id' => $userId, 'organization_id' => $organizationId, 'role_id' => $roleId],
                ['granted_by' => null, 'created_at' => now()]
            );

            Log::info('Installer: Организация создана и админ привязан', [
                'organization_id' => $organizationId,
                'role_id' => $roleId,
                'user_id' => $userId,
            ]);
        } catch (\Throwable $e) {
            Log::warning('Installer: Не удалось создать организацию для админа', [
                'exception' => $e->getMessage(),
            ]);
            // Не блокируем установку: админ уже создан, организацию можно
            // дособрать позже из админки.
        }
    }

    /**
     * Проверить, установлена ли система
     */
    private function isInstalled(): bool
    {
        return File::exists(storage_path('install.lock'));
    }

    /**
     * Пометить систему как установленную
     */
    private function markAsInstalled(): void
    {
        File::put(storage_path('install.lock'), now()->toIso8601String());
        Log::info('Installer: Система помечена как установленная');

        // Временный ключ на окно установки больше не нужен: реальный APP_KEY
        // уже записан в .env, а с этого момента пустой/битый ключ обязан
        // падать громко (fail-loud) — временная подмена условия не ослабляет.
        // Оставленный файл был бы мёртвым грузом в списке «что это за файл».
        File::delete(PreinstallAppKey::persistencePath());
    }
}
