<?php

declare(strict_types=1);

namespace Nabilet\Modules\Venues\Halls\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Nabilet\Core\Errors\NotFoundError;
use Nabilet\Core\Errors\ValidationError;
use Nabilet\Core\Support\Paging;
use Nabilet\Core\Support\PublicationStatus;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Core\Support\PublicId;
use Nabilet\Modules\Venues\Models\Hall;
use Nabilet\Modules\Venues\Models\HallSchemaVersion;
use Nabilet\Modules\Venues\Models\Venue;
use Nabilet\Modules\Venues\Halls\Services\HallService;
use Nabilet\Modules\Venues\Halls\Http\Resources\HallResource;
use Nabilet\Modules\Venues\Halls\Http\Resources\HallCollection;
use Nabilet\Modules\Venues\Halls\Http\Resources\SchemaVersionResource;
use Nabilet\Modules\Venues\Halls\Domain\SchemaPayloadNormalizer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Hall and hall-schema endpoints.
 *
 * The five `abort(404, 'Hall not found')` calls this class used to contain are gone.
 * `abort()` hands the failure to Laravel's default renderer, which answers with
 * `{"message":"Hall not found","exception":"NotFoundHttpException","trace":[…]}`
 * — verified live. That is neither the §66 envelope nor safe in production. A
 * `NotFoundError` carries `HALL_NOT_FOUND` plus the public id, and travels through
 * `ApiExceptionRenderer` like every other failure.
 */
class HallController extends Controller
{
    public function __construct(
        protected HallService $service
    ) {}

    public function index(string $venuePublicId, Request $request): HallCollection
    {
        // Без клампа `?limit=1000000` уходил в пагинатор как есть (см. `Paging`).
        $limit = Paging::limit((int) $request->get('limit', 15), 15, 100);
        // `$venuePublicId`, не int: путь приводился к числу до вызова метода,
        // поэтому `/venues/1abc/halls` отдавал залы площадки 1. Площадка
        // ищется по public_id, отсутствие — 404 из сервиса.
        $halls = $this->service->findByVenue($venuePublicId, $limit);

        return new HallCollection($halls);
    }

    /**
     * Все залы (для формы сеанса в админке).
     */
    public function indexAll(): HallCollection
    {
        return new HallCollection($this->service->findAll());
    }

    public function show(string $publicId): HallResource
    {
        // Публичная страница зала (без auth): lookup зала — в bypass. Адрес
        // решает unguessable `public_id` (ULID), ресурс читает только
        // колонки строки и когда-то загруженные связи.
        $hall = app(OrganizationContext::class)->withoutScope(
            fn (): ?Hall => $this->service->findByPublicId($publicId)
        );

        if ($hall === null) {
            throw new NotFoundError('Hall', $publicId);
        }

        return new HallResource($hall);
    }

    public function store(Request $request): HallResource
    {
        $validated = $request->validate([
            // `bail`/`integer` guard the BIGINT lookup: MySQL does not reject a
            // comparison against a string, it coerces it, so `exists` can match
            // `'1abc'` to row 1. See `CartController::addItem()` for the measurements.
            'venue_id' => ['bail', 'required', 'integer', 'exists:venues,id'],
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'city' => ['nullable', 'string', 'max:150'],
            'address' => ['nullable', 'string', 'max:500'],
            'exterior_photo_url' => ['nullable', 'string', 'max:2048', 'url:https'],
            'interior_photo_url' => ['nullable', 'string', 'max:2048', 'url:https'],
            'capacity' => ['nullable', 'integer', 'min:0'],
            'width' => ['nullable', 'integer', 'min:0'],
            'height' => ['nullable', 'integer', 'min:0'],
            'status' => ['nullable', 'string', PublicationStatus::validationRule()],
        ]);

        // БД требует status NOT NULL.
        $validated['status'] ??= PublicationStatus::ACTIVE;

        $hall = $this->service->createHall($validated);

        return new HallResource($hall);
    }

    public function update(Request $request, string $publicId): HallResource
    {
        $hall = $this->findOrFail($publicId);

        $validated = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'city' => ['nullable', 'string', 'max:150'],
            'address' => ['nullable', 'string', 'max:500'],
            'exterior_photo_url' => ['nullable', 'string', 'max:2048', 'url:https'],
            'interior_photo_url' => ['nullable', 'string', 'max:2048', 'url:https'],
            'capacity' => ['sometimes', 'integer', 'min:0'],
            'width' => ['sometimes', 'integer', 'min:0'],
            'height' => ['sometimes', 'integer', 'min:0'],
        ]);

        $hall = $this->service->updateHall($hall, $validated);

        return new HallResource($hall);
    }

    public function destroy(string $publicId): JsonResponse
    {
        $this->service->deleteHall($this->findOrFail($publicId));

        return response()->json(['message' => 'Hall deleted successfully']);
    }

    public function getSchemaVersions(string $publicId): JsonResponse
    {
        $hall = $this->findOrFail($publicId);

        $versions = $this->service->getSchemaVersions($hall);

        return response()->json([
            'data' => SchemaVersionResource::collection($versions),
        ]);
    }

    /**
     * Публичная версия схемы для витрины (B10).
     *
     * Роут `/halls/{publicId}` открыт, но его ресурс не отдаёт geometry-схему,
     * а список версий скрыт под admin-middleware — витрине (`/event/:slug`,
     * выбор мест живёт на странице события) нечем рисовать посадку. Отдаём
     * ОДНУ опубликованную версию и только те поля, что нужны для рендера;
     * черновики наружу не светятся.
     */
    public function publishedSchema(string $publicId): JsonResponse
    {
        // Публичная схема для витрины мест (без auth): lookup зала — в bypass
        // (как в show), опубликованная версия схемы — в bypass внутри сервиса.
        $hall = app(OrganizationContext::class)->withoutScope(
            fn (): ?Hall => $this->service->findByPublicId($publicId)
        );

        if ($hall === null) {
            throw new NotFoundError('Hall', $publicId);
        }

        $version = $this->service->getPublishedSchemaVersion($hall);

        if ($version === null) {
            throw new NotFoundError('PublishedHallSchema', $publicId);
        }

        return response()->json([
            'data' => [
                'id' => $version->id,
                'public_id' => $version->public_id,
                'hall_id' => $version->hall_id,
                'version' => $version->version,
                'status' => $version->status,
                'width' => $version->width,
                'height' => $version->height,
                'background_url' => $version->background_url,
                // Та же нормализация формы, что и в SchemaVersionResource:
                // пустая карта rowPrices обязана быть объектом, а не массивом.
                'schema' => is_array($version->schema_json)
                    ? SchemaPayloadNormalizer::normalize($version->schema_json)
                    : $version->schema_json,
                'published_at' => $version->published_at?->toIso8601String(),
            ],
        ]);
    }

    public function createSchemaDraft(Request $request, string $publicId): SchemaVersionResource
    {
        $hall = $this->findOrFail($publicId);

        $validated = $request->validate([
            'payload' => ['required', 'array'],
            // B6: клиент может прислать id версии, которую считает черновиком.
            // Сервер проверяет принадлежность залу и статус draft; для
            // published/чужой — 409/404 в конверте §66 (см. HallService).
            'version_id' => ['nullable', 'integer', 'min:1'],
            'base_revision' => ['required_with:version_id', 'integer', 'min:1'],
        ]);

        $version = $this->service->createSchemaDraft(
            $hall,
            $validated['payload'],
            $request->user()->id,
            isset($validated['version_id']) ? (int) $validated['version_id'] : null,
            isset($validated['base_revision']) ? (int) $validated['base_revision'] : null,
        );

        return new SchemaVersionResource($version);
    }

    /**
     * Publish a draft schema version.
     *
     * The hall's public id is part of the path, not decoration: the service checks
     * that the version belongs to that hall, so that publishing someone else's
     * version is indistinguishable from publishing one that does not exist. The
     * route used to carry only `{versionId}` while the service required three
     * arguments — every call died with an ArgumentCountError before the check
     * could run.
     */
    public function publishSchemaVersion(Request $request, string $publicId, int $versionId): SchemaVersionResource
    {
        $validated = $request->validate(['base_revision' => ['sometimes', 'integer', 'min:1']]);
        $version = $this->service->publishSchemaVersion($versionId, $request->user()->id, $publicId, isset($validated['base_revision']) ? (int) $validated['base_revision'] : null);

        return new SchemaVersionResource($version);
    }

    /** Archive the currently published version for this hall. */
    public function archiveSchemaVersion(string $publicId, int $versionId): SchemaVersionResource
    {
        return new SchemaVersionResource(
            $this->service->archiveSchemaVersion($versionId, $publicId)
        );
    }

    /* ── Площадка владеет схемой (упрощение модели 2026-11-18) ──────────── */

    private function venueOrFail(string $publicId): Venue
    {
        $venue = Venue::query()->where('public_id', $publicId)->first();

        if ($venue === null) {
            throw new NotFoundError('Venue', $publicId);
        }

        return $venue;
    }

    /** Техническая строка схемы: одна на площадку, пользователю не показывается. */
    private function shadowHall(Venue $venue): Hall
    {
        // Зал — это сама площадка (halls теперь VIEW над venues): отдельной
        // строки нет, возвращаем модель с id площадки для legacy-сервисов.
        return (new Hall())->forceFill([
            'id' => $venue->id,
            'public_id' => $venue->public_id,
            'venue_id' => $venue->id,
            'name' => $venue->hall_name ?? $venue->name,
            'organization_id' => $venue->organization_id,
            'status' => $venue->status,
        ]);
    }

    /** GET /venues/{publicId}/schema-versions — версии схемы площадки. */
    public function venueSchemaVersions(string $publicId): JsonResponse
    {
        $venue = $this->venueOrFail($publicId);
        $versions = HallSchemaVersion::query()
            ->where('venue_id', $venue->id)
            ->orderByDesc('version')
            ->get();

        return response()->json([
            'data' => SchemaVersionResource::collection($versions)->resolve(),
        ]);
    }

    /** POST /venues/{publicId}/schema-versions/draft. */
    public function createVenueSchemaDraft(Request $request, string $publicId): SchemaVersionResource
    {
        $hall = $this->shadowHall($this->venueOrFail($publicId));

        $validated = $request->validate([
            'payload' => ['required', 'array'],
            'version_id' => ['nullable', 'integer', 'min:1'],
            'base_revision' => ['required_with:version_id', 'integer', 'min:1'],
        ]);

        return new SchemaVersionResource($this->service->createSchemaDraft(
            $hall,
            $validated['payload'],
            $request->user()->id,
            isset($validated['version_id']) ? (int) $validated['version_id'] : null,
            isset($validated['base_revision']) ? (int) $validated['base_revision'] : null,
        ));
    }

    /** POST /venues/{publicId}/schema-versions/{versionId}/publish. */
    public function publishVenueSchemaVersion(Request $request, string $publicId, int $versionId): SchemaVersionResource
    {
        $validated = $request->validate(['base_revision' => ['sometimes', 'integer', 'min:1']]);
        $hall = $this->shadowHall($this->venueOrFail($publicId));

        return new SchemaVersionResource(
            $this->service->publishSchemaVersion($versionId, $request->user()->id, $hall->public_id, isset($validated['base_revision']) ? (int) $validated['base_revision'] : null)
        );
    }

    /**
     * Resolve a hall by public id or fail with the envelope's 404.
     *
     * @throws NotFoundError
     */
    private function findOrFail(string $publicId): Hall
    {
        $hall = $this->service->findByPublicId($publicId);

        if (!$hall) {
            throw new NotFoundError('Hall', $publicId);
        }

        return $hall;
    }
}
