<?php

declare(strict_types=1);

namespace Nabilet\Modules\Checkin\Support;

use Nabilet\Core\Errors\ValidationError;
use Nabilet\Core\Support\DatabaseId;
use Nabilet\Core\Tenancy\OrganizationContext;
use Nabilet\Modules\Tickets\Models\Ticket;

/**
 * `ticket_id` из тела sync-запроса → `tickets.public_id`.
 *
 * ЗАЧЕМ ИМЕННО PUBLIC_ID
 *   Офлайн-бандл (`OfflineBundleBuilder`) отдаёт устройству public_id билета, и
 *   `TicketScanService::scanFromBundle()` принимает именно его. Поэтому внешний
 *   идентификатор тут — не вторичная форма, а основная.
 *
 * ПОЧЕМУ ЧИСЛО ТОЖЕ РАБОТАЕТ
 *   Ноль — не «не передали», а валидный id в MySQL не бывает; `0` означает
 *   «билет не указан», поэтому числу `0` соответствует отказ, а не поиск.
 *   Любой другой числовой id разрешается в public_id — иначе пакетная выгрузка
 *   из отчёта (`/admin/checkin/scans` отдаёт оба идентификатора) не пережила бы
 *   обратную отправку.
 */
final class TicketLocator
{
    public function publicIdOf(string|int $value): string
    {
        $value = is_int($value) ? (string) $value : trim($value);

        if ($value === '') {
            throw new ValidationError(['ticket_id' => ['Ticket id is required.']]);
        }

        if (DatabaseId::isNumeric($value)) {
            $id = (int) $value;

            if ($id === 0) {
                throw new ValidationError(['ticket_id' => ['Unknown ticket id.']]);
            }

            // Синхронизация чекера идёт под токеном устройства, не под
            // организацией HTTP-контекста: принадлежность билета устройству
            // проверяет scanFromBundle() по organizationId параметру.
            $publicId = app(OrganizationContext::class)->withoutScope(
                fn () => Ticket::query()->whereKey($id)->value('public_id')
            );

            if ($publicId === null) {
                throw new ValidationError(['ticket_id' => ['Unknown ticket id.']]);
            }

            return (string) $publicId;
        }

        $exists = app(OrganizationContext::class)->withoutScope(
            fn (): bool => Ticket::query()->where('public_id', $value)->exists()
        );

        if (! $exists) {
            throw new ValidationError(['ticket_id' => ['Unknown ticket public id.']]);
        }

        return $value;
    }
}
