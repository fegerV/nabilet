<?php

declare(strict_types=1);

namespace Nabilet\Modules\Notifications\Services;

use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;
use Nabilet\Modules\Core\Settings\SettingsStore;
use Throwable;

/**
 * Настройки исходящей почты, редактируемые из админки.
 *
 * SMTP-параметры живут в таблице `settings` (scope=`mail`), а не в .env, потому
 * что менять их должен администратор магазина, а не тот, у кого есть SSH. До
 * этого письма нельзя было включить без правки .env и перезапуска — на
 * шаред-хостинге TimeWeb это отдельная задача для владельца.
 *
 * ПАРОЛЬ ХРАНИТСЯ ЗАШИФРОВАННЫМ (`encrypted = 1`, Crypt), и НИКОГДА не
 * возвращается в API: наружу уходит только флаг «пароль задан» и его длина.
 * Иначе любой, кто откроет DevTools в админке, получил бы доступ к SMTP-ящику,
 * а он часто совпадает с корпоративной почтой.
 *
 * Значения из БД перекрывают config/env. Это осознанно: .env — значение по
 * умолчанию для свежей установки, а таблица — то, что администратор настроил
 * осознанно, и его выбор должен побеждать.
 *
 * `applyRuntimeConfig()` вызывается на каждом запросе (см.
 * NotificationsServiceProvider) — почта уходит и из очереди, и из веб-запроса,
 * и оба пути обязаны видеть одни и те же настройки.
 */
class MailSettings
{
    public const SCOPE = 'mail';

    /**
     * Чтение/запись `settings`. Кэш НЕ включён: настройки SMTP читаются редко,
     * а изменения из другого процесса должны быть видны сразу.
     */
    private SettingsStore $store;

    public function __construct()
    {
        $this->store = new SettingsStore();
    }

    /** Ключи, которые администратор может править через UI. */
    public const EDITABLE = [
        'host',
        'port',
        'username',
        'password',
        'encryption',
        'from_address',
        'from_name',
        self::ORDER_NOTIFY_KEY,
    ];

    /**
     * Копия писем о заказах.
     *
     * Запасной адресат на весь магазин: если у организации-владельца мероприятия
     * в `organizations.email` адреса нет, письмо о заказе уходит сюда. Заполняется
     * один раз при настройке почты, а организация — при создании площадки.
     */
    public const ORDER_NOTIFY_KEY = 'order_notify_email';

    /** Секрет: пишется в `settings.encrypted = 1`, наружу не отдаётся. */
    public const SECRET_KEYS = ['password'];

    /**
     * Загрузить настройки из БД и применить их к runtime-конфигу mail.
     *
     * Тихая деградация при недоступной таблице: на свежей установке (до
     * миграций) `settings` может не быть, и падать на этом нельзя — иначе
     * сломается и логин, и весь бутстрап.
     */
    public function applyRuntimeConfig(): void
    {
        $values = $this->storedValues();

        if ($values === []) {
            return;
        }

        $host = $values['host'] ?? null;

        // Пока хост не задан, mailer остаётся тем, что в .env: переключение на
        // smtp с пустым хостом превратило бы весь сайт в «почта не уходит».
        if (! is_string($host) || trim($host) === '') {
            return;
        }

        Config::set('mail.default', 'smtp');
        Config::set('mail.mailers.smtp.host', $host);
        Config::set('mail.mailers.smtp.port', (int) ($values['port'] ?? 587));

        $username = $values['username'] ?? null;
        if (is_string($username) && $username !== '') {
            Config::set('mail.mailers.smtp.username', $username);
        }

        $password = $this->decryptedPassword($values);
        if ($password !== null) {
            Config::set('mail.mailers.smtp.password', $password);
        }

        // Laravel 11+ ждёт `encryption` как `scheme` в mailers.smtp: `tls` ↔
        // connect with STARTTLS, `ssl` ↔ implicit TLS. Пустая строка = без шифрования.
        $scheme = match ((string) ($values['encryption'] ?? '')) {
            'ssl' => 'smtps',
            'tls' => 'smtp',
            default => null,
        };

        if ($scheme !== null) {
            Config::set('mail.mailers.smtp.scheme', $scheme);
        }

        $fromAddress = $values['from_address'] ?? null;
        if (is_string($fromAddress) && $fromAddress !== '') {
            Config::set('mail.from.address', $fromAddress);
        }

        $fromName = $values['from_name'] ?? null;
        if (is_string($fromName) && $fromName !== '') {
            Config::set('mail.from.name', $fromName);
        }
    }

    /**
     * Настройки для формы в админке. Пароль НЕ возвращается — только признак,
     * что он задан. Иначе админка стала бы способом выгрузить SMTP-секрет.
     *
     * @return array<string, mixed>
     */
    public function forAdmin(): array
    {
        $values = $this->storedValues();
        $password = $this->decryptedPassword($values);

        return [
            'host' => (string) ($values['host'] ?? ''),
            'port' => (int) ($values['port'] ?? 587),
            'username' => (string) ($values['username'] ?? ''),
            'password_set' => $password !== null && $password !== '',
            'encryption' => (string) ($values['encryption'] ?? 'tls'),
            'from_address' => (string) ($values['from_address'] ?? config('mail.from.address', '')),
            'from_name' => (string) ($values['from_name'] ?? config('mail.from.name', '')),
            'order_notify_email' => $this->orderNotifyEmail(),
            // Что реально уйдёт в транспорт сейчас — чтобы админ видел эффект,
            // а не догадывался, применились ли правки.
            'effective_mailer' => (string) config('mail.default'),
            'effective_host' => (string) config('mail.mailers.smtp.host', ''),
        ];
    }

    /**
     * Запасной адресат копий писем о заказах.
     *
     * Приоритет у таблицы `settings`: .env — значение для свежей установки, а
     * запись в таблице — осознанный выбор администратора. Пустая строка в записи
     * = «копий не надо» и перекрывает .env: стёр поле в форме — перестал
     * получать копии. Отсутствие записи — дефолт из .env.
     *
     * Различие проводится по наличию ключа, а не по пустоте значения, иначе
     * очистка поля возвращала бы .env-адрес и админ молча продолжал бы
     * получать копии, которых в интерфейсе уже нет.
     */
    public function orderNotifyEmail(): string
    {
        $values = $this->storedValues();

        if (array_key_exists(self::ORDER_NOTIFY_KEY, $values)) {
            return is_string($values[self::ORDER_NOTIFY_KEY]) ? trim($values[self::ORDER_NOTIFY_KEY]) : '';
        }

        return trim((string) config('mail.order_notify_email', ''));
    }

    /**
     * Сохранить настройки. `null` в значении удаляет переопределение (возврат к
     * .env); `password` со значением `null` НЕ удаляет пароль — для этого есть
     * отдельный флаг, иначе случайное сохранение формы без пароля стёрло бы его.
     *
     * @param  array<string, mixed>  $values
     * @param  bool  $clearPassword
     */
    public function save(array $values, bool $clearPassword = false): void
    {
        foreach ($values as $key => $value) {
            if (! in_array($key, self::EDITABLE, true)) {
                continue;
            }

            if ($key === 'password') {
                // Пустая строка = «не менять пароль», а не «стереть».
                if (is_string($value) && $value !== '') {
                    $this->writeValue('password', $value, encrypted: true);
                }

                continue;
            }

            if ($value === null) {
                $this->forget($key);

                continue;
            }

            $this->writeValue($key, $value);
        }

        if ($clearPassword) {
            $this->forget('password');
        }

        // Применить сразу: админ сохранил — письмо должно уйти уже с новыми
        // настройками, без перезапуска воркера.
        $this->applyRuntimeConfig();
    }

    /**
     * Отправить тестовое письмо текущими настройками.
     *
     * Возвращает текст ошибки или null при успехе — админке нужен внятный
     * ответ, а не 500, потому что «неверный пароль SMTP» это ожидаемая
     * ситуация при настройке, а не сбой сервера.
     */
    public function sendTest(string $recipient): ?string
    {
        // Настройки могли поменяться в этом же запросе — берём актуальные.
        $this->applyRuntimeConfig();

        try {
            Mail::raw(
                'Это тестовое письмо от NABILET. Настройки SMTP применились успешно.',
                static function ($message) use ($recipient): void {
                    $message->to($recipient)->subject('NABILET: проверка SMTP');
                },
            );

            return null;
        } catch (Throwable $e) {
            return str_ireplace($recipient, '[адрес скрыт]', $e->getMessage());
        }
    }

    /** @return array<string, mixed> сырые значения из БД (пароль — всё ещё шифротекст) */
    private function storedValues(): array
    {
        return $this->store->values(self::SCOPE);
    }

    /**
     * @param  array<string, mixed>  $values
     */
    private function decryptedPassword(array $values): ?string
    {
        $raw = $values['password'] ?? null;

        if (! is_string($raw) || $raw === '') {
            return null;
        }

        return SettingsStore::decrypt($raw);
    }

    private function writeValue(string $key, mixed $value, bool $encrypted = false): void
    {
        $this->store->write(self::SCOPE, $key, $value, $encrypted);
    }

    private function forget(string $key): void
    {
        $this->store->forget(self::SCOPE, $key);
    }
}
