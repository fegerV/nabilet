<?php

declare(strict_types=1);

namespace Nabilet\Modules\Tickets\Services;

use Nabilet\Modules\Tickets\Models\Ticket;
use Nabilet\Modules\Tickets\Repositories\TicketRepository;
use Nabilet\Modules\Tickets\Domain\TicketIssuance;
use Nabilet\Modules\Tickets\StateMachines\TicketStateMachine;
use Nabilet\Modules\Orders\Models\Order;
use Nabilet\Modules\Orders\StateMachines\OrderStateMachine;
use Nabilet\Modules\Inventory\Models\InventoryItem;
use Nabilet\Modules\Sessions\Models\Session;
use Nabilet\Core\Support\QrSigner;
use Nabilet\Core\Support\Sha256Hex;
use Nabilet\Modules\Core\Support\PublicId;
use Nabilet\Core\Tenancy\OrganizationContext;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class TicketService
{
    // NB: the old constructor injected `CheckinEvaluator` — a PURE domain class
    // whose real contract is evaluate(ScanRequest, ?TicketSnapshot). Nothing in
    // this service ever called it correctly (it passed a Ticket model and got a
    // TypeError), and because Laravel's container cannot build that dependency
    // graph cleanly through this service, `app(TicketService::class)` from
    // PaymentService crashed and NO tickets were issued after payment. Check-in
    // decisions live in TicketScanService, which is the only place allowed to
    // talk to the evaluator.
    public function __construct(
        protected TicketRepository $repository,
        protected TicketIssuance $issuance
    ) {}

    /**
     * A6: выпуск билетов для оплаченного заказа.
     *
     * Идемпотентность: повторный вызов (например, ретрай вебхука) НЕ перевыпускает
     * билеты — уже существующие возвращаются как есть. Выпуск разрешён только для
     * статуса 'paid' — терминального успеха машины состояний Order ('completed' в
     * машине отсутствует).
     */
    public function issueTicketsForOrder(Order $order): array
    {
        // Системный путь: выпуск по факту оплаты идёт через вебхук и задание
        // очереди — организации запроса там нет. Дети читаются у уже
        // найденного заказа (ретрай вебхука через `findAny*`), поэтому
        // читающий скоуп `Ticket`/`Order` здесь не участвует.
        return app(OrganizationContext::class)->withoutScope(
            fn (): array => $this->issueTicketsForOrderScoped($order)
        );
    }

    private function issueTicketsForOrderScoped(Order $order): array
    {
        return DB::transaction(function () use ($order) {
            if ($order->status !== OrderStateMachine::PAID) {
                // Доменная ошибка вместо RuntimeException (аудит D-7):
                // прямой вызов из админ-пути должен давать конверт §66 (422
                // ORDER_NOT_PAID), а не 500, — машина состояний просто не даёт
                // этот переход, и это deliberate refusal, а не сбой.
                throw new \Nabilet\Core\Errors\DomainRuleViolation(
                    'order must be paid before tickets can be issued',
                    'ORDER_NOT_PAID',
                );
            }

            // Идемпотентность: если билеты уже выпущены — ничего не создаём заново.
            $existing = Ticket::where('order_id', $order->id)->orderBy('id')->get();
            if ($existing->isNotEmpty()) {
                return $existing->all();
            }

            $signer = $this->makeQrSigner();
            $tickets = [];
            $seq = 0;

            foreach ($order->items as $item) {
                $inventory = InventoryItem::find($item->inventory_item_id);

                // `tickets.event_id` и `tickets.session_id` — NOT NULL, поэтому оба
                // обязаны быть определены ДО вставки.
                //
                // Здесь стоял фолбэк `$inventory?->event_id`, и он был мёртвым
                // кодом: колонки `event_id` у `inventory_items` не существует
                // (есть `session_id`, `type`, `seat_id`, `standing_zone_id`,
                // `price_amount`, `capacity`, ...). Поэтому для заказа без
                // `orders.event_id` — например созданного через `POST /orders`
                // или тестовой фикстурой — выпуск падал с
                // `1048 Column 'event_id' cannot be null`, откатывая всю
                // транзакцию вебхука ВМЕСТЕ с подтверждением оплаты: провайдер
                // деньги списал, а заказ оставался неоплаченным.
                //
                // Событие выводим из сеанса — это единственный корректный путь,
                // потому что сеанс всегда принадлежит событию.
                $sessionId = $order->session_id ?? $inventory?->session_id;
                $eventId = $order->event_id
                    ?? ($sessionId !== null ? Session::query()->whereKey($sessionId)->value('event_id') : null);

                if ($sessionId === null || $eventId === null) {
                    // Заказ вне сеанса: билет не к чему привязать. Ронять
                    // транзакцию нельзя — оплата уже подтверждена провайдером,
                    // и 500 откатил бы её. Говорим громко и пропускаем позицию.
                    Log::warning('TicketService: no session/event for order item — ticket skipped', [
                        'order_id' => $order->id,
                        'order_item_id' => $item->id,
                        'inventory_item_id' => $item->inventory_item_id,
                    ]);

                    continue;
                }

                for ($i = 0; $i < max(1, (int) $item->quantity); $i++) {
                    $seq++;
                    $publicId = PublicId::generate();
                    $snapshot = $item->seat_snapshot_json ?? [];
                    $seatId = $snapshot['seat_id'] ?? $inventory?->seat_id;

                    // Смягчение D2-арх (UNIQUE(session_id, seat_id) в схеме был
                    // бы радикальным решением: возврат места и его ПЕРЕПРОДАЖА
                    // законно создают второй билет на то же место, а частичного
                    // уникального индекса в MySQL нет). Гвард app-уровня:
                    // АКТИВНЫЙ билет (issued/used) на это место этого сеанса
                    // уже существует — значит, инвентарь дважды попал в
                    // checkout. Второй билет не создаём (критично в лог) и
                    // продолжаем выпуск остальных, не роняя оплаченный заказ.
                    if ($seatId !== null
                        && Ticket::query()
                            ->where('session_id', $sessionId)
                            ->where('seat_id', (int) $seatId)
                            ->whereIn('status', [TicketStateMachine::ISSUED, TicketStateMachine::USED])
                            ->exists()
                    ) {
                        Log::critical('TicketService: duplicate active ticket for the same seat — second ticket suppressed', [
                            'order_id' => $order->id,
                            'order_item_id' => $item->id,
                            'session_id' => $sessionId,
                            'seat_id' => (int) $seatId,
                        ]);

                        continue;
                    }

                    // QrSigner (§30): в QR нет ни e-mail, ни цены — только
                    // NB1.<ticketPublicId>.<token>.<signature>.
                    $signed = $signer->issue($publicId);

                    $ticket = Ticket::create([
                        'public_id' => $publicId,
                        'ticket_number' => sprintf('TCK-%s-%03d', strtoupper(substr($order->public_id, 0, 8)), $seq),
                        'ticket_index' => $i + 1,
                        'order_id' => $order->id,
                        'order_item_id' => $item->id,
                        'event_id' => $eventId,
                        'session_id' => $sessionId,
                        'inventory_item_id' => $item->inventory_item_id,
                        'seat_id' => $seatId,
                        'holder_name' => $order->customer_name ?? $order->customer_email,
                        'status' => TicketStateMachine::ISSUED,
                        'qr_version' => 1,
                        'qr_token_hash' => Sha256Hex::of($signed['token']),
                        'qr_payload' => $signed['payload'],
                        'issued_at' => now(),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    $tickets[] = $ticket;
                }
            }

            return $tickets;
        });
    }

    /**
     * Подписывальщик QR.
     *
     * Сборка вынесена в единый `QrSignerFactory`: раньше логика была скопирована
     * сюда и в `TicketScanService`, и оба экземпляра молча подписывали билеты
     * `APP_KEY`, если `TICKET_QR_SECRET` не задан (см. комментарий фабрики).
     */
    protected function makeQrSigner(): QrSigner
    {
        return QrSignerFactory::make();
    }

    /**
     * Билет по id в пределах организации. Организация обязательна:
     * без неё чужой билет (по `order.organization_id`) стал бы виден.
     * Для системных контекстов используйте `findTicketAny()`.
     */
    public function findTicket(int $ticketId, int $organizationId): ?Ticket
    {
        return $this->repository->find($ticketId, $organizationId);
    }

    /** Системный поиск без скоупа организации (вебхуки, задания, reconcile). */
    public function findTicketAny(int $ticketId): ?Ticket
    {
        return $this->repository->findAny($ticketId);
    }

    public function findByPublicId(string $publicId, int $organizationId): ?Ticket
    {
        return $this->repository->findByPublicId($publicId, $organizationId);
    }

    public function findAnyByPublicId(string $publicId): ?Ticket
    {
        return $this->repository->findAnyByPublicId($publicId);
    }

    /**
     * Check-in through the service's own entry point. The decision belongs to
     * the pure CheckinEvaluator (evaluate(ScanRequest, ?TicketSnapshot)) and is
     * owned by TicketScanService; this method delegates so that callers of
     * TicketService keep working without re-implementing the door rules here.
     *
     * Арендатор выводится из заказа билета (`orders.organization_id` NOT NULL):
     * делегат обязан работать и вне HTTP-контекста, а организация в
     * `TicketScanService::scan()` обязательна (план §3.1) — «вызова без
     * арендатора» больше не существует.
     */
    public function checkInTicket(Ticket $ticket, int $checkinDeviceId, ?string $location = null): array
    {
        $organizationId = (int) DB::table('orders')->where('id', (int) $ticket->order_id)->value('organization_id');

        return app(\Nabilet\Modules\Tickets\Services\TicketScanService::class)
            ->scan(
                ticketId: (int) $ticket->id,
                sessionId: (int) $ticket->session_id,
                organizationId: $organizationId,
                deviceId: $checkinDeviceId,
            );
    }

    /**
     * Revoke a ticket (§44). Spec statuses: issued|used|cancelled|refunded|
     * expired|revoked — 'invalidated' does not exist in ck_tickets_status, and
     * the old code wrote non-existent columns invalidated_at/
     * invalidation_reason (SQLSTATE 42S22 on every call).
     */
    public function revokeTicket(Ticket $ticket, string $reason): Ticket
    {
        if ($ticket->status === TicketStateMachine::REVOKED) {
            throw new \RuntimeException('Ticket is already revoked');
        }

        // issued -> revoked and used -> revoked are the only legal paths into
        // `revoked` per TicketStateMachine; terminal states stay terminal.
        $allowed = TicketStateMachine::make()->can($ticket->status, TicketStateMachine::REVOKED);
        if ($allowed === false) {
            throw new \RuntimeException(sprintf(
                'Cannot revoke a ticket in status "%s"',
                (string) $ticket->status
            ));
        }

        return $this->repository->revoke($ticket, $reason);
    }

    /** Back-compatible alias; prefer revokeTicket(). */
    public function invalidateTicket(Ticket $ticket, string $reason): Ticket
    {
        return $this->revokeTicket($ticket, $reason);
    }

    public function getTicketsByOrder(int $orderId): array
    {
        return $this->repository->findByOrder($orderId)->toArray();
    }

    public function getTicketsBySession(int $sessionId, int $limit = 50): LengthAwarePaginator
    {
        return $this->repository->findBySession($sessionId, $limit);
    }

    public function getCheckinStats(int $sessionId): array
    {
        return $this->repository->getCheckinStats($sessionId);
    }

    protected function generateBarcodeData(Order $order, $item): string
    {
        // Generate unique barcode data
        return sprintf(
            'ORD-%s-ITEM-%d',
            $order->public_id,
            $item->id
        );
    }
}
