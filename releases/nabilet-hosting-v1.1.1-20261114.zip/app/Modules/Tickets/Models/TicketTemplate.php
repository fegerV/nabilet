<?php

declare(strict_types=1);

namespace Nabilet\Modules\Tickets\Models;

use Nabilet\Modules\Core\Models\Concerns\HasPublicId;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
// Каноническая модель. Дубликат в `Modules\Organizations\Models\Organization`
// нёс трейт `SoftDeletes` при отсутствующей колонке `organizations.deleted_at`,
// из-за чего эта связь падала с `SQLSTATE[42S22]` при первой же загрузке.
use Nabilet\Modules\Core\Organizations\Models\Organization;

/**
 * Eloquent mapping for `ticket_templates` (005_payments_tickets).
 * Schema columns are organization_id, name, format, width, height,
 * template_json, active and public_id — not session_id/qr_prefix/is_active.
 */
class TicketTemplate extends Model
{
    use HasPublicId;

    protected $table = 'ticket_templates';

    protected $fillable = [
        'public_id',
        'organization_id',
        'name',
        'format',
        'width',
        'height',
        'template_json',
        'active',
    ];

    protected $casts = [
        'width' => 'integer',
        'height' => 'integer',
        'template_json' => 'array',
        'active' => 'boolean',
    ];

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    /**
     * Мероприятия, которым назначен этот макет (`events.ticket_template_id`).
     *
     * Связь — то, что показывает `/admin/ticket-templates`: какой макет чьи
     * билеты оформляет. Удаление макета обнуляет ссылку (`ON DELETE SET NULL`),
     * поэтому коллекция всегда актуальна без ручной синхронизации.
     */
    public function events(): HasMany
    {
        return $this->hasMany(\Nabilet\Modules\Events\Models\Event::class, 'ticket_template_id');
    }
}
